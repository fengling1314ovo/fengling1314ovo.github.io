/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetSchoolPage", "<!-- pagePetSchoolPage -->\n<div class=\"tool-page\" id=\"pagePetSchoolPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🎒 出门上学</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">选择学校让小橘去上学，提升战力！等级越高，战力提升越多~</div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;\">\n            <div style=\"font-size:48px;\" id=\"schoolPetEmoji\">🐱</div>\n            <div style=\"margin-left:12px;\">\n              <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"schoolPetMood\">心情不错~</div>\n            </div>\n          </div>\n          <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n            <div style=\"display:inline-block;background:#fef3c7;color:#f59e0b;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n              ⚔️ <span id=\"schoolPetPower\">0</span>\n            </div>\n            <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"schoolCoins\">0</span></div>\n          </div>\n        </div>\n        <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span>\n              <span id=\"schoolHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"schoolHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span>\n              <span id=\"schoolCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"schoolCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span>\n              <span id=\"schoolAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"schoolAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 上学中状态 -->\n      <div id=\"schoolAwayArea\" style=\"display:none;margin-bottom:14px;\">\n        <div style=\"background:#fff3cd;border-radius:16px;padding:20px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n          <div style=\"font-size:48px;\">🏫</div>\n          <div style=\"font-size:16px;font-weight:700;color:#856404;margin-top:8px;\" id=\"schoolAwayText\">小橘正在上学...</div>\n          <div style=\"font-size:28px;font-weight:700;color:#856404;margin-top:10px;\" id=\"schoolAwayTimer\">00:00</div>\n          <div style=\"font-size:13px;color:#856404;margin-top:8px;\" id=\"schoolAwayReward\">预计战力 +0</div>\n          <button onclick=\"recallPet()\" style=\"margin-top:14px;background:#ef4444;color:#fff;border:none;padding:10px 24px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(239,68,68,0.3);\">\n            🏠 召回宠物（退还一半金币）\n          </button>\n          <button onclick=\"showSuperItemPanel()\" style=\"margin-top:10px;margin-left:8px;background:linear-gradient(135deg,#f43f5e,#f97316);color:#fff;border:none;padding:10px 24px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(244,63,94,0.3);\">\n            ✨ 使用道具\n          </button>\n        </div>\n      </div>\n      \n      <!-- 学校列表 -->\n      <div id=\"schoolListArea\">\n        <div style=\"display:grid;gap:12px;\" id=\"schoolList\">\n          <!-- 学校列表由JS生成 -->\n        </div>\n      </div>\n    </div>\n  </div>");
window.flRegisterToolPage("pagePetPlayPage", "<!-- pagePetPlayPage -->\n<div class=\"tool-page\" id=\"pagePetPlayPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🌳 出去玩</h3>\n      <div style=\"display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;\">\n        <div style=\"font-size:13px;color:var(--text-secondary);\">选择地点带小橘出去玩，提升好感度！不同地点有不同的惊喜哦~</div>\n        <button onclick=\"openPage('collectionRecordPage')\" style=\"flex-shrink:0;margin-left:10px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#fff;border:none;padding:8px 14px;border-radius:10px;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(245,158,11,0.3);white-space:nowrap;\">📜 获得记录</button>\n      </div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#dcfce7,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;\">\n            <div style=\"font-size:48px;\" id=\"playPetEmoji\">🐱</div>\n            <div style=\"margin-left:12px;\">\n              <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"playPetMood\">心情不错~</div>\n            </div>\n          </div>\n          <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n            <div style=\"display:inline-block;background:#fef3c7;color:#f59e0b;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n              ⚔️ <span id=\"playPetPower\">0</span>\n            </div>\n            <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"playCoins\">0</span></div>\n          </div>\n        </div>\n        <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span>\n              <span id=\"playHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"playHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span>\n              <span id=\"playCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"playCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span>\n              <span id=\"playAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"playAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 游玩中状态 -->\n      <div id=\"playAwayArea\" style=\"display:none;margin-bottom:14px;\">\n        <div style=\"background:#dcfce7;border-radius:16px;padding:20px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n          <div style=\"font-size:48px;\" id=\"playAwayEmoji\">🌳</div>\n          <div style=\"font-size:16px;font-weight:700;color:#166534;margin-top:8px;\" id=\"playAwayText\">小橘正在公园玩耍...</div>\n          <div style=\"font-size:28px;font-weight:700;color:#166534;margin-top:10px;\" id=\"playAwayTimer\">00:00</div>\n          <div style=\"font-size:13px;color:#166534;margin-top:8px;\" id=\"playAwayReward\">预计好感 +10</div>\n          <div style=\"display:flex;gap:10px;margin-top:14px;justify-content:center;\">\n            <button onclick=\"showPlaySuperItemPanel()\" style=\"background:linear-gradient(135deg,#f43f5e,#f97316);color:#fff;border:none;padding:10px 20px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(244,63,94,0.3);\">\n              ✨ 使用道具\n            </button>\n            <button onclick=\"recallPetFromPlay()\" style=\"background:#ef4444;color:#fff;border:none;padding:10px 20px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(239,68,68,0.3);\">\n              🏠 召回宠物\n            </button>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 游玩地点列表 -->\n      <div id=\"playLocationList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 地点卡片由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ==================== 宠物上学系统 ====================
const PET_SCHOOLS = [
  {id:'kindergarten', name:'幼儿园', emoji:'🏫', cost:5, duration:10, power:1, color:'#86efac', unlockCount:0, unlockSchool:null},
  {id:'primary', name:'小学', emoji:'🏫', cost:10, duration:20, power:3, color:'#93c5fd', unlockCount:3, unlockSchool:'kindergarten'},
  {id:'middle', name:'初中', emoji:'🏫', cost:20, duration:30, power:6, color:'#fcd34d', unlockCount:10, unlockSchool:'primary'},
  {id:'high', name:'高中', emoji:'🏫', cost:35, duration:45, power:10, color:'#f9a8d4', unlockCount:20, unlockSchool:'middle'},
  {id:'university', name:'大学', emoji:'🎓', cost:50, duration:60, power:15, color:'#c4b5fd', unlockCount:25, unlockSchool:'high'}
];

// 宠物打工配置
const PET_JOBS = [
  {id:'paperboy', name:'送报纸', emoji:'📰', duration:30, coinMin:8, coinMax:15, hungerCost:8, cleanCost:5, affectionCost:2, unlockSchool:null, unlockCount:0, color:'#fcd34d', desc:'早起送报纸，辛苦但稳定~'},
  {id:'waiter', name:'餐厅服务员', emoji:'🍽️', duration:45, coinMin:15, coinMax:25, hungerCost:10, cleanCost:8, affectionCost:3, unlockSchool:'kindergarten', unlockCount:2, color:'#93c5fd', desc:'端盘子擦桌子，需幼儿园学历~'},
  {id:'cashier', name:'超市收银员', emoji:'💳', duration:60, coinMin:25, coinMax:40, hungerCost:10, cleanCost:5, affectionCost:3, unlockSchool:'primary', unlockCount:3, color:'#86efac', desc:'扫码收钱，需小学学历~'},
  {id:'tutor', name:'家庭教师', emoji:'📚', duration:90, coinMin:40, coinMax:65, hungerCost:8, cleanCost:3, affectionCost:5, unlockSchool:'middle', unlockCount:5, color:'#f9a8d4', desc:'辅导小朋友功课，需初中学历~'},
  {id:'programmer', name:'程序员', emoji:'💻', duration:120, coinMin:60, coinMax:100, hungerCost:12, cleanCost:2, affectionCost:8, unlockSchool:'high', unlockCount:5, color:'#c4b5fd', desc:'敲代码赚大钱，需高中学历~'},
  {id:'doctor', name:'医生', emoji:'⚕️', duration:150, coinMin:90, coinMax:150, hungerCost:10, cleanCost:5, affectionCost:5, unlockSchool:'university', unlockCount:3, color:'#f87171', desc:'救死扶伤，需大学学历~'}
];

// 每日任务配置


// 清洁用品配置
const PET_CLEAN_ITEMS = [
  {id:'towel', name:'毛巾', emoji:'🧻', cost:2, clean:10},
  {id:'soap', name:'香皂', emoji:'🧼', cost:3, clean:15},
  {id:'bathball', name:'沐浴球', emoji:'🛁', cost:5, clean:20},
  {id:'shampoo', name:'沐浴露', emoji:'🧴', cost:8, clean:30}
];

// 猫咪玩具配置
const PET_TOYS = [
  {id:'feather', name:'逗猫棒', emoji:'🪶', cost:5, affection:10},
  {id:'yarn', name:'毛线球', emoji:'🧶', cost:3, affection:5},
  {id:'laser', name:'激光笔', emoji:'🔴', cost:8, affection:15},
  {id:'scratcher', name:'猫抓板', emoji:'📦', cost:6, affection:12},
  {id:'mousetoy', name:'小老鼠', emoji:'🐭', cost:4, affection:8},
  {id:'catnip', name:'猫薄荷', emoji:'🌿', cost:10, affection:20}
];

// 游玩地点配置
const PET_PLAY_LOCATIONS = [
  {id:'park', name:'公园', emoji:'🌳', hungerCost:5, cleanCost:3, affectionGain:10, duration:30, coinMin:5, coinMax:15, powerGain:0, color:'#22c55e', desc:'散步晒太阳，轻松愉快~', collectibles:['🍁','🦋','🌻']},
  {id:'mall', name:'商场', emoji:'🏬', hungerCost:8, cleanCost:5, affectionGain:8, duration:45, coinMin:10, coinMax:25, powerGain:0, color:'#3b82f6', desc:'逛街购物，可能有惊喜~', collectibles:['🛍️','💄','🎀']},
  {id:'beach', name:'海边', emoji:'🏖️', hungerCost:10, cleanCost:15, affectionGain:15, duration:60, coinMin:15, coinMax:35, powerGain:0, color:'#06b6d4', desc:'吹海风玩沙子，超开心~', collectibles:['🐚','🦀','🐠']},
  {id:'playground', name:'游乐场', emoji:'🎡', hungerCost:15, cleanCost:10, affectionGain:25, duration:90, coinMin:20, coinMax:50, powerGain:2, color:'#ec4899', desc:'玩各种游乐设施，快乐加倍~', collectibles:['🎈','🎠','🎪']},
  {id:'cinema', name:'电影院', emoji:'🎬', hungerCost:5, cleanCost:2, affectionGain:12, duration:40, coinMin:8, coinMax:20, powerGain:0, color:'#8b5cf6', desc:'看场电影，放松心情~', collectibles:['🎬','🍿','🎞️']},
  {id:'zoo', name:'动物园', emoji:'🦁', hungerCost:8, cleanCost:5, affectionGain:12, duration:40, coinMin:8, coinMax:20, powerGain:0, color:'#f97316', desc:'看各种可爱的小动物~', collectibles:['🦁','🐘','🦒']},
  {id:'aquarium', name:'水族馆', emoji:'🐬', hungerCost:6, cleanCost:8, affectionGain:15, duration:60, coinMin:12, coinMax:30, powerGain:0, color:'#0ea5e9', desc:'看海洋生物游来游去~', collectibles:['🐬','🐙','🪸']},
  {id:'ski', name:'滑雪场', emoji:'⛷️', hungerCost:12, cleanCost:8, affectionGain:18, duration:75, coinMin:18, coinMax:40, powerGain:1, color:'#38bdf8', desc:'滑雪打雪仗，超刺激~', collectibles:['⛷️','⛄','🏂']},
  {id:'camping', name:'露营地', emoji:'⛺', hungerCost:10, cleanCost:10, affectionGain:20, duration:50, coinMin:10, coinMax:25, powerGain:0, color:'#84cc16', desc:'搭帐篷烤篝火，亲近自然~', collectibles:['⛺','🔥','🔦']},
  {id:'dessert', name:'甜品店', emoji:'🍰', hungerCost:3, cleanCost:2, affectionGain:8, duration:25, coinMin:5, coinMax:15, powerGain:0, color:'#f472b6', desc:'吃甜甜的蛋糕和冰淇淋~', collectibles:['🍰','🍩','🧁']}
];

// 收藏品配置
const PET_COLLECTIBLES = {
  '🍁':{name:'枫叶',location:'公园',desc:'秋天的公园随处可见，火红的枫叶像小手掌~'},
  '🦋':{name:'蝴蝶',location:'公园',desc:'花丛中翩翩起舞的美丽精灵，小橘追了好久~'},
  '🌻':{name:'向日葵',location:'公园',desc:'永远朝着太阳绽放的花朵，充满阳光的味道~'},
  '🛍️':{name:'购物袋',location:'商场',desc:'逛街购物的战利品，里面装着满满的快乐~'},
  '💄':{name:'口红',location:'商场',desc:'美妆店的热门商品，小橘偷偷试了试~'},
  '🎀':{name:'蝴蝶结',location:'商场',desc:'可爱的粉色蝴蝶结，戴在小橘头上超萌~'},
  '🐚':{name:'贝壳',location:'海边',desc:'海浪冲上来的美丽贝壳，贴在耳边能听到海声~'},
  '🦀':{name:'螃蟹',location:'海边',desc:'横着走路的小螃蟹，差点夹住小橘的爪子~'},
  '🐠':{name:'小鱼',location:'海边',desc:'在浅水里游来游去的彩色小鱼，超可爱~'},
  '🎈':{name:'气球',location:'游乐场',desc:'五颜六色的气球，小橘一松手就飞上天啦~'},
  '🎠':{name:'旋转木马',location:'游乐场',desc:'梦幻的旋转木马，小橘坐上去开心得喵喵叫~'},
  '🎪':{name:'马戏团',location:'游乐场',desc:'精彩的马戏团表演，小橘看得目不转睛~'},
  '🎬':{name:'电影票',location:'电影院',desc:'一场电影的入场券，小橘选了最爱的动画片~'},
  '🍿':{name:'爆米花',location:'电影院',desc:'看电影必备的香甜爆米花，小橘一口一个~'},
  '🎞️':{name:'胶片',location:'电影院',desc:'老电影的胶片，记录着一个个动人的故事~'},
  '🦁':{name:'狮子玩偶',location:'动物园',desc:'动物园纪念品商店买的小狮子玩偶，毛茸茸超可爱~'},
  '🐘':{name:'大象贴纸',location:'动物园',desc:'长鼻子大象的贴纸，小橘贴在了日记本上~'},
  '🦒':{name:'长颈鹿模型',location:'动物园',desc:'长长的脖子模型，小橘说要和它比身高~'},
  '🐬':{name:'海豚玩偶',location:'水族馆',desc:'蓝色的海豚毛绒玩偶，摸起来软软的~'},
  '🐙':{name:'章鱼毛绒',location:'水族馆',desc:'八只触手的章鱼玩偶，小橘数了好几遍~'},
  '🪸':{name:'珊瑚标本',location:'水族馆',desc:'美丽的珊瑚标本，像海底的小花~'},
  '⛷️':{name:'迷你滑雪板',location:'滑雪场',desc:'缩小版的滑雪板钥匙扣，小橘挂在书包上~'},
  '⛄':{name:'小雪人',location:'滑雪场',desc:'用雪堆的小雪人，虽然化了但照片留下来了~'},
  '🏂':{name:'滑雪奖牌',location:'滑雪场',desc:'小橘第一次滑雪获得的鼓励奖牌~'},
  '⛺':{name:'小帐篷',location:'露营地',desc:'迷你帐篷模型，小橘说下次要带真的去露营~'},
  '🔥':{name:'篝火徽章',location:'露营地',desc:'露营篝火晚会的纪念徽章，暖暖的~'},
  '🔦':{name:'小手电筒',location:'露营地',desc:'夜里探险用的小手电筒，还能发光~'},
  '🍰':{name:'小蛋糕',location:'甜品店',desc:'草莓奶油小蛋糕，小橘吃得满脸都是~'},
  '🍩':{name:'甜甜圈',location:'甜品店',desc:'粉色糖霜甜甜圈，小橘舔了舔嘴唇~'},
  '🧁':{name:'纸杯蛋糕',location:'甜品店',desc:'可爱的纸杯蛋糕，上面有小橘最爱的糖珠~'}
};

let petPlayTimer = null;
let currentPlayLocation = null;

// 渲染游玩地点列表
function renderPlayLocations(){
  const container = document.getElementById('playLocationList');
  if(!container) return;
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  
  container.innerHTML = PET_PLAY_LOCATIONS.map(loc => {
    const canPlay = hunger >= loc.hungerCost && clean >= loc.cleanCost;
    return `
      <div onclick="${canPlay ? `confirmPlayLocation('${loc.id}')` : `showToast('状态不足，无法去${loc.name}玩~')`}" 
           style="background:linear-gradient(135deg,${loc.color}40,${loc.color}20);border-radius:16px;padding:16px;cursor:${canPlay?'pointer':'not-allowed'};box-shadow:0 2px 12px rgba(0,0,0,0.06);border:2px solid ${canPlay?loc.color:'#e5e7eb'};opacity:${canPlay?1:0.5};">
        <div style="text-align:center;">
          <div style="font-size:40px;">${loc.emoji}</div>
          <div style="font-size:16px;font-weight:700;margin-top:6px;">${loc.name}</div>
          <div style="font-size:11px;color:#666;margin-top:2px;">${loc.desc}</div>
          <div style="margin-top:10px;padding:8px;background:rgba(255,255,255,0.6);border-radius:8px;font-size:11px;line-height:1.6;">
            <div>⏱️ ${loc.duration}秒</div>
            <div>🍖 -${loc.hungerCost} 🧼 -${loc.cleanCost}</div>
            <div style="color:#16a34a;font-weight:600;">💕 +${loc.affectionGain}好感</div>
            <div style="color:#d97706;font-weight:600;">💰 ${loc.coinMin}-${loc.coinMax}金币${loc.powerGain>0?` ⚔️+${loc.powerGain}`:''}</div>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// 确认游玩地点（弹出确认窗口）
function confirmPlayLocation(locationId){
  const loc = PET_PLAY_LOCATIONS.find(l => l.id === locationId);
  if(!loc) return;
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  if(hunger < loc.hungerCost){
    showToast(`饱食度不足，需要${loc.hungerCost}点~`);
    return;
  }
  if(clean < loc.cleanCost){
    showToast(`清洁值不足，需要${loc.cleanCost}点~`);
    return;
  }
  
  // 创建确认弹窗
  const collectiblesHtml = loc.collectibles.map(c => 
    `<span style="display:inline-block;font-size:24px;margin:0 4px;" title="${PET_COLLECTIBLES[c]?.name || c}">${c}</span>`
  ).join('');
  
  const modalHtml = `
    <div class="modal-mask" id="playConfirmMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;z-index:99999;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:360px;width:90%;padding:0;overflow:hidden;border-radius:20px;">
        <button class="modal-close-btn" type="button" aria-label="关闭游玩确认" onclick="closePlayConfirm()" style="position:absolute;top:12px;right:12px;z-index:2;">✕</button>
        <div style="background:linear-gradient(135deg,${loc.color},${loc.color}aa);padding:20px;text-align:center;">
          <div style="font-size:56px;">${loc.emoji}</div>
          <div style="font-size:18px;font-weight:700;color:#fff;margin-top:8px;">${loc.name}</div>
          <div style="font-size:12px;color:rgba(255,255,255,0.9);margin-top:4px;">${loc.desc}</div>
        </div>
        <div style="padding:20px;">
          <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;text-align:center;">📋 游玩确认</div>
          
          <!-- 消耗 -->
          <div style="background:#fef2f2;border-radius:10px;padding:10px;margin-bottom:10px;">
            <div style="font-size:12px;font-weight:600;color:#dc2626;margin-bottom:6px;">💔 消耗</div>
            <div style="display:flex;gap:12px;font-size:13px;color:#666;">
              <span>🍖 饱食度 -${loc.hungerCost}</span>
              <span>🧼 清洁值 -${loc.cleanCost}</span>
            </div>
          </div>
          
          <!-- 获得 -->
          <div style="background:#f0fdf4;border-radius:10px;padding:10px;margin-bottom:10px;">
            <div style="font-size:12px;font-weight:600;color:#16a34a;margin-bottom:6px;">🎁 可能获得</div>
            <div style="font-size:13px;color:#666;line-height:1.8;">
              <div>💕 好感度 +${loc.affectionGain}</div>
              <div>💰 金币 ${loc.coinMin}-${loc.coinMax}${loc.powerGain > 0 ? ` · ⚔️ 战力 +${loc.powerGain}` : ''}</div>
              <div style="margin-top:4px;">🏆 收藏品：${collectiblesHtml}</div>
            </div>
          </div>
          
          <!-- 时长 -->
          <div style="text-align:center;font-size:12px;color:#999;margin-bottom:14px;">⏱️ 游玩时长：${loc.duration}秒</div>
          
          <!-- 按钮 -->
          <div style="display:flex;gap:10px;">
            <button onclick="closePlayConfirm()" style="flex:1;padding:12px;border:none;border-radius:12px;background:#f3f4f6;color:#666;font-size:14px;font-weight:700;cursor:pointer;">取消</button>
            <button onclick="startPetPlay('${loc.id}');closePlayConfirm();" style="flex:2;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,${loc.color},${loc.color}cc);color:#fff;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px ${loc.color}66;">🚀 出发！</button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // 移除已存在的弹窗
  const oldModal = document.getElementById('playConfirmMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
}

// 关闭游玩确认弹窗（带淡出动画）
function closePlayConfirm(){
  const modal = document.getElementById('playConfirmMask');
  if(!modal) return;
  modal.classList.add('closing');
  document.body.style.overflow='';
  setTimeout(() => {
    if(modal.parentNode) modal.parentNode.removeChild(modal);
  }, 200);
}

// 渲染收藏品展柜
function renderCollections(){
  const container = document.getElementById('collectionDisplay');
  const progressEl = document.getElementById('collectionProgress');
  if(!container) return;
  
  const collections = lsGet('pet_collections', {});
  const allCollectibles = Object.keys(PET_COLLECTIBLES);
  const obtainedCount = allCollectibles.filter(c => collections[c] > 0).length;
  
  if(progressEl) progressEl.textContent = `${obtainedCount}/${allCollectibles.length}`;
  
  container.innerHTML = allCollectibles.map(c => {
    const count = collections[c] || 0;
    const obtained = count > 0;
    const info = PET_COLLECTIBLES[c];
    return `
      <div onclick="showCollectibleDetail('${c}')" style="text-align:center;padding:8px 4px;background:${obtained ? 'rgba(255,255,255,0.6)' : 'rgba(0,0,0,0.1)'};border-radius:10px;position:relative;cursor:pointer;" title="${info?.name || c}（${info?.location || '未知'}）">
        <div style="font-size:24px;${obtained ? '' : 'filter:grayscale(100%);opacity:0.4;'}">${c}</div>
        ${obtained ? `<div style="font-size:10px;color:#92400e;font-weight:600;margin-top:2px;">×${count}</div>` : `<div style="font-size:10px;color:#999;margin-top:2px;">未获得</div>`}
      </div>
    `;
  }).join('');
}

// 渲染全部收藏品展柜页面
function renderAllCollections(){
  const container = document.getElementById('allCollectionContent');
  const countEl = document.getElementById('allCollectionCount');
  if(!container) return;
  
  const collections = lsGet('pet_collections', {});
  const history = lsGet('pet_collection_history', []);
  const allCollectibles = Object.keys(PET_COLLECTIBLES);
  const obtainedCount = allCollectibles.filter(c => collections[c] > 0).length;
  
  if(countEl) countEl.textContent = obtainedCount;
  const totalEl = document.getElementById('allCollectionTotal');
  if(totalEl) totalEl.textContent = allCollectibles.length;
  
  // 按地点分组
  const locations = {};
  allCollectibles.forEach(c => {
    const info = PET_COLLECTIBLES[c];
    const loc = info?.location || '未知';
    if(!locations[loc]) locations[loc] = [];
    locations[loc].push(c);
  });
  
  // 地点对应的emoji
  const locationEmojis = {'公园':'🌳','商场':'🏬','海边':'🏖️','游乐场':'🎡','电影院':'🎬'};
  
  container.innerHTML = Object.keys(locations).map(loc => {
    const items = locations[loc];
    const locObtained = items.filter(c => collections[c] > 0).length;
    return `
      <div style="margin-bottom:18px;background:#fff;border-radius:14px;padding:14px;box-shadow:0 2px 10px rgba(0,0,0,0.05);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
          <div style="font-size:15px;font-weight:700;color:#333;">${locationEmojis[loc] || '📍'} ${loc}</div>
          <div style="font-size:12px;color:#999;">${locObtained}/${items.length}</div>
        </div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;">
          ${items.map(c => {
            const count = collections[c] || 0;
            const obtained = count > 0;
            const info = PET_COLLECTIBLES[c];
            // 查找首次获得时间
            const firstGet = history.find(h => h.collectible === c);
            const timeStr = firstGet ? formatTime(firstGet.time) : '';
            return `
              <div onclick="showCollectibleDetail('${c}')" style="text-align:center;padding:12px 8px;background:${obtained ? 'linear-gradient(135deg,#fef3c7,#fde68a)' : '#f5f5f5'};border-radius:12px;cursor:pointer;">
                <div style="font-size:32px;${obtained ? '' : 'filter:grayscale(100%);opacity:0.3;'}">${c}</div>
                <div style="font-size:12px;font-weight:600;color:${obtained ? '#92400e' : '#999'};margin-top:6px;">${info?.name || c}</div>
                ${obtained ? `
                  <div style="font-size:11px;color:#b45309;margin-top:2px;">×${count}</div>
                  <div style="font-size:10px;color:#d97706;margin-top:2px;">${timeStr}</div>
                ` : `<div style="font-size:10px;color:#bbb;margin-top:4px;">未获得</div>`}
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `;
  }).join('');
}

// 渲染收藏品获得记录
function renderCollectionHistory(){
  const container = document.getElementById('collectionHistoryContent');
  if(!container) return;
  
  const history = lsGet('pet_collection_history', []);
  
  if(history.length === 0){
    container.innerHTML = `
      <div style="text-align:center;padding:60px 20px;color:#999;">
        <div style="font-size:48px;margin-bottom:12px;">📭</div>
        <div style="font-size:14px;">还没有获得记录哦~</div>
        <div style="font-size:12px;margin-top:6px;">带小橘出去玩收集纪念品吧！</div>
      </div>
    `;
    return;
  }
  
  // 按时间倒序
  const sorted = [...history].sort((a, b) => b.time - a.time);
  
  container.innerHTML = `
    <div style="font-size:12px;color:#999;margin-bottom:10px;">共 ${history.length} 条获得记录</div>
    <div style="background:#fff;border-radius:14px;overflow:hidden;box-shadow:0 2px 10px rgba(0,0,0,0.05);">
      ${sorted.map((item, index) => {
        const info = PET_COLLECTIBLES[item.collectible];
        return `
          <div style="display:flex;align-items:center;padding:12px 14px;${index < sorted.length - 1 ? 'border-bottom:1px solid #f0f0f0;' : ''}">
            <div style="font-size:28px;margin-right:12px;">${item.collectible}</div>
            <div style="flex:1;">
              <div style="font-size:14px;font-weight:600;color:#333;">${info?.name || item.collectible}</div>
              <div style="font-size:11px;color:#999;margin-top:2px;">在${item.location}获得</div>
            </div>
            <div style="text-align:right;">
              <div style="font-size:11px;color:#666;">${formatTime(item.time)}</div>
              <div style="font-size:10px;color:#bbb;margin-top:2px;">${formatDate(item.time)}</div>
            </div>
          </div>
        `;
      }).join('')}
    </div>
  `;
}

// 清空获得记录
function clearCollectionHistory(){
  if(!confirm('确定要清空所有获得记录吗？（收藏品数量不会清空）')) return;
  lsSet('pet_collection_history', []);
  renderCollectionHistory();
  showToast('获得记录已清空~');
}

// 格式化时间（HH:MM）
function formatTime(timestamp){
  const d = new Date(timestamp);
  return `${String(d.getHours()).padStart(2,'0')}:${String(d.getMinutes()).padStart(2,'0')}`;
}

// 格式化日期（MM-DD）
function formatDate(timestamp){
  const d = new Date(timestamp);
  return `${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
}

// 显示收藏品说明弹窗
function showCollectibleDetail(emoji){
  const info = PET_COLLECTIBLES[emoji];
  if(!info) return;
  
  const collections = lsGet('pet_collections', {});
  const count = collections[emoji] || 0;
  const obtained = count > 0;
  
  // 查找首次获得时间
  const history = lsGet('pet_collection_history', []);
  const firstGet = history.find(h => h.collectible === emoji);
  const firstTimeStr = firstGet ? `${formatDate(firstGet.time)} ${formatTime(firstGet.time)}` : '未获得';
  
  // 地点对应的emoji
  const locationEmojis = {'公园':'🌳','商场':'🏬','海边':'🏖️','游乐场':'🎡','电影院':'🎬'};
  
  const modalHtml = `
    <div class="modal-mask" id="collectibleDetailMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;z-index:99999;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:340px;width:90%;padding:0;overflow:hidden;border-radius:20px;box-shadow:0 20px 60px rgba(0,0,0,0.3);">
        <button class="modal-close-btn" type="button" aria-label="关闭收藏品详情" onclick="closeCollectibleDetail()" style="position:absolute;top:12px;right:12px;z-index:2;">✕</button>
        <!-- 顶部区域 -->
        <div style="background:${obtained ? 'linear-gradient(135deg,#fef3c7,#fde68a)' : 'linear-gradient(135deg,#f3f4f6,#e5e7eb)'};padding:28px 20px;text-align:center;">
          <div style="font-size:64px;${obtained ? '' : 'filter:grayscale(100%);opacity:0.5;'}">${emoji}</div>
          <div style="font-size:20px;font-weight:700;color:${obtained ? '#92400e' : '#666'};margin-top:10px;">${info.name}</div>
          <div style="font-size:12px;color:${obtained ? '#b45309' : '#999'};margin-top:4px;">${locationEmojis[info.location] || '📍'} ${info.location}</div>
        </div>
        
        <!-- 详情区域 -->
        <div style="padding:18px;background:#fff;">
          <!-- 描述 -->
          <div style="background:${obtained ? '#fffbeb' : '#f9fafb'};border-radius:12px;padding:12px;margin-bottom:14px;">
            <div style="font-size:11px;font-weight:600;color:${obtained ? '#92400e' : '#999'};margin-bottom:6px;">📝 收藏品介绍</div>
            <div style="font-size:13px;color:${obtained ? '#78350f' : '#666'};line-height:1.6;">${info.desc}</div>
          </div>
          
          <!-- 统计信息 -->
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
            <div style="background:#f9fafb;border-radius:10px;padding:10px;text-align:center;">
              <div style="font-size:11px;color:#999;">获得数量</div>
              <div style="font-size:18px;font-weight:700;color:${obtained ? '#f59e0b' : '#999'};margin-top:2px;">${obtained ? '×' + count : '未获得'}</div>
            </div>
            <div style="background:#f9fafb;border-radius:10px;padding:10px;text-align:center;">
              <div style="font-size:11px;color:#999;">首次获得</div>
              <div style="font-size:13px;font-weight:600;color:${obtained ? '#666' : '#999'};margin-top:4px;">${firstTimeStr}</div>
            </div>
          </div>
          
          <!-- 关闭按钮 -->
          <button onclick="closeCollectibleDetail()" style="width:100%;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#fff;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.4);">
            ${obtained ? '知道啦~' : '去收集！'}
          </button>
        </div>
      </div>
    </div>
  `;
  
  // 移除已存在的弹窗
  const oldModal = document.getElementById('collectibleDetailMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
}

// 关闭收藏品说明弹窗（带淡出动画）
function closeCollectibleDetail(){
  const modal = document.getElementById('collectibleDetailMask');
  if(!modal) return;
  modal.classList.add('closing');
  document.body.style.overflow='';
  setTimeout(() => {
    if(modal.parentNode) modal.parentNode.removeChild(modal);
  }, 200);
}

// 开始出去玩
function startPetPlay(locationId){
  const loc = PET_PLAY_LOCATIONS.find(l => l.id === locationId);
  if(!loc) return;
  currentPlayLocation = loc;
  
  // 扣除状态
  lsSet('pet_hunger', Math.max(0, lsGet('pet_hunger', 50) - loc.hungerCost));
  lsSet('pet_clean', Math.max(0, lsGet('pet_clean', 100) - loc.cleanCost));
  
  // 设置游玩状态
  const playData = {
    locationId: loc.id,
    startTime: Date.now(),
    duration: loc.duration * 1000,
    endTime: Date.now() + loc.duration * 1000
  };
  lsSet('pet_play_data', playData);
  
  // 更新UI
  updatePlayUI();
  if(typeof playSound === 'function') playSound('success');
  showToast(`小橘去${loc.name}玩啦~`);
}

// 更新出去玩UI
function updatePlayUI(){
  const playData = lsGet('pet_play_data', null);
  const awayArea = document.getElementById('playAwayArea');
  const listArea = document.getElementById('playLocationList');
  
  if(playData && Date.now() < playData.endTime){
    if(awayArea) awayArea.style.display = 'block';
    if(listArea) listArea.style.display = 'none';
    const loc = PET_PLAY_LOCATIONS.find(l => l.id === playData.locationId);
    if(loc){
      const awayEmoji = document.getElementById('playAwayEmoji');
      const awayText = document.getElementById('playAwayText');
      const awayReward = document.getElementById('playAwayReward');
      if(awayEmoji) awayEmoji.textContent = loc.emoji;
      if(awayText) awayText.textContent = `小橘正在${loc.name}玩耍...`;
      if(awayReward) awayReward.textContent = `预计好感 +${loc.affectionGain}，金币 ${loc.coinMin}-${loc.coinMax}`;
    }
    startPlayTimer();
  }else{
    if(awayArea) awayArea.style.display = 'none';
    if(listArea) listArea.style.display = 'grid';
    if(petPlayTimer){
      clearInterval(petPlayTimer);
      petPlayTimer = null;
    }
    renderPlayLocations();
  }
  updatePetStatusDisplay('play');
}

// 启动游玩计时器
function startPlayTimer(){
  if(petPlayTimer) clearInterval(petPlayTimer);
  petPlayTimer = setInterval(() => {
    const playData = lsGet('pet_play_data', null);
    if(!playData){
      clearInterval(petPlayTimer);
      petPlayTimer = null;
      return;
    }
    const remaining = Math.max(0, playData.endTime - Date.now());
    const mins = Math.floor(remaining / 60000);
    const secs = Math.floor((remaining % 60000) / 1000);
    const timeStr = `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    
    // 更新出去玩页面倒计时
    const timerEl = document.getElementById('playAwayTimer');
    if(timerEl) timerEl.textContent = timeStr;
    
    // 更新状态页面倒计时
    const statusTimerEl = document.getElementById('statusPetAwayTimer');
    if(statusTimerEl) statusTimerEl.textContent = timeStr;
    
    if(remaining <= 0){
      completePetPlay();
    }
  }, 500);
}

// 完成出去玩
function completePetPlay(){
  const playData = lsGet('pet_play_data', null);
  if(!playData) return;
  const loc = PET_PLAY_LOCATIONS.find(l => l.id === playData.locationId);
  if(!loc) return;
  
  // 增加好感度
  const currentAffection = lsGet('pet_affection', 50);
  lsSet('pet_affection', Math.min(100, currentAffection + loc.affectionGain));
  
  // 随机金币奖励
  const coinReward = Math.floor(Math.random() * (loc.coinMax - loc.coinMin + 1)) + loc.coinMin;
  bpAddCoins(coinReward, 'play');
  
  // 战力奖励
  if(loc.powerGain > 0){
    const currentPower = lsGet('pet_power', 0);
    lsSet('pet_power', currentPower + loc.powerGain);
    const totalGained = lsGet('pet_total_gained_power', 0);
    lsSet('pet_total_gained_power', totalGained + loc.powerGain);
  }
  
  // 收藏品奖励（50%概率获得，使用必出收藏品卡则必定获得）
  let obtainedCollectible = null;
  const guaranteedCollectible = lsGet('pet_guaranteed_collectible', false);
  const shouldGetCollectible = guaranteedCollectible || Math.random() < 0.5;
  if(shouldGetCollectible && loc.collectibles && loc.collectibles.length > 0){
    obtainedCollectible = loc.collectibles[Math.floor(Math.random() * loc.collectibles.length)];
    const collections = lsGet('pet_collections', {});
    collections[obtainedCollectible] = (collections[obtainedCollectible] || 0) + 1;
    lsSet('pet_collections', collections);
    
    // 记录获得历史
    const history = lsGet('pet_collection_history', []);
    history.push({
      collectible: obtainedCollectible,
      location: loc.name,
      time: Date.now()
    });
    lsSet('pet_collection_history', history);
    
    // 清除必出收藏品标记
    if(guaranteedCollectible){
      lsSet('pet_guaranteed_collectible', false);
    }
  }
  
  // 清除游玩数据
  lsSet('pet_play_data', null);
  currentPlayLocation = null;
  
  // 清除定时器
  if(petPlayTimer){
    clearInterval(petPlayTimer);
    petPlayTimer = null;
  }
  
  // 更新UI
  updatePlayUI();
  if(typeof playSound === 'function') playSound('success');
  
  let rewardMsg = `小橘从${loc.name}回来啦~ 💕+${loc.affectionGain}好感，💰+${coinReward}金币`;
  if(loc.powerGain > 0) rewardMsg += `，⚔️+${loc.powerGain}战力`;
  if(obtainedCollectible) rewardMsg += `，🏆获得收藏品${obtainedCollectible}`;
  showToast(rewardMsg);
}

// 从游玩中召回宠物
function recallPetFromPlay(){
  const playData = lsGet('pet_play_data', null);
  if(!playData) return;
  lsSet('pet_play_data', null);
  currentPlayLocation = null;
  if(petPlayTimer){
    clearInterval(petPlayTimer);
    petPlayTimer = null;
  }
  updatePlayUI();
  if(typeof playSound === 'function') playSound('click');
  showToast('小橘被召回啦~');
}

let petSchoolTimer = null;

// 初始化宠物战力、清洁值和毕业次数
function initPetPower(){
  if(lsGet('pet_power', null) === null){
    lsSet('pet_power', 0);
  }
  if(lsGet('pet_clean', null) === null){
    lsSet('pet_clean', 100);
  }
  if(lsGet('pet_school_counts', null) === null){
    lsSet('pet_school_counts', {});
  }
}

// 检查学校是否解锁
function isSchoolUnlocked(schoolId){
  const school = PET_SCHOOLS.find(s => s.id === schoolId);
  if(!school || !school.unlockSchool) return true;
  const counts = lsGet('pet_school_counts', {});
  const requiredCount = school.unlockCount;
  const currentCount = counts[school.unlockSchool] || 0;
  return currentCount >= requiredCount;
}

// 获取学校解锁进度
function getSchoolUnlockProgress(schoolId){
  const school = PET_SCHOOLS.find(s => s.id === schoolId);
  if(!school || !school.unlockSchool) return {current:0, required:0, percent:100};
  const counts = lsGet('pet_school_counts', {});
  const requiredCount = school.unlockCount;
  const currentCount = Math.min(counts[school.unlockSchool] || 0, requiredCount);
  return {current:currentCount, required:requiredCount, percent:Math.floor(currentCount/requiredCount*100)};
}

// 更新宠物状态显示（状态页面和上学页面）
function updatePetStatusDisplay(){
  const power = lsGet('pet_power', 0);
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  const cleanPercent = Math.max(0, Math.min(100, clean));
  const affectionPercent = Math.max(0, Math.min(100, affection));
  
  // 根据饱食度和清洁值更新心情和表情
  let mood, emoji;
  if(hungerPercent >= 80 && cleanPercent >= 80){ mood='吃饱喝足，超级开心~'; emoji='😺'; }
  else if(hungerPercent >= 50 && cleanPercent >= 50){ mood='心情不错~'; emoji='🐱'; }
  else if(hungerPercent >= 20 && cleanPercent >= 20){ mood='有点饿了/该洗澡了...'; emoji='😿'; }
  else{ mood='快饿晕啦/脏死啦，快照顾我！'; emoji='😾'; }
  
  if(cleanPercent < 30){ emoji = '🥺'; mood = '脏死啦，快给我洗澡！'; }
  
  // 状态页面
  const elStatusPower = document.getElementById('statusPetPower');
  const elStatusEmoji = document.getElementById('statusPetEmoji');
  const elStatusMood = document.getElementById('statusPetMood');
  const elStatusHungerText = document.getElementById('statusHungerText');
  const elStatusHungerBar = document.getElementById('statusHungerBar');
  const elStatusCleanText = document.getElementById('statusCleanText');
  const elStatusCleanBar = document.getElementById('statusCleanBar');
  const elStatusAffectionText = document.getElementById('statusAffectionText');
  const elStatusAffectionBar = document.getElementById('statusAffectionBar');
  if(elStatusPower) elStatusPower.textContent = power;
  if(elStatusEmoji) elStatusEmoji.textContent = emoji;
  if(elStatusMood) elStatusMood.textContent = mood;
  if(elStatusHungerText) elStatusHungerText.textContent = hungerPercent + '/100';
  if(elStatusHungerBar) elStatusHungerBar.style.width = hungerPercent + '%';
  if(elStatusCleanText) elStatusCleanText.textContent = cleanPercent + '/100';
  if(elStatusCleanBar) elStatusCleanBar.style.width = cleanPercent + '%';
  if(elStatusAffectionText) elStatusAffectionText.textContent = affectionPercent + '/100';
  if(elStatusAffectionBar) elStatusAffectionBar.style.width = affectionPercent + '%';
  
  // 上学页面
  const elSchoolPower = document.getElementById('schoolPetPower');
  const elSchoolEmoji = document.getElementById('schoolPetEmoji');
  const elSchoolMood = document.getElementById('schoolPetMood');
  const elSchoolCoins = document.getElementById('schoolCoins');
  const elSchoolHungerText = document.getElementById('schoolHungerText');
  const elSchoolHungerBar = document.getElementById('schoolHungerBar');
  const elSchoolCleanText = document.getElementById('schoolCleanText');
  const elSchoolCleanBar = document.getElementById('schoolCleanBar');
  const elSchoolAffectionText = document.getElementById('schoolAffectionText');
  const elSchoolAffectionBar = document.getElementById('schoolAffectionBar');
  if(elSchoolPower) elSchoolPower.textContent = power;
  if(elSchoolEmoji) elSchoolEmoji.textContent = emoji;
  if(elSchoolMood) elSchoolMood.textContent = mood;
  if(elSchoolCoins) elSchoolCoins.textContent = bpGetCoins();
  if(elSchoolHungerText) elSchoolHungerText.textContent = hungerPercent + '/100';
  if(elSchoolHungerBar) elSchoolHungerBar.style.width = hungerPercent + '%';
  if(elSchoolCleanText) elSchoolCleanText.textContent = cleanPercent + '/100';
  if(elSchoolCleanBar) elSchoolCleanBar.style.width = cleanPercent + '%';
  if(elSchoolAffectionText) elSchoolAffectionText.textContent = affectionPercent + '/100';
  if(elSchoolAffectionBar) elSchoolAffectionBar.style.width = affectionPercent + '%';
  
  // 出去玩页面
  const elPlayPower = document.getElementById('playPetPower');
  const elPlayEmoji = document.getElementById('playPetEmoji');
  const elPlayMood = document.getElementById('playPetMood');
  const elPlayCoins = document.getElementById('playCoins');
  const elPlayHungerText = document.getElementById('playHungerText');
  const elPlayHungerBar = document.getElementById('playHungerBar');
  const elPlayCleanText = document.getElementById('playCleanText');
  const elPlayCleanBar = document.getElementById('playCleanBar');
  const elPlayAffectionText = document.getElementById('playAffectionText');
  const elPlayAffectionBar = document.getElementById('playAffectionBar');
  if(elPlayPower) elPlayPower.textContent = power;
  if(elPlayEmoji) elPlayEmoji.textContent = emoji;
  if(elPlayMood) elPlayMood.textContent = mood;
  if(elPlayCoins) elPlayCoins.textContent = bpGetCoins();
  if(elPlayHungerText) elPlayHungerText.textContent = hungerPercent + '/100';
  if(elPlayHungerBar) elPlayHungerBar.style.width = hungerPercent + '%';
  if(elPlayCleanText) elPlayCleanText.textContent = cleanPercent + '/100';
  if(elPlayCleanBar) elPlayCleanBar.style.width = cleanPercent + '%';
  if(elPlayAffectionText) elPlayAffectionText.textContent = affectionPercent + '/100';
  if(elPlayAffectionBar) elPlayAffectionBar.style.width = affectionPercent + '%';
  
  // 检查宠物是否在上学或出去玩或打工
  const schoolData = lsGet('pet_school_data', null);
  const playData = lsGet('pet_play_data', null);
  const workData = lsGet('pet_work_data', null);
  const elHomeArea = document.getElementById('statusPetHomeArea');
  const elAwayArea = document.getElementById('statusPetAwayArea');
  const elSchoolListArea = document.getElementById('schoolListArea');
  const elSchoolAwayArea = document.getElementById('schoolAwayArea');
  
  if(playData && playData.endTime > Date.now()){
    // 宠物正在出去玩
    if(elHomeArea) elHomeArea.style.display = 'none';
    if(elAwayArea) elAwayArea.style.display = 'block';
    if(elSchoolListArea) elSchoolListArea.style.display = 'none';
    if(elSchoolAwayArea) elSchoolAwayArea.style.display = 'none';
    
    const loc = PET_PLAY_LOCATIONS.find(l => l.id === playData.locationId);
    if(loc){
      const elAwayText = document.getElementById('statusPetAwayText');
      if(elAwayText) elAwayText.textContent = '小橘正在' + loc.name + '玩耍...';
    }
    // 修改召回按钮为游玩召回
    const recallBtn = document.querySelector('#statusPetAwayArea button');
    if(recallBtn){
      recallBtn.style.display = 'block';
      recallBtn.textContent = '🏠 召回宠物';
      recallBtn.onclick = recallPetFromPlay;
    }
    // 修改使用道具按钮为出去玩道具
    const allBtns = document.querySelectorAll('#statusPetAwayArea button');
    if(allBtns.length > 1){
      allBtns[1].style.display = 'block';
      allBtns[1].textContent = '✨ 使用道具';
      allBtns[1].setAttribute('onclick', 'showPlaySuperItemPanel()');
      allBtns[1].onclick = showPlaySuperItemPanel;
    }
    // 更新倒计时
    const remaining = Math.max(0, playData.endTime - Date.now());
    const timerEl = document.getElementById('statusPetAwayTimer');
    if(timerEl){
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timerEl.textContent = `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    }
  } else if(workData && workData.endTime > Date.now()){
    // 宠物正在打工
    if(elHomeArea) elHomeArea.style.display = 'none';
    if(elAwayArea) elAwayArea.style.display = 'block';
    if(elSchoolListArea) elSchoolListArea.style.display = 'none';
    if(elSchoolAwayArea) elSchoolAwayArea.style.display = 'none';
    
    const job = PET_JOBS.find(j => j.id === workData.jobId);
    if(job){
      const elAwayText = document.getElementById('statusPetAwayText');
      if(elAwayText) elAwayText.textContent = '小橘正在' + job.name + '打工...';
    }
    // 召回按钮
    const recallBtn = document.querySelector('#statusPetAwayArea button');
    if(recallBtn){
      recallBtn.style.display = 'block';
      recallBtn.textContent = '🏠 召回宠物（不获得工资）';
      recallBtn.onclick = recallPetWork;
    }
    // 隐藏使用道具按钮（打工没有道具）
    const allBtns = document.querySelectorAll('#statusPetAwayArea button');
    if(allBtns.length > 1){
      allBtns[1].style.display = 'none';
    }
    // 更新倒计时
    const remaining = Math.max(0, workData.endTime - Date.now());
    const timerEl = document.getElementById('statusPetAwayTimer');
    if(timerEl){
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timerEl.textContent = `${String(mins).padStart(2,'0')}:${String(secs).padStart(2,'0')}`;
    }
  } else if(schoolData && schoolData.endTime > Date.now()){
    // 宠物正在上学
    if(elHomeArea) elHomeArea.style.display = 'none';
    if(elAwayArea) elAwayArea.style.display = 'block';
    if(elSchoolListArea) elSchoolListArea.style.display = 'none';
    if(elSchoolAwayArea) elSchoolAwayArea.style.display = 'block';
    
    const school = PET_SCHOOLS.find(s => s.id === schoolData.schoolId);
    if(school){
      const elAwayText = document.getElementById('statusPetAwayText');
      const elSchoolAwayText = document.getElementById('schoolAwayText');
      const elSchoolAwayReward = document.getElementById('schoolAwayReward');
      if(elAwayText) elAwayText.textContent = '小橘正在' + school.name + '上学...';
      if(elSchoolAwayText) elSchoolAwayText.textContent = '小橘正在' + school.name + '上学...';
      if(elSchoolAwayReward) elSchoolAwayReward.textContent = '预计战力 +' + school.power;
    }
    // 恢复上学召回按钮
    const recallBtn = document.querySelector('#statusPetAwayArea button');
    if(recallBtn){
      recallBtn.style.display = 'block';
      recallBtn.textContent = '🏠 召回宠物（退还一半金币）';
      recallBtn.onclick = recallPet;
    }
    // 显示使用道具按钮（恢复为上学道具）
    const allBtns = document.querySelectorAll('#statusPetAwayArea button');
    if(allBtns.length > 1){
      allBtns[1].style.display = 'block';
      allBtns[1].textContent = '✨ 使用道具';
      allBtns[1].setAttribute('onclick', 'showSuperItemPanel()');
      allBtns[1].onclick = showSuperItemPanel;
    }
  } else {
    // 宠物在家
    if(elHomeArea) elHomeArea.style.display = 'block';
    if(elAwayArea) elAwayArea.style.display = 'none';
    if(elSchoolListArea) elSchoolListArea.style.display = 'block';
    if(elSchoolAwayArea) elSchoolAwayArea.style.display = 'none';
  }
}

// 初始化宠物上学页面
function initPetSchool(){
  renderSchoolList();
  updatePetStatusDisplay();
  startPetSchoolTimer();
}

// 渲染学校列表
// 当前选中待确认的学校
let confirmSchoolId = null;

function renderSchoolList(){
  const container = document.getElementById('schoolList');
  if(!container) return;
  container.innerHTML = '';
  PET_SCHOOLS.forEach(school => {
    const unlocked = isSchoolUnlocked(school.id);
    const progress = getSchoolUnlockProgress(school.id);
    const isConfirming = confirmSchoolId === school.id;
    const div = document.createElement('div');
    if(unlocked){
      div.style.cssText = `background:var(--card-bg);border-radius:14px;padding:16px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;border-left:6px solid ${school.color};${isConfirming ? 'border:2px solid #667eea;' : ''}`;
      div.onmouseover = () => div.style.transform = 'translateX(4px)';
      div.onmouseout = () => div.style.transform = 'translateX(0)';
      div.onclick = () => toggleSchoolConfirm(school.id);
    } else {
      div.style.cssText = `background:#f5f5f5;border-radius:14px;padding:16px;cursor:not-allowed;box-shadow:0 2px 8px rgba(0,0,0,0.04);border-left:6px solid #ccc;opacity:0.7;`;
    }
    let extraInfo = '';
    if(!unlocked && school.unlockSchool){
      const unlockSchoolName = PET_SCHOOLS.find(s => s.id === school.unlockSchool)?.name || '';
      extraInfo = `
        <div style="margin-top:8px;padding:8px 12px;background:#fff3cd;border-radius:8px;">
          <div style="font-size:12px;color:#856404;font-weight:600;">🔒 需要${unlockSchoolName}毕业 ${progress.required} 次解锁</div>
          <div style="height:6px;background:#fff;border-radius:3px;margin-top:6px;overflow:hidden;">
            <div style="height:100%;background:#f59e0b;border-radius:3px;width:${progress.percent}%;"></div>
          </div>
          <div style="font-size:11px;color:#856404;margin-top:4px;text-align:right;">${progress.current}/${progress.required}</div>
        </div>
      `;
    }
    // 确认面板
    let confirmPanel = '';
    if(isConfirming && unlocked){
      const curHunger = lsGet('pet_hunger', 50);
      const curClean = lsGet('pet_clean', 100);
      const curAffection = lsGet('pet_affection', 50);
      const curCoins = bpGetCoins();
      const lackHunger = curHunger < 10;
      const lackClean = curClean < 10;
      const lackAffection = curAffection < 5;
      const lackCoins = curCoins < school.cost;
      const canConfirm = !lackHunger && !lackClean && !lackAffection && !lackCoins;
      const lackList = [];
      if(lackCoins) lackList.push('💰金币');
      if(lackHunger) lackList.push('🍖饱食度');
      if(lackClean) lackList.push('🧼清洁值');
      if(lackAffection) lackList.push('💕好感度');
      const warnText = canConfirm ? '' : `<div style="margin-top:8px;padding:6px 10px;background:#fef2f2;border-radius:6px;font-size:11px;color:#dc2626;font-weight:600;">⚠️ ${lackList.join('、')}不足，无法上学</div>`;
      const confirmBtnStyle = canConfirm 
        ? 'background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;cursor:pointer;box-shadow:0 2px 6px rgba(102,126,234,0.3);'
        : 'background:#d1d5db;color:#9ca3af;cursor:not-allowed;';
      confirmPanel = `
        <div style="margin-top:12px;padding:12px;background:linear-gradient(135deg,#eef2ff,#fdf4ff);border-radius:10px;border:1px dashed #667eea;" onclick="event.stopPropagation();">
          <div style="font-size:13px;font-weight:700;color:#4c51bf;margin-bottom:8px;">📋 上学消耗确认</div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;font-size:12px;">
            <div style="color:#666;${lackCoins ? 'background:#fef2f2;padding:2px 4px;border-radius:4px;' : ''}">💰 消耗金币：<span style="color:${lackCoins ? '#dc2626' : '#f59e0b'};font-weight:600;">-${school.cost}${lackCoins ? ' (不足)' : ''}</span></div>
            <div style="color:#666;">⏱️ 上学时长：<span style="color:#667eea;font-weight:600;">${school.duration}秒</span></div>
            <div style="color:#666;${lackHunger ? 'background:#fef2f2;padding:2px 4px;border-radius:4px;' : ''}">🍖 饱食度：<span style="color:${lackHunger ? '#dc2626' : '#ef4444'};font-weight:600;">-10${lackHunger ? ' (不足)' : ''}</span></div>
            <div style="color:#666;${lackClean ? 'background:#fef2f2;padding:2px 4px;border-radius:4px;' : ''}">🧼 清洁值：<span style="color:${lackClean ? '#dc2626' : '#3b82f6'};font-weight:600;">-10${lackClean ? ' (不足)' : ''}</span></div>
            <div style="color:#666;${lackAffection ? 'background:#fef2f2;padding:2px 4px;border-radius:4px;' : ''}">💕 好感度：<span style="color:${lackAffection ? '#dc2626' : '#ec4899'};font-weight:600;">-5${lackAffection ? ' (不足)' : ''}</span></div>
            <div style="color:#666;">⚔️ 获得战力：<span style="color:#10b981;font-weight:600;">+${school.power}</span></div>
          </div>
          ${warnText}
          <div style="display:flex;gap:8px;margin-top:10px;">
            <button ${canConfirm ? `onclick="confirmSendToSchool('${school.id}')"` : 'disabled'} style="flex:1;border:none;padding:8px;border-radius:8px;font-size:13px;font-weight:700;${confirmBtnStyle}">
              ✅ 确认上学
            </button>
            <button onclick="cancelSchoolConfirm()" style="flex:1;background:#e5e7eb;color:#666;border:none;padding:8px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer;">
              ❌ 取消
            </button>
          </div>
        </div>
      `;
    }
    div.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;">
        <div style="display:flex;align-items:center;">
          <div style="font-size:32px;filter:${unlocked ? 'none' : 'grayscale(100%)'};">${unlocked ? school.emoji : '🔒'}</div>
          <div style="margin-left:12px;">
            <div style="font-size:16px;font-weight:700;">${school.name}</div>
            <div style="font-size:12px;color:#666;margin-top:2px;">⏱️ ${school.duration}秒 · ⚔️ 战力+${school.power}</div>
          </div>
        </div>
        <div style="background:${unlocked ? '#fef3c7' : '#e0e0e0'};color:${unlocked ? '#f59e0b' : '#999'};padding:6px 14px;border-radius:12px;font-size:14px;font-weight:700;">
          💰 ${school.cost}
        </div>
      </div>
      ${extraInfo}
      ${confirmPanel}
    `;
    container.appendChild(div);
  });
}

// 切换学校确认面板
function toggleSchoolConfirm(schoolId){
  if(confirmSchoolId === schoolId){
    confirmSchoolId = null;
  } else {
    confirmSchoolId = schoolId;
  }
  renderSchoolList();
}

// 取消学校确认
function cancelSchoolConfirm(){
  confirmSchoolId = null;
  renderSchoolList();
}

// 确认送宠物去上学
function confirmSendToSchool(schoolId){
  confirmSchoolId = null;
  renderSchoolList();
  sendPetToSchool(schoolId);
}

// 送宠物去上学
function sendPetToSchool(schoolId){
  const school = PET_SCHOOLS.find(s => s.id === schoolId);
  if(!school) return;
  
  // 检查学校是否解锁
  if(!isSchoolUnlocked(schoolId)){
    const progress = getSchoolUnlockProgress(schoolId);
    const unlockSchoolName = PET_SCHOOLS.find(s => s.id === school.unlockSchool)?.name || '';
    showToast(`🔒 ${school.name}未解锁，需要${unlockSchoolName}毕业${progress.required}次（当前${progress.current}/${progress.required}）`);
    return;
  }
  
  const coins = bpGetCoins();
  if(coins < school.cost){
    showToast('金币不足，去玩游戏赚金币吧~');
    return;
  }
  
  // 检查状态是否足够抵扣上学消耗
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  const lackStats = [];
  if(hunger < 10) lackStats.push('🍖饱食度');
  if(clean < 10) lackStats.push('🧼清洁值');
  if(affection < 5) lackStats.push('💕好感度');
  if(lackStats.length > 0){
    showToast('⚠️ 状态不足无法上学！' + lackStats.join('、') + '太低了，先照顾小橘吧~');
    return;
  }
  
  // 扣除金币
  lsSet('backpack_coins', coins - school.cost);
  
  // 记录上学数据
  const schoolData = {
    schoolId: school.id,
    startTime: Date.now(),
    endTime: Date.now() + school.duration * 1000
  };
  lsSet('pet_school_data', schoolData);
  
  // 扣除饱食度和清洁值（上学消耗体力和变脏）
  lsSet('pet_hunger', Math.max(0, hunger - 10));
  lsSet('pet_clean', Math.max(0, clean - 10));
  // 减少好感度（上学没时间陪小橘玩）
  lsSet('pet_affection', Math.max(0, affection - 5));
  
  showToast('小橘去' + school.name + '上学啦！');
  updatePetStatusDisplay();
  startPetSchoolTimer();
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_pet_school', 1);
}

// 召回宠物
function recallPet(){
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData) return;
  
  const school = PET_SCHOOLS.find(s => s.id === schoolData.schoolId);
  if(!school) return;
  
  // 退还一半金币
  const refund = Math.floor(school.cost / 2);
  const coins = bpGetCoins();
  lsSet('backpack_coins', coins + refund);
  
  // 清除上学数据
  lsSet('pet_school_data', null);
  
  // 停止倒计时
  if(petSchoolTimer){
    clearInterval(petSchoolTimer);
    petSchoolTimer = null;
  }
  
  showToast('小橘被召回啦！退还' + refund + '金币（不获得战力）');
  updatePetStatusDisplay();
  if(typeof bpUpdateHomeBadge === 'function') bpUpdateHomeBadge();
}

// 启动上学倒计时
function startPetSchoolTimer(){
  if(petSchoolTimer){
    clearInterval(petSchoolTimer);
    petSchoolTimer = null;
  }
  
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData || schoolData.endTime <= Date.now()){
    return;
  }
  
  updateSchoolTimerDisplay();
  
  petSchoolTimer = setInterval(() => {
    const data = lsGet('pet_school_data', null);
    if(!data || data.endTime <= Date.now()){
      // 上学结束
      clearInterval(petSchoolTimer);
      petSchoolTimer = null;
      completePetSchool();
      return;
    }
    updateSchoolTimerDisplay();
  }, 1000);
}

// 更新倒计时显示
function updateSchoolTimerDisplay(){
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData) return;
  
  const remaining = Math.max(0, Math.ceil((schoolData.endTime - Date.now()) / 1000));
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const timeStr = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  
  const elStatusTimer = document.getElementById('statusPetAwayTimer');
  const elSchoolTimer = document.getElementById('schoolAwayTimer');
  if(elStatusTimer) elStatusTimer.textContent = timeStr;
  if(elSchoolTimer) elSchoolTimer.textContent = timeStr;
}

// 完成上学，提升战力
function completePetSchool(){
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData) return;
  
  const school = PET_SCHOOLS.find(s => s.id === schoolData.schoolId);
  if(!school) return;
  
  // 提升战力（支持双倍战力卡）
  const power = lsGet('pet_power', 0);
  const doublePower = lsGet('pet_double_power_next', false);
  const gainedPower = doublePower ? school.power * 2 : school.power;
  lsSet('pet_power', power + gainedPower);
  if(doublePower) lsSet('pet_double_power_next', false);
  
  // 记录累计获得战力
  const totalGained = lsGet('pet_total_gained_power', 0);
  lsSet('pet_total_gained_power', totalGained + gainedPower);
  
  // 记录毕业次数
  const counts = lsGet('pet_school_counts', {});
  counts[school.id] = (counts[school.id] || 0) + 1;
  lsSet('pet_school_counts', counts);
  
  // 清除上学数据
  lsSet('pet_school_data', null);
  
  // 判断是否是最后一次升学（达到解锁下一级学校的次数）
  const nextSchool = PET_SCHOOLS.find(s => s.unlockSchool === school.id);
  const isFinalGraduation = !nextSchool || counts[school.id] === nextSchool.unlockCount;
  
  const powerText = doublePower ? `战力+${gainedPower}（双倍！）` : `战力+${gainedPower}`;
  if(isFinalGraduation){
    showToast('🎉 小橘从' + school.name + '毕业啦！' + powerText + '！');
  } else {
    showToast('🐱 小橘放学啦，回去抱抱她吧~ ' + powerText + '！');
  }
  
  updatePetStatusDisplay();
  renderSchoolList();
  if(typeof bpUpdateHomeBadge === 'function') bpUpdateHomeBadge();
  
  // 生成校长邮件
  generateSchoolMail(school, counts[school.id], isFinalGraduation);
}

