/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageDailyTaskPage", "<!-- pageDailyTaskPage -->\n<div class=\"tool-page\" id=\"pageDailyTaskPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"backFromDailyTask()\"><span>←</span> <span id=\"dailyTaskBackText\">返回</span></button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>📋 每日任务</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">每天0点自动刷新，签到+做任务领金币~</div>\n      \n      <!-- 签到区域 -->\n      <div class=\"fortune-today-card\" style=\"text-align:center;margin-bottom:14px;\">\n        <div id=\"checkinStatus\" style=\"font-size:15px;margin:12px 0;\"></div>\n        <div id=\"checkinWeek\" style=\"display:flex;gap:8px;justify-content:center;margin:16px 0;flex-wrap:wrap;\"></div>\n        <button class=\"common-btn\" id=\"checkinBtn\" onclick=\"checkinDo()\">✅ 签到</button>\n        <div style=\"margin-top:14px;font-size:13px;color:var(--text-secondary);line-height:1.9;\">\n          连续签到第 <b id=\"checkinStreak\" style=\"color:var(--primary);\"></b> 天 · \n          累计签到 <b id=\"checkinTotal\" style=\"color:var(--primary);\"></b> 天 · \n          共获得 <b id=\"checkinCoins\" style=\"color:var(--primary);\"></b> 金币<br>\n          <span style=\"font-size:12px;color:var(--text-placeholder);\">基础10金币，连签越多奖励越多！</span>\n        </div>\n      </div>\n      \n      <!-- 任务进度概览 -->\n      <div style=\"background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(245,158,11,0.15);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div>\n            <div style=\"font-size:14px;font-weight:700;color:#92400e;\">今日进度</div>\n            <div style=\"font-size:12px;color:#b45309;margin-top:2px;\" id=\"dailyTaskDate\">--</div>\n          </div>\n          <div style=\"text-align:right;\">\n            <div style=\"font-size:24px;font-weight:700;color:#d97706;\" id=\"dailyTaskProgress\">0/10</div>\n            <div style=\"font-size:11px;color:#b45309;\">已完成任务</div>\n          </div>\n        </div>\n        <div style=\"height:10px;background:rgba(255,255,255,0.5);border-radius:5px;overflow:hidden;margin-top:10px;\">\n          <div id=\"dailyTaskBar\" style=\"height:100%;background:linear-gradient(90deg,#f59e0b,#d97706);border-radius:5px;width:0%;transition:width 0.3s;\"></div>\n        </div>\n        <div style=\"display:flex;justify-content:space-between;margin-top:8px;\">\n          <span style=\"font-size:12px;color:#92400e;\">已领奖励：<span id=\"dailyTaskClaimed\">0</span> 💰</span>\n          <span style=\"font-size:12px;color:#92400e;\">可领奖励：<span id=\"dailyTaskTotal\">0</span> 💰</span>\n        </div>\n      </div>\n      \n      <!-- 任务列表 -->\n      <div id=\"dailyTaskList\" style=\"display:grid;gap:10px;\">\n        <!-- 任务由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ==================== 新增工具：每日签到 ====================
function checkinGetData(){
  return lsGet('checkin_data',{days:[],coins:0});
}
function checkinStreak(days){
  let streak=0;
  const d=new Date();
  while(true){
    const ds=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
    if(days.includes(ds)){streak++;d.setDate(d.getDate()-1);}
    else break;
  }
  return streak;
}
function checkinRender(){
  const data=checkinGetData();
  const today=getTodaySeed();
  const done=data.days.includes(today);
  const streak=checkinStreak(data.days);
  const status=document.getElementById('checkinStatus');
  const btn=document.getElementById('checkinBtn');
  if(status){
    status.innerHTML=done?'✅ 今日已签到，明天再来吧！':'☀️ 今日尚未签到，点击下方按钮领取金币！';
  }
  if(btn)btn.disabled=done;
  const s=document.getElementById('checkinStreak'),t=document.getElementById('checkinTotal'),c=document.getElementById('checkinCoins');
  if(s)s.textContent=streak;
  if(t)t.textContent=data.days.length;
  if(c)c.textContent=data.coins;
  const weekEl=document.getElementById('checkinWeek');
  if(weekEl){
    const days=['日','一','二','三','四','五','六'];
    let html='';
    for(let i=6;i>=0;i--){
      const d=new Date();d.setDate(d.getDate()-i);
      const ds=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();
      const isToday=(ds===today);
      const checked=data.days.includes(ds);
      html+='<div style="text-align:center;padding:8px 12px;background:'+(checked?'var(--primary)':'var(--bg-input)')+';border:1px solid '+(checked?'var(--primary)':'var(--border-color)')+';border-radius:10px;'+(isToday?'outline:2px solid var(--primary);outline-offset:2px;':'')+'">'+
        '<div style="font-size:11px;color:'+(checked?'#fff':'var(--text-secondary)')+';">周'+days[d.getDay()]+'</div>'+
        '<div style="font-size:17px;'+(checked?'color:#fff;':'color:var(--text-placeholder);')+'">'+(checked?'✓':'·')+'</div>'+
        '</div>';
    }
    weekEl.innerHTML=html;
  }
}
function checkinDo(){
  const data=checkinGetData();
  const today=getTodaySeed();
  if(data.days.includes(today)){showToast('今天已经签过到啦');return;}
  data.days.push(today);
  const streak=checkinStreak(data.days);
  const base=10;
  const bonus=Math.min(streak-1,5)*2;
  const reward=base+bonus;
  data.coins+=reward;
  lsSet('checkin_data',data);
  bpAddCoins(reward,'checkin');
  checkinRender();
  showToast('🎉 签到成功！连续'+streak+'天，获得'+reward+'金币');
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_checkin', 1);
  // 如果当前在每日任务页面，刷新
  if(pageDailyTaskPage && pageDailyTaskPage.style.display === 'block' && typeof renderDailyTasks === 'function'){
    renderDailyTasks();
  }
}

