/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageChestHome", "<!-- pageChestHome -->\n<div class=\"tool-page page-chest-home\" id=\"pageChestHome\">\n    <div class=\"sticky-nav\">\n    <div class=\"tool-header\" style=\"gap:6px;\">\n      <button class=\"back-btn\" onclick=\"goHome()\"><span>←</span> 返回首页</button>\n      <button type=\"button\" class=\"back-btn chest-help-btn\" title=\"百宝箱规则\" aria-label=\"百宝箱规则\" style=\"margin-left:auto;width:32px;height:40px;min-height:40px;padding:0;justify-content:center;background:var(--primary-bg);color:var(--primary);font-weight:700;border-radius:12px;\" onclick=\"openRuleModal()\">?</button>\n      <button class=\"back-btn chest-status-btn\" style=\"background:var(--primary-bg);color:var(--primary);font-weight:600;\" onclick=\"openChestTool('statusPage','个人状态')\">\n        📊 状态\n      </button>\n      \n    </div>\n    <div class=\"breadcrumb\"></div>\n    </div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px;\">\n      <div style=\"display:flex;align-items:center;justify-content:space-between;margin-bottom:4px;\"><h3 data-breadcrumb-title=\"百宝箱\" style=\"margin:0;\">🧰 趣味百宝箱</h3><button class=\"common-btn\" style=\"padding:6px 12px;font-size:13px;\" onclick=\"openPage('backpack')\">🎒 背包</button></div>\n      <div class=\"gold-tip\">✨ 金色边框的游戏可以赚金币哦～</div>\n      <div class=\"chest-quick-actions\" id=\"chestQuickActions\" style=\"justify-content:flex-start;\">\n        <button class=\"common-btn\" style=\"padding:4px 10px;font-size:12px;\" onclick=\"flOpenMysteryCodeModal()\">🔑 兑换</button>\n        <button class=\"common-btn chest-store-btn\" style=\"padding:4px 10px;font-size:12px;\" onclick=\"openChestTool('pinballShopPage','弹珠商店')\">🛒 store</button>\n      </div>\n      <div class=\"chest-welfare\" style=\"margin:4px 0 20px;padding:14px;border:1px solid #ffd700;border-radius:14px;background:linear-gradient(135deg,rgba(255,215,0,0.10),rgba(255,193,7,0.03));\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;\">\n          <h4 style=\"margin:0;font-size:14px;color:#b8860b;\">🎁 福利中心</h4>\n          <span style=\"font-size:11px;color:var(--text-secondary);\">每日任务 · 扭蛋 · 成就领金币</span>\n        </div>\n        <div style=\"display:grid;grid-template-columns:repeat(3,1fr);gap:8px;\">\n          <div class=\"chest-card gold\" style=\"padding:12px 6px;\" onclick=\"openChestTool('dailyTaskPage','每日任务')\">\n            <div class=\"icon\">📋</div><div class=\"title\" style=\"font-size:13px;white-space:nowrap;\">每日任务</div>\n          </div>\n          <div class=\"chest-card gold\" style=\"padding:12px 6px;\" onclick=\"openChestTool('capsulePage','扭蛋机')\">\n            <div class=\"icon\">🥚</div><div class=\"title\" style=\"font-size:13px;white-space:nowrap;\">扭蛋机</div>\n          </div>\n          <div class=\"chest-card gold\" style=\"padding:12px 6px;\" onclick=\"openChestTool('achievementPage','成就徽章')\">\n            <div class=\"icon\">🏅</div><div class=\"title\" style=\"font-size:13px;white-space:nowrap;\">成就徽章</div>\n          </div>\n        </div>\n      </div>\n      <div class=\"chest-categories\" id=\"chestCategories\" style=\"display:flex;align-items:center;flex-wrap:wrap;gap:8px;\">\n        <button class=\"chest-cat-btn cat-btn-item active\" data-cat=\"all\" onclick=\"filterChest('all')\">全部</button>\n        <button class=\"chest-cat-btn cat-btn-item\" data-cat=\"game\" onclick=\"filterChest('game')\">🎮 游戏</button>\n        <button class=\"chest-cat-btn cat-btn-item\" data-cat=\"fun\" onclick=\"filterChest('fun')\">🎉 趣味</button>\n        <button class=\"chest-cat-btn cat-btn-item\" data-cat=\"fortune\" onclick=\"filterChest('fortune')\">🔮 测算</button>\n        <button class=\"chest-cat-btn cat-btn-item\" data-cat=\"text\" onclick=\"filterChest('text')\">✍️ 文字</button>\n      </div>\n      <div class=\"chest-grid\" id=\"chestGrid\">\n        <!-- 打字练习（红色置顶） -->\n        <div class=\"chest-card red\" data-cat=\"game\" onclick=\"openChestTool('typingPage','打字练习')\">\n          <div class=\"icon\">⌨️</div><div class=\"title\">打字练习</div><div class=\"desc\">金山打字通风格练习</div>\n        </div>\n        <!-- 打弹珠（红色置顶） -->\n        <div class=\"chest-card red\" data-cat=\"game\" onclick=\"openChestTool('pinballPage','打弹珠')\">\n          <div class=\"icon\">🔮</div><div class=\"title\">打弹珠</div><div class=\"desc\">经典弹珠台弹射得分</div>\n        </div>\n        <!-- 幸运转盘（红色） -->\n        <div class=\"chest-card red\" data-cat=\"game\" onclick=\"openChestTool('wheelPage','幸运转盘')\">\n          <div class=\"icon\">🎡</div><div class=\"title\">幸运转盘</div><div class=\"desc\">多转盘抽金币道具</div>\n        </div>\n                <!-- 趣味类 -->\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('dicePage','掷骰子')\">\n          <div class=\"icon\">🎲</div><div class=\"title\">掷骰子</div><div class=\"desc\">多颗骰子随机点数+历史</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('coinPage','抛硬币')\">\n          <div class=\"icon\">🪙</div><div class=\"title\">抛硬币</div><div class=\"desc\">翻转动画+正反面统计</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('eatPage','今天吃什么')\">\n          <div class=\"icon\">🍔</div><div class=\"title\">今天吃什么</div><div class=\"desc\">自定义美食列表</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('yesnoPage','是或否决策器')\">\n          <div class=\"icon\">🎯</div><div class=\"title\">是或否决策器</div><div class=\"desc\">帮你拿主意+历史</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('fortunePage','抽签')\">\n          <div class=\"icon\">🎋</div><div class=\"title\">抽签</div><div class=\"desc\">自定义签文随机抽取</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fun\" onclick=\"openChestTool('gachaPage','抽卡模拟器')\">\n          <div class=\"icon\">🎴</div><div class=\"title\">抽卡模拟器</div><div class=\"desc\">单抽/十连+SSR概率</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"fun\" onclick=\"openChestTool('rpsPage','石头剪刀布')\">\n          <div class=\"icon\">✊</div><div class=\"title\">石头剪刀布</div><div class=\"desc\">人机对战+胜率统计</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('magic8Page','魔法8球')\">\n          <div class=\"icon\">🔮</div><div class=\"title\">魔法8球</div><div class=\"desc\">摇动球获取答案</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('truthDarePage','真心话大冒险')\">\n          <div class=\"icon\">🎤</div><div class=\"title\">真心话大冒险</div><div class=\"desc\">聚会破冰必玩</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('jokesPage','冷笑话大全')\">\n          <div class=\"icon\">🧊</div><div class=\"title\">冷笑话大全</div><div class=\"desc\">随机冷段子</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('riddlesPage','脑筋急转弯')\">\n          <div class=\"icon\">🤔</div><div class=\"title\">脑筋急转弯</div><div class=\"desc\">考考你的脑洞</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('game24Page','24点')\">\n          <div class=\"icon\">➗</div><div class=\"title\">24点</div><div class=\"desc\">加减乘除凑24</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('idiomChainPage','成语接龙')\">\n          <div class=\"icon\">🐲</div><div class=\"title\">成语接龙</div><div class=\"desc\">接龙挑战词汇量</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fun\" onclick=\"openChestTool('mindReadingPage','读心术')\">\n          <div class=\"icon\">🃏</div><div class=\"title\">读心术</div><div class=\"desc\">猜出你心里想的数</div>\n        </div>\n        <!-- 游戏类 -->\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('minesweeperPage','扫雷')\">\n          <div class=\"icon\">💣</div><div class=\"title\">扫雷</div><div class=\"desc\">经典踩雷游戏</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('tttPage','井字棋')\">\n          <div class=\"icon\">⭕</div><div class=\"title\">井字棋</div><div class=\"desc\">人机对战井字棋</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('memoryPage','记忆翻牌')\">\n          <div class=\"icon\">🃏</div><div class=\"title\">记忆翻牌</div><div class=\"desc\">翻牌配对考验记忆</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('whackPage','打地鼠')\">\n          <div class=\"icon\">🔨</div><div class=\"title\">打地鼠</div><div class=\"desc\">限时打地鼠计分</div>\n        </div><div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('guessPage','猜数字')\">\n          <div class=\"icon\">🎯</div><div class=\"title\">猜数字</div><div class=\"desc\">1-100猜数字游戏</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"game\" onclick=\"openChestTool('slotPage','老虎机')\">\n          <div class=\"icon\">🎰</div><div class=\"title\">老虎机</div><div class=\"desc\">旋转滚轮赢取金币</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('tetrisPage','俄罗斯方块')\">\n          <div class=\"icon\">🧱</div><div class=\"title\">俄罗斯方块</div><div class=\"desc\">消行计分+速度递增</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('gomokuPage','五子棋')\">\n          <div class=\"icon\">⚫</div><div class=\"title\">五子棋</div><div class=\"desc\">人机对战五子连珠</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('game2048Page','2048')\">\n          <div class=\"icon\">🔢</div><div class=\"title\">2048</div><div class=\"desc\">滑动合成数字</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('breakoutPage','打砖块')\">\n          <div class=\"icon\">🏓</div><div class=\"title\">打砖块</div><div class=\"desc\">挡板弹球消砖块</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('pianoPage','别踩白块')\">\n          <div class=\"icon\">🎹</div><div class=\"title\">别踩白块</div><div class=\"desc\">点击黑块别踩白</div>\n        </div>\n        <!-- 测算类 -->\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('fortuneTodayPage','今日运势')\">\n          <div class=\"icon\">🌟</div><div class=\"title\">今日运势</div><div class=\"desc\">每日固定运势测算</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('jinriPage','今日人品')\">\n          <div class=\"icon\">🍀</div><div class=\"title\">今日人品</div><div class=\"desc\">每日人品值检测</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('zodiacPage','星座运势')\">\n          <div class=\"icon\">♈</div><div class=\"title\">星座运势</div><div class=\"desc\">12星座每日运势</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('zodiacMatchPage','生肖配对')\">\n          <div class=\"icon\">🐉</div><div class=\"title\">生肖配对</div><div class=\"desc\">生肖契合度测算</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('nameMatchPage','姓名配对')\">\n          <div class=\"icon\">💕</div><div class=\"title\">姓名配对</div><div class=\"desc\">输入名字算缘分</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('mentalAgePage','心理年龄测试')\">\n          <div class=\"icon\">🧠</div><div class=\"title\">心理年龄测试</div><div class=\"desc\">测测你的心理年龄</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('brainTestPage','左右脑测试')\">\n          <div class=\"icon\">🧩</div><div class=\"title\">左右脑测试</div><div class=\"desc\">测你是左脑还是右脑型</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('pastLifePage','前世身份')\">\n          <div class=\"icon\">🏛️</div><div class=\"title\">前世身份</div><div class=\"desc\">输入名字测前世（纯娱乐）</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fortune\" onclick=\"openChestTool('tarotPage','塔罗牌占卜')\">\n          <div class=\"icon\">🔮</div><div class=\"title\">塔罗牌占卜</div><div class=\"desc\">抽牌看运势（娱乐）</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('dreamPage','周公解梦')\">\n          <div class=\"icon\">💤</div><div class=\"title\">周公解梦</div><div class=\"desc\">输入梦境关键词查询</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('mbtiPage','MBTI人格测试')\">\n          <div class=\"icon\">🧬</div><div class=\"title\">MBTI人格测试</div><div class=\"desc\">测出你的16型人格</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('iqPage','IQ智商测试')\">\n          <div class=\"icon\">🧠</div><div class=\"title\">IQ智商测试</div><div class=\"desc\">趣味智商小测验</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('bloodMatchPage','血型配对')\">\n          <div class=\"icon\">🩸</div><div class=\"title\">血型配对</div><div class=\"desc\">血型契合度测算</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('charDivPage','测字')\">\n          <div class=\"icon\">🔤</div><div class=\"title\">测字</div><div class=\"desc\">一字测运势（娱乐）</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('astrodicePage','占星骰子')\">\n          <div class=\"icon\">🎲</div><div class=\"title\">占星骰子</div><div class=\"desc\">行星·星座·宫位三骰占卜</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fortune\" onclick=\"openChestTool('runePage','符文占卜')\">\n          <div class=\"icon\">🪨</div><div class=\"title\">符文占卜</div><div class=\"desc\">北欧卢恩符文抽牌解读</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('pendulumPage','灵摆占卜')\">\n          <div class=\"icon\">🔮</div><div class=\"title\">灵摆占卜</div><div class=\"desc\">输入问题看灵摆摆动方向</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fortune\" onclick=\"openChestTool('lenormandPage','雷诺曼卡牌')\">\n          <div class=\"icon\">🎴</div><div class=\"title\">雷诺曼卡牌</div><div class=\"desc\">36张牌简单直接的占卜</div>\n          <div class=\"chest-progress\" id=\"lenormandProgress\">集齐 0/36</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fortune\" onclick=\"openChestTool('oraclePage','天使神谕卡')\">\n          <div class=\"icon\">👼</div><div class=\"title\">天使神谕卡</div><div class=\"desc\">治愈系神谕卡指引</div>\n        </div>\n        <div class=\"chest-card gacha-highlight\" data-cat=\"fortune\" onclick=\"openChestTool('kipperPage','基博卡')\">\n          <div class=\"icon\">🃏</div><div class=\"title\">基博卡</div><div class=\"desc\">德国传统生活卡牌占卜</div>\n          <div class=\"chest-progress\" id=\"kipperProgress\">集齐 0/36</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('numerologyPage','数字命理学')\">\n          <div class=\"icon\">🔢</div><div class=\"title\">数字命理学</div><div class=\"desc\">生日算生命数字运势</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('tealeafPage','茶叶占卜')\">\n          <div class=\"icon\">🍵</div><div class=\"title\">茶叶占卜</div><div class=\"desc\">看茶杯底茶叶形状解读</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('crystalballPage','水晶球占卜')\">\n          <div class=\"icon\">🔮</div><div class=\"title\">水晶球占卜</div><div class=\"desc\">凝视水晶球获取启示</div>\n        </div>\n        <!-- 生活类 -->\n        <!-- 文字类 -->\n        <div class=\"chest-card\" data-cat=\"text\" onclick=\"openChestTool('acrosticPage','藏头诗生成')\">\n          <div class=\"icon\">📜</div><div class=\"title\">藏头诗生成</div><div class=\"desc\">输入字生成藏头诗</div>\n        </div>\n        <!-- 新游戏 -->\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('spotDiffPage','找不同')\">\n          <div class=\"icon\">🔍</div><div class=\"title\">找不同</div><div class=\"desc\">限时找出所有差异</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('match3Page','消消乐')\">\n          <div class=\"icon\">🍎</div><div class=\"title\">消消乐</div><div class=\"desc\">三消连线赢金币</div>\n        </div>\n        <div class=\"chest-card gold\" data-cat=\"game\" onclick=\"openChestTool('linkGamePage','连连看')\">\n          <div class=\"icon\">🔗</div><div class=\"title\">连连看</div><div class=\"desc\">配对连线消除</div>\n        </div>\n        <!-- 新测试 -->\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('almanacPage','今日宜忌')\">\n          <div class=\"icon\">📜</div><div class=\"title\">今日宜忌</div><div class=\"desc\">每日宜做啥忌做啥</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('animalPersonalityPage','动物性格测试')\">\n          <div class=\"icon\">🐾</div><div class=\"title\">动物性格测试</div><div class=\"desc\">测你内心住着啥动物</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('faceScorePage','颜值打分器')\">\n          <div class=\"icon\">💅</div><div class=\"title\">颜值打分器</div><div class=\"desc\">输入名字测颜值分</div>\n        </div>\n        <div class=\"chest-card\" data-cat=\"fortune\" onclick=\"openChestTool('moralityPage','人品计算器')\">\n          <div class=\"icon\">⚖️</div><div class=\"title\">人品计算器</div><div class=\"desc\">算算你的人品值</div>\n        </div>\n\n        <!-- 声音类 --><!-- 创意类 -->\n      </div>\n    </div>\n  </div>");
const chestRuleModalMarkup = `<style id="flChestRuleModalStyles">
/* 规则弹窗紧凑样式 */
.rule-modal-box{width:340px;min-width:0;max-width:calc(100vw - 32px);padding:18px 16px;}
.rule-tabs{position:relative;isolation:isolate;display:flex;gap:6px;margin-bottom:12px;background:var(--bg-input);border-radius:12px;padding:4px;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);}
.rule-tab-indicator{position:absolute;z-index:0;left:4px;top:4px;bottom:4px;width:var(--rule-tab-indicator-width,calc((100% - 26px)/4));border-radius:9px;background:var(--primary);box-shadow:0 2px 8px var(--primary-bg);transform:translateX(var(--rule-tab-indicator-x,0px));transition:transform .46s cubic-bezier(.34,1.56,.64,1),width .24s ease;pointer-events:none;}
.rule-tabs.rule-tabs-no-transition .rule-tab-indicator{transition:none;}
.rule-tab{position:relative;z-index:1;flex:1 1 0;min-width:0;box-sizing:border-box;padding:7px 4px;border:none;background:transparent;border-radius:9px;font-size:12px;font-weight:600;color:var(--text-secondary);cursor:grab;touch-action:none;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;transition:color .2s,transform .2s cubic-bezier(.2,.9,.25,1.3),background .18s,box-shadow .18s;}
.rule-tab.active{background:transparent;color:#fff;box-shadow:none;}
.rule-tab.rule-tab-source-lift{opacity:.28;filter:blur(.35px);transform:scale(.88);}
.rule-tab.rule-tab-drop-target{background:rgba(236,72,153,.12);color:var(--primary);box-shadow:inset 0 0 0 1px rgba(236,72,153,.18);transform:scale(1.045);}
.rule-tabs.rule-tabs-dragging .rule-tab{cursor:grabbing;}
.rule-tabs.rule-tabs-dragging .rule-tab-indicator{opacity:0;transition:none;}
.rule-tab-drag-ghost{position:fixed!important;z-index:100000!important;display:flex!important;align-items:center;justify-content:center;flex:none!important;margin:0!important;padding:7px 4px!important;overflow:hidden;border:1px solid rgba(255,255,255,.78)!important;border-radius:999px!important;background:linear-gradient(145deg,rgba(255,255,255,.7),rgba(248,145,196,.62) 38%,rgba(236,72,153,.68))!important;color:#fff!important;box-shadow:0 10px 28px rgba(195,63,137,.28),inset 0 1px 1px rgba(255,255,255,.9),inset 0 -1px 1px rgba(255,255,255,.24)!important;backdrop-filter:blur(18px) saturate(180%);-webkit-backdrop-filter:blur(18px) saturate(180%);opacity:.98;pointer-events:none!important;cursor:grabbing!important;transform:translate(-50%,-50%) scale(1.08);transform-origin:center;transition:none!important;white-space:nowrap;will-change:left,top,transform;}
.rule-tab-drag-ghost::before{content:"";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(115deg,rgba(255,255,255,.58),transparent 38%,rgba(255,255,255,.1) 70%,rgba(255,255,255,.38));pointer-events:none;}
.rule-tab-drag-ghost::after{content:"";position:absolute;left:12%;top:-55%;width:76%;height:85%;border-radius:50%;background:rgba(255,255,255,.48);filter:blur(7px);pointer-events:none;}
.rule-tab-ghost-label{position:relative;z-index:1;display:block;text-shadow:0 1px 5px rgba(178,38,113,.3);}
.rule-tab-drag-ghost.rule-tab-liquid-release{animation:ruleTabLiquidRelease .26s cubic-bezier(.2,.85,.25,1) forwards;}
@keyframes ruleTabLiquidRelease{0%{opacity:.98;filter:blur(0);transform:translate(-50%,-50%) scale(1.08);}42%{opacity:.84;transform:translate(-50%,-50%) scale(1.18,.82);}100%{opacity:0;filter:blur(3px);transform:translate(-50%,-50%) scale(.18,.72);}}
.rule-tab-content{height:260px;overflow-y:auto;padding-bottom:72px;box-sizing:border-box;scrollbar-width:thin;scrollbar-color:var(--fl-scrollbar-thumb) transparent;-webkit-overflow-scrolling:touch;}
.rule-tab-content::-webkit-scrollbar{width:7px;}
.rule-tab-content::-webkit-scrollbar-track{background:transparent;}
.rule-tab-content::-webkit-scrollbar-thumb{background:var(--fl-scrollbar-thumb);border:2px solid transparent;border-radius:99px;background-clip:padding-box;}
@media(max-width:600px){#ruleModalMask .rule-tab-content{height:220px;}}
@media(prefers-reduced-motion:reduce){.rule-tab-indicator{transition:none;}}
.rule-modal-footer{position:absolute;z-index:6;left:16px;right:16px;bottom:14px;}
.rule-modal-footer::before{content:"";position:absolute;z-index:0;left:-16px;right:-16px;top:-82px;bottom:-14px;pointer-events:none;background:linear-gradient(to bottom,rgba(255,255,255,0),rgba(255,255,255,.14));backdrop-filter:blur(16px) saturate(115%);-webkit-backdrop-filter:blur(16px) saturate(115%);mask-image:linear-gradient(to bottom,transparent 0%,rgba(0,0,0,.12) 24%,rgba(0,0,0,.52) 62%,#000 100%);-webkit-mask-image:linear-gradient(to bottom,transparent 0%,rgba(0,0,0,.12) 24%,rgba(0,0,0,.52) 62%,#000 100%);}
.rule-confirm-btn{position:relative;z-index:1;display:flex;align-items:center;justify-content:center;width:100%;min-height:46px;margin:0;padding:10px 18px;border:1px solid var(--primary-bg);border-radius:14px;color:var(--primary);background:var(--primary-bg);box-shadow:0 3px 12px var(--primary-bg),inset 0 1px 0 rgba(255,255,255,.45);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);font:inherit;font-size:16px;font-weight:700;cursor:pointer;transition:transform .12s ease,background .16s ease;}
.rule-confirm-btn:active{transform:scale(.98);}
.rule-item{display:flex;align-items:center;gap:8px;padding:6px 4px;border-bottom:1px solid var(--border-color);font-size:12px;color:var(--text-secondary);line-height:1.4;}
.rule-item:last-child{border-bottom:none;}
.rule-icon{font-size:14px;flex-shrink:0;}
.rule-text{flex:1;}
#ruleModalMask > .rule-modal-box{--modal-head-y:18px;--modal-head-x:16px;--modal-head-gap:12px;border:0 !important;box-shadow:0 28px 80px rgba(34,39,75,.24),0 8px 24px var(--primary-bg) !important;}
</style>
<!-- 金币规则弹窗 -->
<div class="modal-mask" id="ruleModalMask">
  <div class="modal-box rule-modal-box">
    <div class="modal-glass-sticky-head" style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:12px;">
      <h4 style="margin:0;">📜 金币规则说明</h4>
    </div>
    <div class="rule-tabs">
      <span class="rule-tab-indicator" aria-hidden="true"></span>
      <button class="rule-tab active" data-tab="earn" onclick="switchRuleTab('earn')">💰 获得</button>
      <button class="rule-tab" data-tab="spend" onclick="switchRuleTab('spend')">💸 消耗</button>
      <button class="rule-tab" data-tab="code" onclick="switchRuleTab('code')">🔑 代码</button>
      <button class="rule-tab" data-tab="pet" onclick="switchRuleTab('pet')">🐱 宠物</button>
    </div>
    <div class="rule-tab-content" id="ruleTab-earn">
      <div class="rule-item"><span class="rule-icon">🔢</span><span class="rule-text">2048：每50分=1金币，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">💣</span><span class="rule-text">扫雷：简单20/中等50/困难100</span></div>
      <div class="rule-item"><span class="rule-icon">⭕</span><span class="rule-text">井字棋：胜利10，平局5</span></div>
      <div class="rule-item"><span class="rule-icon">🃏</span><span class="rule-text">记忆翻牌：30-步数，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">🔨</span><span class="rule-text">打地鼠：按分数奖励，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">🎯</span><span class="rule-text">猜数字：25-次数×2，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">✊</span><span class="rule-text">石头剪刀布：胜利5</span></div>
      <div class="rule-item"><span class="rule-icon">🎰</span><span class="rule-text">老虎机：中奖获得下注×倍数</span></div>
      <div class="rule-item"><span class="rule-icon">🧱</span><span class="rule-text">俄罗斯方块：每50分=1金币，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">⚫</span><span class="rule-text">五子棋：胜利30</span></div>
      <div class="rule-item"><span class="rule-icon">🏓</span><span class="rule-text">打砖块：每20分=1金币，通关+20，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">🎹</span><span class="rule-text">别踩白块：每5分=1金币，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">🔮</span><span class="rule-text">打弹珠：每200分=1金币，最低5</span></div>
      <div class="rule-item"><span class="rule-icon">🎡</span><span class="rule-text">幸运转盘-金币转盘：免费抽金币，支持单抽/十连/百连</span></div>
    </div>
    <div class="rule-tab-content" id="ruleTab-spend" style="display:none;">
      <div class="rule-item"><span class="rule-icon">🎴</span><span class="rule-text">抽卡模拟器：单抽5，十连40（省10）</span></div>
      <div class="rule-item"><span class="rule-icon">🎰</span><span class="rule-text">老虎机：下注消耗金币</span></div>
      <div class="rule-item"><span class="rule-icon">🔮</span><span class="rule-text">塔罗牌：单牌10，三牌30，四牌40</span></div>
      <div class="rule-item"><span class="rule-icon">🪨</span><span class="rule-text">符文占卜：单枚10，三枚30</span></div>
      <div class="rule-item"><span class="rule-icon">🎴</span><span class="rule-text">雷诺曼卡牌：单牌10，三牌30</span></div>
      <div class="rule-item"><span class="rule-icon">🃏</span><span class="rule-text">基博卡：单牌10，三牌30</span></div>
      <div class="rule-item"><span class="rule-icon">🥚</span><span class="rule-text">扭蛋机：单次5，五连25，可得卡牌/金币/道具</span></div>
      <div class="rule-item"><span class="rule-icon">🎡</span><span class="rule-text">幸运转盘-道具转盘：单抽2，十连15，可得8种道具</span></div>
      <div class="rule-item"><span class="rule-icon">🎡</span><span class="rule-text">幸运转盘-卡牌转盘：单抽2，十连15，可得N/R/SR/SSR卡牌</span></div>
      <div class="rule-item"><span class="rule-icon">🎡</span><span class="rule-text">幸运转盘-弹珠转盘：单抽1，十连8，可得9种颜色弹珠</span></div>
    </div>
    <div class="rule-tab-content" id="ruleTab-code" style="display:none;">
      <div class="rule-item"><span class="rule-icon">🔑</span><span class="rule-text">输入 20110925 得520金币</span></div>
      <div class="rule-item"><span class="rule-icon">🔑</span><span class="rule-text">输入 fengling1314ovo.top 得5200金币</span></div>
      <div class="rule-item"><span class="rule-icon">⚔️</span><span class="rule-text">输入 增加战力 小橘战力+1000</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">输入 毕业幼儿园 解锁小学</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">输入 毕业小学 解锁初中</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">输入 毕业初中 解锁高中</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">输入 毕业高中 解锁大学</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">输入 毕业大学 自动解锁全部学校</span></div>
      <div class="rule-item"><span class="rule-icon">⌨️</span><span class="rule-text">输入 解锁打字 解锁全部打字关卡</span></div>
      <div class="rule-item"><span class="rule-icon">♾️</span><span class="rule-text">无次数上限，可重复兑换</span></div>
    </div>
    <div class="rule-tab-content" id="ruleTab-pet" style="display:none;">
      <div class="rule-item"><span class="rule-icon">🐱</span><span class="rule-text">宠物名字：小橘，一只可爱的橘猫~</span></div>
      <div class="rule-item"><span class="rule-icon">🍖</span><span class="rule-text">饱食度：初始50，上限100，使用食物增加</span></div>
      <div class="rule-item"><span class="rule-icon">🧼</span><span class="rule-text">清洁值：初始100，上限100，使用清洁用品增加</span></div>
      <div class="rule-item"><span class="rule-icon">💕</span><span class="rule-text">好感度：初始50，上限100，使用猫咪玩具增加，上学减少5</span></div>
      <div class="rule-item"><span class="rule-icon">⚔️</span><span class="rule-text">战力：上学毕业获得，学历越高战力越多</span></div>
      <div class="rule-item"><span class="rule-icon">🏫</span><span class="rule-text">上学消耗：饱食度-10、清洁值-10、好感度-5，状态不足无法上学</span></div>
      <div class="rule-item"><span class="rule-icon">🏫</span><span class="rule-text">上学金币：幼儿园5、小学10、初中20、高中35、大学50</span></div>
      <div class="rule-item"><span class="rule-icon">🎓</span><span class="rule-text">学历解锁：小学需幼儿园毕业3次，初中需小学10次，高中需初中20次，大学需高中25次</span></div>
      <div class="rule-item"><span class="rule-icon">🏠</span><span class="rule-text">召回宠物：上学中可召回，退还一半金币</span></div>
      <div class="rule-item"><span class="rule-icon">🏪</span><span class="rule-text">食物商店：购买食物放入仓库，从仓库喂食增加饱食度</span></div>
      <div class="rule-item"><span class="rule-icon">🏪</span><span class="rule-text">清洁商店：购买清洁用品放入仓库，使用增加清洁值</span></div>
      <div class="rule-item"><span class="rule-icon">🏪</span><span class="rule-text">猫咪用品商店：购买逗猫棒等玩具放入仓库，使用增加好感度</span></div>
      <div class="rule-item"><span class="rule-icon">✨</span><span class="rule-text">超级道具商店：加速卡（跳过50%时长）、立即毕业卡、双倍战力卡</span></div>
      <div class="rule-item"><span class="rule-icon">📦</span><span class="rule-text">宠物仓库：存放食物、清洁用品、玩具，点击物品即可使用</span></div>
      <div class="rule-item"><span class="rule-icon">✉️</span><span class="rule-text">校长信箱：毕业后收到校长邮件，含祝福语和随机奖励（食物/清洁/玩具/金币）</span></div>
      <div class="rule-item"><span class="rule-icon">📊</span><span class="rule-text">统计信息：查看小橘使用过的所有物品记录（食物/清洁/玩具/超级道具）</span></div>
      <div class="rule-item"><span class="rule-icon">🛒</span><span class="rule-text">批量购买：商店支持批量购买，可选×1/×5/×10/最大</span></div>
    </div>
    <div class="rule-modal-footer"><button class="rule-confirm-btn" type="button" onclick="closeRuleModal()">✓ 确认</button></div>
  </div>
</div>`;
if (!document.getElementById("ruleModalMask")) {
  document.body.insertAdjacentHTML("beforeend", chestRuleModalMarkup);
}
installRuleTabDrag();

/* 百宝箱首页共享功能：规则弹窗与卡片收集进度。 */
function updateChestProgress() {
  const lenormandCards = lsGet("backpack_lenormand", []);
  const lenormandUnique = new Set(lenormandCards.map(function (card) { return card.num; }));
  const lenormandEl = document.getElementById("lenormandProgress");
  if (lenormandEl) lenormandEl.textContent = "集齐 " + lenormandUnique.size + "/36";

  const kipperCards = lsGet("backpack_kipper", []);
  const kipperUnique = new Set(kipperCards.map(function (card) { return card.num; }));
  const kipperEl = document.getElementById("kipperProgress");
  if (kipperEl) kipperEl.textContent = "集齐 " + kipperUnique.size + "/36";
}

function openRuleModal() {
  const mask = document.getElementById("ruleModalMask");
  if (!mask) return;
  mask.style.display = "flex";
  const activeButton = mask.querySelector(".rule-tab.active");
  if (activeButton) positionRuleTabIndicator(activeButton, false);
  document.body.style.overflow = "hidden";
}

function positionRuleTabIndicator(button, animate) {
  const tabs = button && button.closest(".rule-tabs");
  const firstButton = tabs && tabs.querySelector(".rule-tab");
  if (!tabs || !firstButton) return;
  if (!animate) tabs.classList.add("rule-tabs-no-transition");
  tabs.style.setProperty("--rule-tab-indicator-x", (button.offsetLeft - firstButton.offsetLeft) + "px");
  tabs.style.setProperty("--rule-tab-indicator-width", button.offsetWidth + "px");
  if (!animate) requestAnimationFrame(function () {
    tabs.classList.remove("rule-tabs-no-transition");
  });
}

function installRuleTabDrag() {
  const tabs = document.querySelector("#ruleModalMask .rule-tabs");
  if (!tabs || tabs.dataset.dragReady === "true") return;
  tabs.dataset.dragReady = "true";
  let pressState = null;
  let suppressClick = false;

  function makeDragGhost(button, clientX, clientY) {
    const ghost = button.cloneNode(true);
    ghost.classList.remove("active");
    ghost.classList.add("rule-tab-drag-ghost");
    ghost.removeAttribute("onclick");
    ghost.setAttribute("aria-hidden", "true");
    const label = document.createElement("span");
    label.className = "rule-tab-ghost-label";
    label.textContent = button.textContent.trim();
    ghost.textContent = "";
    ghost.appendChild(label);
    ghost.style.width = button.offsetWidth + "px";
    ghost.style.height = button.offsetHeight + "px";
    ghost.style.left = clientX + "px";
    ghost.style.top = clientY + "px";
    document.body.appendChild(ghost);
    return ghost;
  }

  function animateDragGhost(state, timestamp) {
    if (pressState !== state || !state.dragging || !state.ghost) return;
    const elapsed = state.lastFrame ? Math.min(32, timestamp - state.lastFrame) : 16.67;
    const frameScale = elapsed / 16.67;
    state.lastFrame = timestamp;
    state.vx = (state.vx + (state.targetX - state.x) * .2 * frameScale) * Math.pow(.68, frameScale);
    state.vy = (state.vy + (state.targetY - state.y) * .2 * frameScale) * Math.pow(.68, frameScale);
    state.x += state.vx * frameScale;
    state.y += state.vy * frameScale;
    const speed = Math.hypot(state.vx, state.vy);
    const stretch = Math.min(.2, speed / 100);
    const squash = 1 - stretch * .52;
    const rotation = Math.max(-8, Math.min(8, state.vx * .18));
    state.ghost.style.left = state.x + "px";
    state.ghost.style.top = state.y + "px";
    state.ghost.style.transform = "translate(-50%,-50%) rotate(" + rotation + "deg) scale(" + (1 + stretch) + "," + squash + ")";
    state.ghost.style.borderRadius = Math.max(12, 24 - speed * .28) + "px";
    state.raf = requestAnimationFrame(function (nextTimestamp) {
      animateDragGhost(state, nextTimestamp);
    });
  }

  function updateDropTarget(state, clientX, clientY) {
    const hit = document.elementFromPoint(clientX, clientY);
    const button = hit && hit.closest ? hit.closest(".rule-tab") : null;
    const next = button && tabs.contains(button) ? button : null;
    if (state.dropTarget === next) return;
    if (state.dropTarget) state.dropTarget.classList.remove("rule-tab-drop-target");
    state.dropTarget = next;
    if (next) next.classList.add("rule-tab-drop-target");
  }

  function dismissDragGhost(state, clientX, clientY) {
    if (state.raf) cancelAnimationFrame(state.raf);
    if (state.sourceButton) state.sourceButton.classList.remove("rule-tab-source-lift");
    if (state.dropTarget) state.dropTarget.classList.remove("rule-tab-drop-target");
    if (!state.ghost) return;
    state.ghost.style.left = clientX + "px";
    state.ghost.style.top = clientY + "px";
    state.ghost.style.transform = "";
    state.ghost.classList.add("rule-tab-liquid-release");
    const ghost = state.ghost;
    setTimeout(function () { ghost.remove(); }, 280);
  }

  function restoreIndicator() {
    tabs.classList.remove("rule-tabs-dragging");
    const activeButton = tabs.querySelector(".rule-tab.active");
    if (activeButton) positionRuleTabIndicator(activeButton, true);
  }

  function cancelPress(restore) {
    if (!pressState) return;
    const state = pressState;
    clearTimeout(state.timer);
    const wasDragging = state.dragging;
    if (wasDragging) {
      const activeButton = tabs.querySelector(".rule-tab.active");
      const activeRect = activeButton && activeButton.getBoundingClientRect();
      dismissDragGhost(state, activeRect ? activeRect.left + activeRect.width / 2 : state.x, activeRect ? activeRect.top + activeRect.height / 2 : state.y);
    }
    pressState = null;
    if (restore && wasDragging) restoreIndicator();
  }

  tabs.addEventListener("pointerdown", function (event) {
    const button = event.target.closest(".rule-tab");
    if (!button || !tabs.contains(button) || event.button !== 0) return;
    cancelPress(false);
    const state = { pointerId: event.pointerId, startX: event.clientX, startY: event.clientY, targetX: event.clientX, targetY: event.clientY, x: event.clientX, y: event.clientY, vx: 0, vy: 0, lastFrame: 0, raf: 0, sourceButton: button, dropTarget: null, dragging: false, timer: 0 };
    pressState = state;
    state.timer = setTimeout(function () {
      if (pressState !== state) return;
      state.dragging = true;
      tabs.classList.add("rule-tabs-dragging");
      button.classList.add("rule-tab-source-lift");
      state.ghost = makeDragGhost(button, state.startX, state.startY);
      state.raf = requestAnimationFrame(function (timestamp) { animateDragGhost(state, timestamp); });
      try { tabs.setPointerCapture(state.pointerId); } catch (_) {}
    }, 320);
  });

  tabs.addEventListener("pointermove", function (event) {
    if (!pressState || event.pointerId !== pressState.pointerId) return;
    if (!pressState.dragging) {
      const dx = event.clientX - pressState.startX;
      const dy = event.clientY - pressState.startY;
      if (Math.hypot(dx, dy) > 10) cancelPress(false);
      return;
    }
    event.preventDefault();
    pressState.targetX = event.clientX;
    pressState.targetY = event.clientY;
    updateDropTarget(pressState, event.clientX, event.clientY);
  });

  tabs.addEventListener("pointerup", function (event) {
    if (!pressState || event.pointerId !== pressState.pointerId) return;
    const state = pressState;
    const wasDragging = state.dragging;
    clearTimeout(state.timer);
    if (wasDragging) updateDropTarget(state, event.clientX, event.clientY);
    pressState = null;
    if (!wasDragging) return;

    const targetTab = state.dropTarget ? state.dropTarget.dataset.tab : "";
    dismissDragGhost(state, event.clientX, event.clientY);
    tabs.classList.remove("rule-tabs-dragging");
    if (targetTab) switchRuleTab(targetTab);
    const activeButton = tabs.querySelector(".rule-tab.active");
    if (activeButton) positionRuleTabIndicator(activeButton, true);

    suppressClick = true;
    setTimeout(function () { suppressClick = false; }, 0);
  });

  tabs.addEventListener("pointercancel", function () { cancelPress(true); });
  tabs.addEventListener("click", function (event) {
    if (!suppressClick) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    suppressClick = false;
  }, true);
  tabs.addEventListener("contextmenu", function (event) {
    if (pressState && pressState.dragging) event.preventDefault();
  });
}

function closeRuleModal() {
  closeModalAnimated("ruleModalMask");
}

function switchRuleTab(tab) {
  const mask = document.getElementById("ruleModalMask");
  if (!mask) return;
  const buttons = Array.from(mask.querySelectorAll(".rule-tab"));
  const currentIndex = buttons.findIndex(function (button) { return button.classList.contains("active"); });
  const targetIndex = buttons.findIndex(function (button) { return button.dataset.tab === tab; });
  const selected = mask.querySelector("#ruleTab-" + tab);
  if (targetIndex < 0 || !selected) return;
  if (targetIndex === currentIndex) {
    positionRuleTabIndicator(buttons[targetIndex], true);
    return;
  }
  buttons.forEach(function (button, index) {
    button.classList.toggle("active", index === targetIndex);
  });
  positionRuleTabIndicator(buttons[targetIndex], true);
  mask.querySelectorAll(".rule-tab-content").forEach(function (content) {
    content.style.display = "none";
  });
  selected.style.display = "block";
  selected.scrollTop = 0;
}

