/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageWarehousePage", "<!-- pageWarehousePage -->\n<div class=\"tool-page\" id=\"pageWarehousePage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>📦 宠物仓库</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">从商店购买的食物、清洁用品和猫咪玩具都存放在这里，点击物品即可使用~</div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;\">\n            <div style=\"font-size:48px;\" id=\"warehousePetEmoji\">🐱</div>\n            <div style=\"margin-left:12px;\">\n              <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"warehousePetMood\">心情不错~</div>\n            </div>\n          </div>\n        </div>\n        <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span>\n              <span id=\"warehouseHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"warehouseHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span>\n              <span id=\"warehouseCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"warehouseCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span>\n              <span id=\"warehouseAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"warehouseAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- Tab切换 -->\n      <div style=\"display:flex;gap:8px;margin-bottom:14px;\">\n        <button id=\"warehouseTabFood\" onclick=\"switchWarehouseTab('food')\" style=\"flex:1;padding:10px;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;background:linear-gradient(135deg,#ff9a9e,#fecfef);color:#fff;box-shadow:0 2px 8px rgba(255,154,158,0.3);\">\n          🍖 食物 <span id=\"warehouseFoodCount\" style=\"background:rgba(255,255,255,0.3);border-radius:8px;padding:1px 6px;font-size:11px;\">0</span>\n        </button>\n        <button id=\"warehouseTabClean\" onclick=\"switchWarehouseTab('clean')\" style=\"flex:1;padding:10px;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;background:var(--bg-input);color:var(--text-secondary);\">\n          🧼 清洁 <span id=\"warehouseCleanCount\" style=\"background:rgba(0,0,0,0.08);border-radius:8px;padding:1px 6px;font-size:11px;\">0</span>\n        </button>\n        <button id=\"warehouseTabToy\" onclick=\"switchWarehouseTab('toy')\" style=\"flex:1;padding:10px;border:none;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;background:var(--bg-input);color:var(--text-secondary);\">\n          🪶 玩具 <span id=\"warehouseToyCount\" style=\"background:rgba(0,0,0,0.08);border-radius:8px;padding:1px 6px;font-size:11px;\">0</span>\n        </button>\n      </div>\n      \n      <!-- 食物列表 -->\n      <div id=\"warehouseFoodList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 食物列表由JS生成 -->\n      </div>\n      \n      <!-- 清洁用品列表 -->\n      <div id=\"warehouseCleanList\" style=\"display:none;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 清洁用品列表由JS生成 -->\n      </div>\n      \n      <!-- 玩具列表 -->\n      <div id=\"warehouseToyList\" style=\"display:none;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 玩具列表由JS生成 -->\n      </div>\n      \n      <!-- 空状态 -->\n      <div id=\"warehouseEmpty\" style=\"display:none;text-align:center;padding:40px 20px;color:var(--text-placeholder);\">\n        <div style=\"font-size:48px;\">📭</div>\n        <div style=\"font-size:14px;margin-top:10px;\" id=\"warehouseEmptyText\">仓库空空如也，去商店买点东西吧~</div>\n        <div style=\"margin-top:14px;display:flex;gap:8px;justify-content:center;flex-wrap:wrap;\">\n          <button onclick=\"openPage('foodShopPage')\" style=\"padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#ff9a9e,#fecfef);color:#fff;font-size:13px;font-weight:600;cursor:pointer;\">去食物商店</button>\n          <button onclick=\"openPage('cleanShopPage')\" style=\"padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#60a5fa,#34d399);color:#fff;font-size:13px;font-weight:600;cursor:pointer;\">去清洁商店</button>\n          <button onclick=\"openPage('toyShopPage')\" style=\"padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#a78bfa,#f472b6);color:#fff;font-size:13px;font-weight:600;cursor:pointer;\">去猫咪用品商店</button>\n        </div>\n      </div>\n    </div>\n  </div>");
// ==================== 宠物仓库系统 ====================
// 仓库数据结构: {foods: {fish: 2, meat: 1}, cleans: {towel: 3, soap: 1}}

// 获取仓库数据
function getWarehouse(){
  const wh = lsGet('pet_warehouse', null);
  if(!wh || typeof wh !== 'object'){
    return {foods:{}, cleans:{}, toys:{}};
  }
  if(!wh.foods) wh.foods = {};
  if(!wh.cleans) wh.cleans = {};
  if(!wh.toys) wh.toys = {};
  // 清理数据：把对象结构统一转换成数字结构
  ['foods','cleans','toys'].forEach(key => {
    for(let k in wh[key]){
      const item = wh[key][k];
      if(item && typeof item === 'object' && 'count' in item){
        wh[key][k] = parseInt(item.count) || 0;
      } else {
        wh[key][k] = parseInt(item) || 0;
      }
      if(wh[key][k] <= 0) delete wh[key][k];
    }
  });
  return wh;
}

// 保存仓库数据
function saveWarehouse(wh){
  lsSet('pet_warehouse', wh);
}

// 类型映射
function whTypeKey(type){
  if(type === 'food') return 'foods';
  if(type === 'clean') return 'cleans';
  if(type === 'toy') return 'toys';
  return 'foods';
}

// 添加物品到仓库
function addToWarehouse(type, id){
  const wh = getWarehouse();
  const key = whTypeKey(type);
  wh[key][id] = (wh[key][id] || 0) + 1;
  saveWarehouse(wh);
}

// 从仓库移除物品（返回是否成功）
function removeFromWarehouse(type, id){
  const wh = getWarehouse();
  const key = whTypeKey(type);
  const item = wh[key][id];
  if(!item) return false;
  
  let count = typeof item === 'object' ? (item.count || 0) : (item || 0);
  if(count <= 0) return false;
  
  count--;
  if(count <= 0) delete wh[key][id];
  else if(typeof item === 'object') wh[key][id].count = count;
  else wh[key][id] = count;
  
  saveWarehouse(wh);
  return true;
}

// 获取仓库某类物品总数
function getWarehouseTotal(type){
  const wh = getWarehouse();
  const key = whTypeKey(type);
  let total = 0;
  for(let k in wh[key]){
    const item = wh[key][k];
    if(item && typeof item === 'object' && 'count' in item){
      total += parseInt(item.count) || 0;
    } else {
      total += parseInt(item) || 0;
    }
  }
  return total;
}

// 获取仓库全部物品总数
function getWarehouseAllTotal(){
  return getWarehouseTotal('food') + getWarehouseTotal('clean') + getWarehouseTotal('toy');
}

// 更新仓库角标（个人状态页面按钮上的数字）
function updateWarehouseBadge(){
  const el = document.getElementById('warehouseBadge');
  if(el) el.textContent = getWarehouseAllTotal();
}

// 当前仓库Tab
let currentWarehouseTab = 'food';

// 初始化仓库页面
function initWarehouse(){
  currentWarehouseTab = 'food';
  switchWarehouseTab('food');
  updateWarehousePetDisplay();
  updateWarehouseBadge();
}

// 切换仓库Tab
function switchWarehouseTab(tab){
  currentWarehouseTab = tab;
  const tabFood = document.getElementById('warehouseTabFood');
  const tabClean = document.getElementById('warehouseTabClean');
  const tabToy = document.getElementById('warehouseTabToy');
  const listFood = document.getElementById('warehouseFoodList');
  const listClean = document.getElementById('warehouseCleanList');
  const listToy = document.getElementById('warehouseToyList');
  const empty = document.getElementById('warehouseEmpty');
  
  // 重置所有tab样式
  const tabs = [{el:tabFood, active:'linear-gradient(135deg,#ff9a9e,#fecfef)', shadow:'0 2px 8px rgba(255,154,158,0.3)'},
                {el:tabClean, active:'linear-gradient(135deg,#60a5fa,#34d399)', shadow:'0 2px 8px rgba(96,165,250,0.3)'},
                {el:tabToy, active:'linear-gradient(135deg,#a78bfa,#f472b6)', shadow:'0 2px 8px rgba(167,139,250,0.3)'}];
  const activeIdx = tab === 'food' ? 0 : tab === 'clean' ? 1 : 2;
  tabs.forEach((t, i) => {
    if(t.el){
      if(i === activeIdx){
        t.el.style.background = t.active;
        t.el.style.color = '#fff';
        t.el.style.boxShadow = t.shadow;
      } else {
        t.el.style.background = 'var(--bg-input)';
        t.el.style.color = 'var(--text-secondary)';
        t.el.style.boxShadow = 'none';
      }
    }
  });
  
  // 显示对应列表
  if(listFood) listFood.style.display = tab === 'food' ? 'grid' : 'none';
  if(listClean) listClean.style.display = tab === 'clean' ? 'grid' : 'none';
  if(listToy) listToy.style.display = tab === 'toy' ? 'grid' : 'none';
  
  // 渲染对应列表
  if(tab === 'food') renderWarehouseFoodList();
  else if(tab === 'clean') renderWarehouseCleanList();
  else if(tab === 'toy') renderWarehouseToyList();
  
  // 更新Tab上的数量
  const elFoodCount = document.getElementById('warehouseFoodCount');
  const elCleanCount = document.getElementById('warehouseCleanCount');
  const elToyCount = document.getElementById('warehouseToyCount');
  if(elFoodCount) elFoodCount.textContent = getWarehouseTotal('food');
  if(elCleanCount) elCleanCount.textContent = getWarehouseTotal('clean');
  if(elToyCount) elToyCount.textContent = getWarehouseTotal('toy');
  
  // 空状态判断
  const currentTotal = getWarehouseTotal(tab);
  const emptyTexts = {
    food: '食物仓库空空如也，去食物商店买点吧~',
    clean: '清洁用品仓库空空如也，去清洁商店买点吧~',
    toy: '玩具仓库空空如也，去猫咪用品商店买点吧~'
  };
  if(empty){
    if(currentTotal === 0){
      empty.style.display = 'block';
      const emptyText = document.getElementById('warehouseEmptyText');
      if(emptyText) emptyText.textContent = emptyTexts[tab] || '仓库空空如也~';
    } else {
      empty.style.display = 'none';
    }
  }
}

// 渲染仓库食物列表
function renderWarehouseFoodList(){
  const container = document.getElementById('warehouseFoodList');
  if(!container) return;
  container.innerHTML = '';
  const wh = getWarehouse();
  let hasItem = false;
  
  PHONE_FOODS.forEach(food => {
    const itemData = wh.foods[food.id];
    const count = typeof itemData === 'object' ? (itemData.count || 0) : (itemData || 0);
    if(count <= 0) return;
    hasItem = true;
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid #fecfef;position:relative;';
    div.innerHTML = `
      <div style="position:absolute;top:8px;right:8px;background:#ff9a9e;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;font-weight:700;">x${count}</div>
      <div style="font-size:36px;">${food.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${food.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${food.hunger}饱食度</div>
      <button onclick="useFoodFromWarehouse('${food.id}')" style="margin-top:10px;width:100%;background:linear-gradient(135deg,#ff9a9e,#fecfef);color:#fff;border:none;padding:8px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(255,154,158,0.3);">
        🍖 喂食
      </button>
    `;
    container.appendChild(div);
  });
  
  if(!hasItem){
    container.innerHTML = '';
  }
}

// 渲染仓库清洁用品列表
function renderWarehouseCleanList(){
  const container = document.getElementById('warehouseCleanList');
  if(!container) return;
  container.innerHTML = '';
  const wh = getWarehouse();
  let hasItem = false;
  
  PET_CLEAN_ITEMS.forEach(item => {
    const itemData = wh.cleans[item.id];
    const count = typeof itemData === 'object' ? (itemData.count || 0) : (itemData || 0);
    if(count <= 0) return;
    hasItem = true;
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid #93c5fd;position:relative;';
    div.innerHTML = `
      <div style="position:absolute;top:8px;right:8px;background:#60a5fa;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;font-weight:700;">x${count}</div>
      <div style="font-size:36px;">${item.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${item.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${item.clean}清洁值</div>
      <button onclick="useCleanFromWarehouse('${item.id}')" style="margin-top:10px;width:100%;background:linear-gradient(135deg,#60a5fa,#34d399);color:#fff;border:none;padding:8px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(96,165,250,0.3);">
        🧼 使用
      </button>
    `;
    container.appendChild(div);
  });
  
  if(!hasItem){
    container.innerHTML = '';
  }
}

// 渲染仓库玩具列表
function renderWarehouseToyList(){
  const container = document.getElementById('warehouseToyList');
  if(!container) return;
  container.innerHTML = '';
  const wh = getWarehouse();
  let hasItem = false;
  
  PET_TOYS.forEach(toy => {
    const itemData = wh.toys[toy.id];
    const count = typeof itemData === 'object' ? (itemData.count || 0) : (itemData || 0);
    if(count <= 0) return;
    hasItem = true;
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid #c4b5fd;position:relative;';
    div.innerHTML = `
      <div style="position:absolute;top:8px;right:8px;background:#a78bfa;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;font-weight:700;">x${count}</div>
      <div style="font-size:36px;">${toy.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${toy.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${toy.affection}好感度</div>
      <button onclick="useToyFromWarehouse('${toy.id}')" style="margin-top:10px;width:100%;background:linear-gradient(135deg,#a78bfa,#f472b6);color:#fff;border:none;padding:8px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(167,139,250,0.3);">
        🪶 玩耍
      </button>
    `;
    container.appendChild(div);
  });
  
  if(!hasItem){
    container.innerHTML = '';
  }
}

// 从仓库使用玩具（增加好感度）
function useToyFromWarehouse(toyId){
  const toy = PET_TOYS.find(t => t.id === toyId);
  if(!toy) return;
  
  // 检查仓库是否有该物品
  const wh = getWarehouse();
  if(!wh.toys[toyId] || wh.toys[toyId] <= 0){
    showToast('仓库里没有这个玩具了~');
    return;
  }
  
  // 检查好感度是否已满
  const affection = lsGet('pet_affection', 50);
  if(affection >= 100){
    showToast('小橘已经超级喜欢你啦，好感度已满~');
    return;
  }
  
  // 从仓库移除
  removeFromWarehouse('toy', toyId);
  
  // 记录使用
  recordUsage('toy', toy.id, toy.name, toy.emoji);
  
  // 增加好感度
  const newAffection = Math.min(100, affection + toy.affection);
  lsSet('pet_affection', newAffection);
  
  // 更新显示
  updateWarehousePetDisplay();
  updatePetDisplay();
  updatePetStatusDisplay();
  updateCleanShopDisplay();
  updateToyShopDisplay();
  updateWarehouseBadge();
  
  // 重新渲染列表
  if(currentWarehouseTab === 'toy'){
    renderWarehouseToyList();
    switchWarehouseTab('toy');
  }
  
  // 播放音效
  if(typeof playSound === 'function') playSound('success');
  
  showToast(`小橘玩${toy.emoji}${toy.name}玩得很开心，好感度+${toy.affection}！`);
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_play_pet', 1);
}

// 从仓库使用食物（喂食）
function useFoodFromWarehouse(foodId){
  const food = PHONE_FOODS.find(f => f.id === foodId);
  if(!food) return;
  
  // 检查仓库是否有该物品
  const wh = getWarehouse();
  if(!wh.foods[foodId] || wh.foods[foodId] <= 0){
    showToast('仓库里没有这个食物了~');
    return;
  }
  
  // 检查饱食度是否已满
  const hunger = lsGet('pet_hunger', 50);
  if(hunger >= 100){
    showToast('小橘已经吃饱啦，不要再喂了~');
    return;
  }
  
  // 从仓库移除
  removeFromWarehouse('food', foodId);
  
  // 记录使用
  recordUsage('food', food.id, food.name, food.emoji);
  
  // 增加饱食度
  const newHunger = Math.min(100, hunger + food.hunger);
  lsSet('pet_hunger', newHunger);
  
  // 更新显示
  updateWarehousePetDisplay();
  updatePetDisplay();
  updatePetStatusDisplay();
  updateWarehouseBadge();
  
  // 重新渲染列表
  if(currentWarehouseTab === 'food'){
    renderWarehouseFoodList();
    switchWarehouseTab('food'); // 刷新空状态和计数
  }
  
  // 播放音效
  if(typeof playSound === 'function') playSound('success');
  
  showToast(`小橘吃掉了${food.emoji}${food.name}，饱食度+${food.hunger}！`);
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_feed_pet', 1);
}

// 从仓库使用清洁用品
function useCleanFromWarehouse(itemId){
  const item = PET_CLEAN_ITEMS.find(i => i.id === itemId);
  if(!item) return;
  
  // 检查仓库是否有该物品
  const wh = getWarehouse();
  if(!wh.cleans[itemId] || wh.cleans[itemId] <= 0){
    showToast('仓库里没有这个清洁用品了~');
    return;
  }
  
  // 检查清洁值是否已满
  const clean = lsGet('pet_clean', 100);
  if(clean >= 100){
    showToast('小橘已经很干净啦，不需要再清洁了~');
    return;
  }
  
  // 从仓库移除
  removeFromWarehouse('clean', itemId);
  
  // 记录使用
  recordUsage('clean', item.id, item.name, item.emoji);
  
  // 增加清洁值
  const newClean = Math.min(100, clean + item.clean);
  lsSet('pet_clean', newClean);
  
  // 更新显示
  updateWarehousePetDisplay();
  updatePetDisplay();
  updatePetStatusDisplay();
  updateCleanShopDisplay();
  updateWarehouseBadge();
  
  // 重新渲染列表
  if(currentWarehouseTab === 'clean'){
    renderWarehouseCleanList();
    switchWarehouseTab('clean'); // 刷新空状态和计数
  }
  
  // 播放音效
  if(typeof playSound === 'function') playSound('success');
  
  showToast(`使用了${item.emoji}${item.name}，清洁值+${item.clean}！小橘变干净啦~`);
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_clean_pet', 1);
}

// 更新仓库页面的宠物状态显示
function updateWarehousePetDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  const clean = lsGet('pet_clean', 100);
  const cleanPercent = Math.max(0, Math.min(100, clean));
  const affection = lsGet('pet_affection', 50);
  const affectionPercent = Math.max(0, Math.min(100, affection));
  
  // 根据状态更新表情和心情
  let mood, emoji;
  if(hungerPercent >= 80 && cleanPercent >= 80){ mood='吃饱喝足，超级开心~'; emoji='😺'; }
  else if(hungerPercent >= 50 && cleanPercent >= 50){ mood='心情不错~'; emoji='🐱'; }
  else if(hungerPercent >= 20 && cleanPercent >= 20){ mood='有点饿了/该洗澡了...'; emoji='😿'; }
  else{ mood='快饿晕啦/脏死啦，快照顾我！'; emoji='😾'; }
  if(cleanPercent < 30){ emoji = '🥺'; mood = '脏死啦，快给我洗澡！'; }
  
  const elEmoji = document.getElementById('warehousePetEmoji');
  const elMood = document.getElementById('warehousePetMood');
  const elHungerText = document.getElementById('warehouseHungerText');
  const elHungerBar = document.getElementById('warehouseHungerBar');
  const elCleanText = document.getElementById('warehouseCleanText');
  const elCleanBar = document.getElementById('warehouseCleanBar');
  const elAffectionText = document.getElementById('warehouseAffectionText');
  const elAffectionBar = document.getElementById('warehouseAffectionBar');
  
  if(elEmoji) elEmoji.textContent = emoji;
  if(elMood) elMood.textContent = mood;
  if(elHungerText) elHungerText.textContent = hungerPercent + '/100';
  if(elHungerBar) elHungerBar.style.width = hungerPercent + '%';
  if(elCleanText) elCleanText.textContent = cleanPercent + '/100';
  if(elCleanBar) elCleanBar.style.width = cleanPercent + '%';
  if(elAffectionText) elAffectionText.textContent = affectionPercent + '/100';
  if(elAffectionBar) elAffectionBar.style.width = affectionPercent + '%';
}

function updateHungerDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  
  const elDisplay = document.getElementById('phoneHungerDisplay');
  const elBar = document.getElementById('phoneHungerBar');
  const elText = document.getElementById('phoneHungerText');
  const elProgress = document.getElementById('phoneHungerProgress');
  const elMood = document.getElementById('phonePetMood');
  const elEmoji = document.getElementById('phonePetEmoji');
  
  if(elDisplay) elDisplay.textContent = hungerPercent + '/100';
  if(elBar) elBar.style.width = hungerPercent + '%';
  if(elText) elText.textContent = hungerPercent + '/100';
  if(elProgress) elProgress.style.width = hungerPercent + '%';
  
  // 根据饱食度更新心情
  if(elMood && elEmoji){
    if(hungerPercent >= 80){
      elMood.textContent = '吃饱啦，超级开心~';
      elEmoji.textContent = '😺';
    } else if(hungerPercent >= 50){
      elMood.textContent = '心情不错~';
      elEmoji.textContent = '🐱';
    } else if(hungerPercent >= 20){
      elMood.textContent = '有点饿了...';
      elEmoji.textContent = '😿';
    } else {
      elMood.textContent = '快饿晕啦，快喂我！';
      elEmoji.textContent = '😾';
    }
  }
}

