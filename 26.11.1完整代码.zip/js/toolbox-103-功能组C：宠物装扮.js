/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetDressPage", "<!-- pagePetDressPage -->\n<div class=\"tool-page\" id=\"pagePetDressPage\">\n  <div class=\"tool-header\">\n    <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n  </div>\n  <div class=\"breadcrumb\"></div>\n  <div class=\"common-block\" style=\"padding:0 28px 32px\">\n    <h3>👗 宠物装扮</h3>\n    <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">\n      给小橘买好看的衣帽配饰！点击购买，再点\"穿上\"即可穿戴，金币：<b id=\"pdCoins\">0</b> 💰\n    </div>\n\n    <!-- 装扮预览区 -->\n    <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:20px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);text-align:center;\">\n      <div style=\"font-size:13px;color:#666;margin-bottom:8px;\">✨ 装扮预览 ✨</div>\n      <div id=\"pdPreview\" style=\"position:relative;display:inline-block;font-size:64px;line-height:1.2;\">🐱</div>\n      <div style=\"font-size:12px;color:#666;margin-top:8px;\" id=\"pdPreviewText\">小橘还没穿衣服呢~</div>\n    </div>\n\n    <!-- 装扮商店（按分类渲染） -->\n    <div id=\"pdShopArea\"></div>\n  </div>\n</div>");
// ==================== 功能组C：宠物装扮 ====================

const PET_DRESS_CATS = [
  {key:'hat', name:'帽子 🎩'},
  {key:'glasses', name:'眼镜 👓'},
  {key:'scarf', name:'围巾 🧣'},
  {key:'clothes', name:'衣服 👕'}
];
const PET_DRESS_ITEMS = [
  {id:'hat_top', cat:'hat', name:'高顶礼帽', emoji:'🎩', price:50},
  {id:'hat_cap', cat:'hat', name:'棒球帽', emoji:'🧢', price:25},
  {id:'hat_crown', cat:'hat', name:'小皇冠', emoji:'👑', price:100},
  {id:'hat_bow', cat:'hat', name:'蝴蝶结', emoji:'🎀', price:20},
  {id:'hat_straw', cat:'hat', name:'草帽', emoji:'👒', price:15},
  {id:'glass_plain', cat:'glasses', name:'方框眼镜', emoji:'👓', price:40},
  {id:'glass_sun', cat:'glasses', name:'酷墨镜', emoji:'🕶️', price:60},
  {id:'glass_goggle', cat:'glasses', name:'护目镜', emoji:'🥽', price:35},
  {id:'glass_nerd', cat:'glasses', name:'学霸眼镜', emoji:'🤓', price:50},
  {id:'scarf_red', cat:'scarf', name:'红围巾', emoji:'🧣', price:45},
  {id:'scarf_flower', cat:'scarf', name:'花领巾', emoji:'🌸', price:20},
  {id:'scarf_knit', cat:'scarf', name:'毛线围脖', emoji:'🧶', price:35},
  {id:'scarf_ribbon', cat:'scarf', name:'丝带领', emoji:'🎗️', price:25},
  {id:'cloth_tshirt', cat:'clothes', name:'小T恤', emoji:'👕', price:30},
  {id:'cloth_dress', cat:'clothes', name:'小裙子', emoji:'👗', price:60},
  {id:'cloth_coat', cat:'clothes', name:'小外套', emoji:'🧥', price:80},
  {id:'cloth_vest', cat:'clothes', name:'小马甲', emoji:'🦺', price:25},
  {id:'cloth_kimono', cat:'clothes', name:'小和服', emoji:'🥋', price:90}
];

function pdGet(){
  const d = lsGet('pet_dressup', {hat:null, glasses:null, scarf:null, clothes:null, owned:[]});
  if(!d.owned) d.owned = [];
  ['hat','glasses','scarf','clothes'].forEach(k=>{ if(!(k in d)) d[k] = null; });
  return d;
}
function pdSave(d){ lsSet('pet_dressup', d); }
function pdFindItem(id){
  for(let i=0;i<PET_DRESS_ITEMS.length;i++){ if(PET_DRESS_ITEMS[i].id===id) return PET_DRESS_ITEMS[i]; }
  return null;
}

function pdBuy(id){
  const it = pdFindItem(id);
  if(!it) return;
  const d = pdGet();
  if(d.owned.indexOf(id) >= 0){ showToast('已经拥有啦~'); return; }
  if(!bpSpendCoins(it.price, 'petDress')){ showToast('金币不足，快去打工赚钱吧~'); return; }
  d.owned.push(id);
  pdSave(d);
  showToast('购买成功：'+it.name);
  pdRenderShop();
}

function pdWear(id){
  const it = pdFindItem(id);
  if(!it) return;
  const d = pdGet();
  if(d[it.cat] === id){
    d[it.cat] = null;
    showToast('已脱下 '+it.name);
  } else {
    d[it.cat] = id;
    showToast('穿上 '+it.name+' 啦~');
  }
  pdSave(d);
  pdRenderShop();
}

// 装扮页预览
function pdRenderPreview(){
  const box = document.getElementById('pdPreview');
  if(!box) return;
  const d = pdGet();
  const defs = [
    {id:d.hat, css:'top:-16px;left:50%;transform:translateX(-50%);font-size:26px;'},
    {id:d.glasses, css:'top:26%;left:50%;transform:translateX(-50%);font-size:22px;'},
    {id:d.scarf, css:'bottom:24%;left:50%;transform:translateX(-50%);font-size:20px;'},
    {id:d.clothes, css:'bottom:-4px;left:50%;transform:translateX(-50%);font-size:28px;'}
  ];
  let ov = '';
  defs.forEach(def=>{
    if(!def.id) return;
    const it = pdFindItem(def.id);
    if(!it) return;
    ov += '<span style="position:absolute;'+def.css+'pointer-events:none;line-height:1;">'+it.emoji+'</span>';
  });
  box.innerHTML = '🐱' + ov;
  const txt = document.getElementById('pdPreviewText');
  const worn = [d.hat,d.glasses,d.scarf,d.clothes].filter(Boolean).length;
  if(txt) txt.textContent = worn===0 ? '小橘还没穿衣服呢，去商店挑几件吧~' : '小橘已穿戴 '+worn+' 件装扮，真好看！';
}

function pdRenderShop(){
  const area = document.getElementById('pdShopArea');
  if(!area) return;
  const d = pdGet();
  const coinEl = document.getElementById('pdCoins');
  if(coinEl) coinEl.textContent = bpGetCoins();

  let html = '';
  PET_DRESS_CATS.forEach(cat=>{
    const items = PET_DRESS_ITEMS.filter(it=>it.cat===cat.key);
    html += '<h4 style="margin:14px 0 8px;font-size:15px;color:var(--text-main);">'+cat.name+'</h4>';
    html += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:6px;">';
    items.forEach(it=>{
      const owned = d.owned.indexOf(it.id) >= 0;
      const wearing = d[cat.key] === it.id;
      let actionBtn;
      if(!owned){
        actionBtn = '<button onclick="pdBuy(\''+it.id+'\')" style="width:100%;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;border:none;padding:7px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;">'+it.price+'💰 购买</button>';
      } else if(wearing){
        actionBtn = '<button onclick="pdWear(\''+it.id+'\')" style="width:100%;background:#ef4444;color:#fff;border:none;padding:7px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;">已穿 · 脱下</button>';
      } else {
        actionBtn = '<button onclick="pdWear(\''+it.id+'\')" style="width:100%;background:linear-gradient(135deg,#10b981,#34d399);color:#fff;border:none;padding:7px;border-radius:9px;font-size:12px;font-weight:700;cursor:pointer;">穿上</button>';
      }
      const border = wearing ? 'border:2px solid var(--primary);' : 'border:2px solid transparent;';
      html += '<div style="background:var(--card-bg);border-radius:12px;padding:12px;text-align:center;'+border+'box-shadow:0 2px 8px rgba(0,0,0,0.05);">'
        + '<div style="font-size:32px;">'+it.emoji+'</div>'
        + '<div style="font-size:13px;font-weight:700;margin-top:4px;color:var(--text-main);">'+it.name+'</div>'
        + '<div style="margin-top:8px;">'+actionBtn+'</div>'
        + '</div>';
    });
    html += '</div>';
  });
  area.innerHTML = html;
  pdRenderPreview();
}

// 状态页小橘展示区叠加装扮（供 updateStatusPage 调用）
function updatePetDressDisplay(){
  const em = document.getElementById('statusPetEmoji');
  if(!em) return;
  em.style.position = 'relative';
  em.style.display = 'inline-block';
  const old = em.querySelectorAll('.pd-overlay');
  for(let i=0;i<old.length;i++){ old[i].parentNode.removeChild(old[i]); }
  const d = pdGet();
  const defs = [
    {id:d.hat, css:'top:-14px;left:50%;transform:translateX(-50%);font-size:24px;'},
    {id:d.glasses, css:'top:26%;left:50%;transform:translateX(-50%);font-size:20px;'},
    {id:d.scarf, css:'bottom:22%;left:50%;transform:translateX(-50%);font-size:18px;'},
    {id:d.clothes, css:'bottom:-4px;left:50%;transform:translateX(-50%);font-size:24px;'}
  ];
  defs.forEach(def=>{
    if(!def.id) return;
    const it = pdFindItem(def.id);
    if(!it) return;
    const sp = document.createElement('span');
    sp.className = 'pd-overlay';
    sp.style.cssText = 'position:absolute;'+def.css+'pointer-events:none;line-height:1;';
    sp.textContent = it.emoji;
    em.appendChild(sp);
  });
}

function initPetDress(){
  pdRenderShop();
}

