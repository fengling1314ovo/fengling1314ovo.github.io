// ==================== 道具使用系统 ====================
const ITEM_EFFECTS={
  exp_potion:{name:'经验药水',icon:'🌟',action:()=>{const r=Math.floor(Math.random()*20)+10;bpAddCoins(r,'道具');playSound('item');showToast('🌟 使用经验药水，获得'+r+'金币');}},
  coin_bag:{name:'金币袋',icon:'💰',action:()=>{const r=Math.floor(Math.random()*21)+10;bpAddCoins(r,'道具');playSound('coin');showToast('💰 打开金币袋，获得'+r+'金币');}},
  lucky_charm:{name:'幸运符',icon:'🍀',action:()=>{lsSet('lucky_charm_count',3);playSound('item');showToast('🍀 使用幸运符，接下来3次抽卡/扭蛋概率提升！');}},
  mystery_box:{name:'神秘宝箱',icon:'🎁',action:()=>{const r=Math.random();if(r<0.5){const c=Math.floor(Math.random()*30)+20;bpAddCoins(c,'道具');playSound('coin');showToast('🎁 神秘宝箱开出'+c+'金币！');}else{const item=capsuleGetRandomItem();bpAddItem(item.id);playSound('item');showToast('🎁 神秘宝箱开出'+item.name+'！');}}},
  magic_scroll:{name:'魔法卷轴',icon:'📜',action:()=>{bpAddCoins(50,'道具');playSound('item');showToast('📜 使用魔法卷轴，获得50金币');}},
  energy_crystal:{name:'能量水晶',icon:'💎',action:()=>{const r=Math.floor(Math.random()*31)+30;bpAddCoins(r,'道具');playSound('coin');showToast('💎 能量水晶转化为'+r+'金币');}},
  time_hourglass:{name:'时光沙漏',icon:'⏳',action:()=>{bpAddCoins(25,'道具');playSound('item');showToast('⏳ 使用时光沙漏，获得25金币');}},
  star_fragment:{name:'星星碎片',icon:'⭐',action:()=>{const count=lsGet('star_fragment_used',0)+1;lsSet('star_fragment_used',count);if(count>=5){lsSet('star_fragment_used',0);bpAddCoins(100,'道具');playSound('success');showToast('⭐ 集齐5颗星星碎片，获得100金币！');}else{playSound('item');showToast('⭐ 使用星星碎片（'+count+'/5），集齐5颗获得100金币');}}}
};
// 批量使用道具相关变量
let currentBatchItemId=null;
let currentBatchCount=1;
let currentBatchMax=1;

function useItem(itemId){
  const items=bpGetItems();
  const count=items.filter(i=>i.id===itemId).length;
  if(count===0){showToast('没有这个道具');return;}
  if(count===1){
    // 只有1个，直接使用
    const idx=items.findIndex(i=>i.id===itemId);
    items.splice(idx,1);
    lsSet('backpack_items',items);
    const effect=ITEM_EFFECTS[itemId];
    if(effect)effect.action();
    bpRenderItems();
    bpRender();
  }else{
    // 多个，打开批量使用弹窗
    openBatchUseModal(itemId,count);
  }
}

function openBatchUseModal(itemId,count){
  currentBatchItemId=itemId;
  currentBatchMax=count;
  currentBatchCount=1;
  const effect=ITEM_EFFECTS[itemId];
  if(effect){
    document.getElementById('batchItemIcon').textContent=effect.icon;
    document.getElementById('batchItemName').textContent=effect.name;
  }
  document.getElementById('batchItemCount').textContent='拥有：'+count+'个';
  document.getElementById('batchCount').textContent=currentBatchCount;
  const modal=document.getElementById('batchUseModal');
  if(modal){modal.classList.remove('closing');modal.style.display='flex';document.body.style.overflow='hidden';}
  playSound('click');
}

function closeBatchUseModal(){
  const modal=document.getElementById('batchUseModal');
  if(modal) closeModalAnimated(modal);
  currentBatchItemId=null;
}

function changeBatchCount(delta){
  currentBatchCount=Math.max(1,Math.min(currentBatchMax,currentBatchCount+delta));
  document.getElementById('batchCount').textContent=currentBatchCount;
}

function setBatchMax(){
  currentBatchCount=currentBatchMax;
  document.getElementById('batchCount').textContent=currentBatchCount;
}

function confirmBatchUse(){
  if(!currentBatchItemId)return;
  const items=bpGetItems();
  let used=0;
  for(let i=0;i<currentBatchCount;i++){
    const idx=items.findIndex(it=>it.id===currentBatchItemId);
    if(idx===-1)break;
    items.splice(idx,1);
    used++;
  }
  lsSet('backpack_items',items);
  // 循环触发道具效果
  const effect=ITEM_EFFECTS[currentBatchItemId];
  if(effect){
    for(let i=0;i<used;i++){
      effect.action();
    }
  }
  showToast('✨ 批量使用了'+used+'个'+effect.name);
  closeBatchUseModal();
  bpRenderItems();
  bpRender();
}


/* ===== 百宝箱功能分段 ===== */

// 扭蛋机规则弹窗
function openCapsuleRule(){
  const m=document.getElementById('capsuleRuleModal');
  if(m){m.classList.remove('closing');m.style.display='flex';document.body.style.overflow='hidden';playSound('click');}
}
function closeCapsuleRule(){
  const m=document.getElementById('capsuleRuleModal');
  if(m) closeModalAnimated(m);
}


/* ===== 百宝箱功能分段 ===== */

