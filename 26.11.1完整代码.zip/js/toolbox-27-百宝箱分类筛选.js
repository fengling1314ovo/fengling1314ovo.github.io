// ==================== 百宝箱分类筛选 ====================
function filterChest(cat){
  document.querySelectorAll('.chest-cat-btn').forEach(b=>b.classList.toggle('active',b.dataset.cat===cat));
  document.querySelectorAll('.chest-grid .chest-card').forEach(c=>{
    c.style.display = (cat==='all'||c.dataset.cat===cat)?'block':'none';
  });
}


