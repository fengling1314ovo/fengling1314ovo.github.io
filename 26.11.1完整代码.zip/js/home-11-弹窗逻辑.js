// ==================== 弹窗逻辑 ====================
const modalMask = document.getElementById('modalMask');
const openModalBtn = document.getElementById('openModalBtn');
const modalDismissBtn = modalMask.querySelector('.personal-modal-dismiss');
const modalConfirmBtn = modalMask.querySelector('#personalModalConfirm');
const personalModalScroll = modalMask.querySelector('.personal-modal-scroll');
const personalModalHeader = modalMask.querySelector('.personal-modal-header');
const updatePersonalModalHeader = ()=>{
  personalModalHeader.classList.toggle('is-scrolled', personalModalScroll.scrollTop > 2);
};
personalModalScroll.addEventListener('scroll', updatePersonalModalHeader, {passive:true});
openModalBtn.onclick = ()=>{ updatePersonalModalHeader(); modalMask.style.display='flex'; document.body.style.overflow='hidden'; };
const closePersonalModal = ()=>{ document.body.style.overflow=''; closeModalAnimated(modalMask); };
if(modalDismissBtn) modalDismissBtn.onclick = closePersonalModal;
if(modalConfirmBtn) modalConfirmBtn.onclick = closePersonalModal;

