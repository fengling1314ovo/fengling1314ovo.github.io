(function () {
  if (window.__flAdvancedSettingsModalLoaded) return;
  window.__flAdvancedSettingsModalLoaded = true;

  const settings = [
    { key: "clock_show", id: "flAdvancedClockToggle", title: "首页时钟", description: "在首页标题下方显示当前时间" },
    { key: "clock_ms", id: "flAdvancedMillisecondsToggle", title: "毫秒显示", description: "时间后追加毫秒（需开启时钟）" },
    { key: "show_holiday", id: "flAdvancedHolidayToggle", title: "节假日提醒", description: "时钟旁显示距离下一个法定节假日还有几天" }
  ];

  const markup = `<style id="flAdvancedSettingsModalStyles">
#flAdvancedSettingsModal{z-index:10005;padding:16px;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);}
#flAdvancedSettingsModal>.fl-advanced-settings-box{display:flex;flex-direction:column;gap:16px;width:560px;min-width:0;max-width:calc(100vw - 32px);max-height:82vh;padding:22px 20px 18px;border:1px solid rgba(255,255,255,.82);border-radius:26px;overflow:hidden;background:linear-gradient(145deg,rgba(255,255,255,.91),rgba(246,237,252,.9) 55%,rgba(234,244,255,.92));box-shadow:0 28px 80px rgba(34,39,75,.24),0 8px 24px rgba(236,72,153,.16);}
.fl-advanced-settings-header{display:flex;align-items:center;justify-content:space-between;gap:12px;flex:none;}
.fl-advanced-settings-header h3{margin:0;font-size:20px;color:var(--text-main);}
.fl-advanced-settings-close{display:flex;align-items:center;justify-content:center;flex:none;width:38px;height:38px;padding:0;border:1px solid rgba(255,255,255,.85);border-radius:13px;background:rgba(255,255,255,.64);color:var(--text-secondary);font-size:23px;line-height:1;cursor:pointer;}
.fl-advanced-settings-list{display:grid;gap:12px;overflow-y:auto;padding:2px 2px 4px;overscroll-behavior:contain;}
.fl-advanced-setting-row{display:flex;align-items:center;justify-content:space-between;gap:16px;min-height:86px;padding:16px 20px;border:1px solid rgba(255,255,255,.9);border-radius:21px;background:rgba(255,255,255,.42);box-shadow:0 8px 24px rgba(82,96,142,.08);}
.fl-advanced-setting-copy{display:grid;gap:5px;min-width:0;}
.fl-advanced-setting-title{font-size:17px;font-weight:500;color:var(--text-main);}
.fl-advanced-setting-description{font-size:13px;line-height:1.5;color:var(--text-secondary);}
.fl-advanced-switch{position:relative;display:block;flex:none;width:70px;height:40px;}
.fl-advanced-switch input{position:absolute;z-index:2;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer;}
.fl-advanced-switch-track{position:absolute;inset:0;border-radius:999px;background:#cbd5e1;transition:background .2s ease,box-shadow .2s ease;}
.fl-advanced-switch-track::after{content:"";position:absolute;top:4px;left:4px;width:32px;height:32px;border-radius:50%;background:#fff;box-shadow:0 2px 6px rgba(43,61,91,.18);transition:transform .22s cubic-bezier(.34,1.56,.64,1);}
.fl-advanced-switch input:checked+.fl-advanced-switch-track{background:#4fc3f7;}
.fl-advanced-switch input:checked+.fl-advanced-switch-track::after{transform:translateX(30px);}
.fl-advanced-switch input:focus-visible+.fl-advanced-switch-track{outline:3px solid rgba(79,195,247,.3);outline-offset:3px;}
.fl-advanced-settings-footer{flex:none;padding-top:2px;}
.fl-advanced-settings-done{display:flex;align-items:center;justify-content:center;width:100%;min-height:48px;padding:11px 18px;border:1px solid rgba(236,72,153,.15);border-radius:15px;background:rgba(236,72,153,.12);color:var(--primary);font:inherit;font-size:16px;font-weight:700;cursor:pointer;backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);}
@media(max-width:600px){#flAdvancedSettingsModal>.fl-advanced-settings-box{gap:13px;padding:18px 15px 15px;border-radius:23px;max-height:84vh;}.fl-advanced-setting-row{min-height:78px;padding:13px 14px;border-radius:18px;}.fl-advanced-setting-title{font-size:16px;}.fl-advanced-setting-description{font-size:12px;}.fl-advanced-switch{width:62px;height:36px;}.fl-advanced-switch-track::after{width:28px;height:28px;}.fl-advanced-switch input:checked+.fl-advanced-switch-track::after{transform:translateX(26px);}}
</style>
<div class="modal-mask" id="flAdvancedSettingsModal" style="display:none;" aria-hidden="true">
  <div class="modal-box fl-advanced-settings-box" role="dialog" aria-modal="true" aria-labelledby="flAdvancedSettingsTitle">
    <div class="fl-advanced-settings-header">
      <h3 id="flAdvancedSettingsTitle">⚙️ 高级设置</h3>
      <button class="fl-advanced-settings-close" type="button" aria-label="关闭高级设置" onclick="flCloseAdvancedSettingsModal()">×</button>
    </div>
    <div class="fl-advanced-settings-list">
      <label class="fl-advanced-setting-row" for="flAdvancedClockToggle">
        <span class="fl-advanced-setting-copy"><span class="fl-advanced-setting-title">首页时钟</span><span class="fl-advanced-setting-description">在首页标题下方显示当前时间</span></span>
        <span class="fl-advanced-switch"><input id="flAdvancedClockToggle" type="checkbox" data-setting="clock_show" aria-label="首页时钟"><span class="fl-advanced-switch-track"></span></span>
      </label>
      <label class="fl-advanced-setting-row" for="flAdvancedMillisecondsToggle">
        <span class="fl-advanced-setting-copy"><span class="fl-advanced-setting-title">毫秒显示</span><span class="fl-advanced-setting-description">时间后追加毫秒（需开启时钟）</span></span>
        <span class="fl-advanced-switch"><input id="flAdvancedMillisecondsToggle" type="checkbox" data-setting="clock_ms" aria-label="毫秒显示"><span class="fl-advanced-switch-track"></span></span>
      </label>
      <label class="fl-advanced-setting-row" for="flAdvancedHolidayToggle">
        <span class="fl-advanced-setting-copy"><span class="fl-advanced-setting-title">节假日提醒</span><span class="fl-advanced-setting-description">时钟旁显示距离下一个法定节假日还有几天</span></span>
        <span class="fl-advanced-switch"><input id="flAdvancedHolidayToggle" type="checkbox" data-setting="show_holiday" aria-label="节假日提醒"><span class="fl-advanced-switch-track"></span></span>
      </label>
    </div>
    <div class="fl-advanced-settings-footer"><button class="fl-advanced-settings-done" type="button" onclick="flCloseAdvancedSettingsModal()">✓ 完成</button></div>
  </div>
</div>`;

  if (!document.getElementById("flAdvancedSettingsModal")) {
    document.body.insertAdjacentHTML("beforeend", markup);
  }

  const modal = document.getElementById("flAdvancedSettingsModal");
  let previousBodyOverflow = "";
  let closeTimer = 0;

  function syncSettings() {
    settings.forEach(function (setting) {
      const input = document.getElementById(setting.id);
      if (!input) return;
      try { input.checked = localStorage.getItem(setting.key) === "1"; }
      catch (_) { input.checked = false; }
    });
  }

  function handleSettingChange(event) {
    const input = event.target;
    if (!input || !input.matches("input[data-setting]")) return;
    try { localStorage.setItem(input.dataset.setting, input.checked ? "1" : "0"); }
    catch (_) {
      if (typeof window.showToast === "function") window.showToast("设置保存失败");
    }
    if (typeof window.flUpdateHomeClock === "function") window.flUpdateHomeClock();
  }

  function onKeydown(event) {
    if (event.key === "Escape") window.flCloseAdvancedSettingsModal();
  }

  modal.addEventListener("change", handleSettingChange);
  modal.addEventListener("click", function (event) {
    if (event.target === modal) window.flCloseAdvancedSettingsModal();
  });

  window.flOpenAdvancedSettingsModal = function () {
    if (modal.style.display === "flex" && !modal.classList.contains("closing")) return;
    if (closeTimer) clearTimeout(closeTimer);
    syncSettings();
    if (modal.style.display === "none") previousBodyOverflow = document.body.style.overflow;
    modal.classList.remove("closing");
    modal.style.display = "flex";
    modal.setAttribute("aria-hidden", "false");
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeydown);
  };

  window.flCloseAdvancedSettingsModal = function () {
    if (modal.style.display === "none" || modal.classList.contains("closing")) return;
    window.removeEventListener("keydown", onKeydown);
    modal.classList.add("closing");
    closeTimer = setTimeout(function () {
      modal.style.display = "none";
      modal.classList.remove("closing");
      document.body.style.overflow = previousBodyOverflow;
      modal.setAttribute("aria-hidden", "true");
    }, 220);
  };
})();
