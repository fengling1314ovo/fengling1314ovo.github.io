/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetWorkPage", "<!-- pagePetWorkPage -->\n<div class=\"tool-page\" id=\"pagePetWorkPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>💼 出门打工</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">让小橘去打工赚金币！学历越高，工作越赚钱~ 关闭浏览器时间也会继续走哦</div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;\">\n            <div style=\"font-size:48px;\" id=\"workPetEmoji\">🐱</div>\n            <div style=\"margin-left:12px;\">\n              <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"workPetMood\">心情不错~</div>\n            </div>\n          </div>\n          <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n            <div style=\"display:inline-block;background:#fef3c7;color:#f59e0b;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n              ⚔️ <span id=\"workPetPower\">0</span>\n            </div>\n            <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"workCoins\">0</span></div>\n          </div>\n        </div>\n        <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span><span id=\"workHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"workHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span><span id=\"workCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"workCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span><span id=\"workAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"workAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 打工中状态 -->\n      <div id=\"workAwayArea\" style=\"display:none;margin-bottom:14px;\">\n        <div style=\"background:#fff3cd;border-radius:16px;padding:20px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n          <div style=\"font-size:48px;\">💼</div>\n          <div style=\"font-size:16px;font-weight:700;color:#856404;margin-top:8px;\" id=\"workAwayText\">小橘正在打工...</div>\n          <div style=\"font-size:28px;font-weight:700;color:#856404;margin-top:10px;\" id=\"workAwayTimer\">00:00</div>\n          <div style=\"font-size:13px;color:#856404;margin-top:8px;\" id=\"workAwayReward\">预计收入 0 金币</div>\n          <button onclick=\"recallPetWork()\" style=\"margin-top:14px;background:#ef4444;color:#fff;border:none;padding:10px 24px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(239,68,68,0.3);\">\n            🏠 召回宠物（不获得工资）\n          </button>\n        </div>\n      </div>\n      \n      <!-- 工作列表 -->\n      <div id=\"workListArea\">\n        <div style=\"display:grid;gap:12px;\" id=\"workList\">\n          <!-- 工作列表由JS生成 -->\n        </div>\n      </div>\n    </div>\n  </div>");
// ==================== 宠物打工系统 ====================
let petWorkTimer = null;

// 判断工作是否解锁
function isJobUnlocked(jobId){
  const job = PET_JOBS.find(j => j.id === jobId);
  if(!job) return false;
  if(!job.unlockSchool) return true;
  const counts = lsGet('pet_school_counts', {});
  return (counts[job.unlockSchool] || 0) >= job.unlockCount;
}

// 获取工作解锁进度
function getJobUnlockProgress(jobId){
  const job = PET_JOBS.find(j => j.id === jobId);
  if(!job || !job.unlockSchool) return {current:0, required:0};
  const counts = lsGet('pet_school_counts', {});
  return {current: counts[job.unlockSchool] || 0, required: job.unlockCount};
}

// 初始化打工页面
function initPetWork(){
  updateWorkPetDisplay();
  renderWorkList();
  startPetWorkTimer();
}

// 更新打工页面宠物状态显示
function updateWorkPetDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  const power = lsGet('pet_power', 0);
  const coins = bpGetCoins();
  
  let mood = '心情不错~', emoji = '🐱';
  if(hunger >= 80){emoji='😺';mood='吃饱喝足，精神满满~';}
  else if(hunger >= 50){emoji='🐱';mood='心情不错~';}
  else if(hunger >= 20){emoji='😿';mood='有点饿了...';}
  else{emoji='😾';mood='饿晕了，快喂我！';}
  
  const setBar = (id, val) => {
    const el = document.getElementById(id);
    if(el) el.style.width = Math.max(0, Math.min(100, val)) + '%';
  };
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if(el) el.textContent = Math.round(val) + '/100';
  };
  
  setText('workHungerText', hunger); setBar('workHungerBar', hunger);
  setText('workCleanText', clean); setBar('workCleanBar', clean);
  setText('workAffectionText', affection); setBar('workAffectionBar', affection);
  
  const e1 = document.getElementById('workPetEmoji'); if(e1) e1.textContent = emoji;
  const e2 = document.getElementById('workPetMood'); if(e2) e2.textContent = mood;
  const e3 = document.getElementById('workPetPower'); if(e3) e3.textContent = power;
  const e4 = document.getElementById('workCoins'); if(e4) e4.textContent = coins;
  
  // 检查是否在打工中
  const workData = lsGet('pet_work_data', null);
  const awayArea = document.getElementById('workAwayArea');
  const listArea = document.getElementById('workListArea');
  if(workData && workData.endTime > Date.now()){
    if(awayArea) awayArea.style.display = 'block';
    if(listArea) listArea.style.display = 'none';
    const job = PET_JOBS.find(j => j.id === workData.jobId);
    if(job){
      const t = document.getElementById('workAwayText');
      if(t) t.textContent = '小橘正在' + job.name + '打工...';
      const r = document.getElementById('workAwayReward');
      if(r) r.textContent = '预计收入 ' + job.coinMin + '~' + job.coinMax + ' 金币';
    }
  } else {
    if(awayArea) awayArea.style.display = 'none';
    if(listArea) listArea.style.display = 'block';
  }
}

// 渲染工作列表
function renderWorkList(){
  const container = document.getElementById('workList');
  if(!container) return;
  container.innerHTML = '';
  PET_JOBS.forEach(job => {
    const unlocked = isJobUnlocked(job.id);
    const progress = getJobUnlockProgress(job.id);
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,0.06);border-left:4px solid ' + job.color + ';' + (unlocked ? '' : 'opacity:0.6;');
    let lockInfo = '';
    if(!unlocked){
      const reqSchool = PET_SCHOOLS.find(s => s.id === job.unlockSchool);
      lockInfo = '<div style="font-size:11px;color:#ef4444;margin-top:4px;">🔒 需' + (reqSchool ? reqSchool.name : '') + '毕业' + progress.required + '次（' + progress.current + '/' + progress.required + '）</div>';
    }
    div.innerHTML = 
      '<div style="display:flex;align-items:center;gap:12px;">' +
        '<div style="font-size:36px;">' + job.emoji + '</div>' +
        '<div style="flex:1;">' +
          '<div style="font-size:15px;font-weight:700;">' + job.name + '</div>' +
          '<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">' + job.desc + '</div>' +
          '<div style="display:flex;gap:10px;margin-top:6px;font-size:11px;color:var(--text-secondary);flex-wrap:wrap;">' +
            '<span>⏱️ ' + job.duration + '秒</span>' +
            '<span>💰 ' + job.coinMin + '~' + job.coinMax + '</span>' +
            '<span>🍖-' + job.hungerCost + '</span>' +
            '<span>🧼-' + job.cleanCost + '</span>' +
          '</div>' +
          lockInfo +
        '</div>' +
        (unlocked ? '<button onclick="sendPetToWork(\'' + job.id + '\')" style="background:linear-gradient(135deg,' + job.color + ',#f59e0b);color:#fff;border:none;padding:8px 18px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.15);flex-shrink:0;">💼 打工</button>' : '') +
      '</div>';
    container.appendChild(div);
  });
}

// 送宠物去打工
function sendPetToWork(jobId){
  const job = PET_JOBS.find(j => j.id === jobId);
  if(!job) return;
  if(!isJobUnlocked(jobId)){
    showToast('🔒 该工作未解锁');
    return;
  }
  // 检查是否正在上学/游玩/打工
  if(lsGet('pet_school_data', null)){
    showToast('⚠️ 小橘正在上学，不能同时打工~');
    return;
  }
  if(lsGet('pet_play_data', null)){
    showToast('⚠️ 小橘正在外面玩，不能同时打工~');
    return;
  }
  if(lsGet('pet_work_data', null)){
    showToast('⚠️ 小橘已经在打工了~');
    return;
  }
  // 检查状态
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  if(hunger < job.hungerCost || clean < job.cleanCost || affection < job.affectionCost){
    showToast('⚠️ 状态不足，先照顾小橘吧~');
    return;
  }
  // 扣除状态
  lsSet('pet_hunger', Math.max(0, hunger - job.hungerCost));
  lsSet('pet_clean', Math.max(0, clean - job.cleanCost));
  lsSet('pet_affection', Math.max(0, affection - job.affectionCost));
  // 记录打工数据
  const workData = {
    jobId: job.id,
    startTime: Date.now(),
    endTime: Date.now() + job.duration * 1000
  };
  lsSet('pet_work_data', workData);
  showToast('💼 小橘去' + job.name + '打工啦！');
  updateWorkPetDisplay();
  startPetWorkTimer();
  // 每日任务进度
  updateDailyTask('daily_pet_work', 1);
}

// 启动打工倒计时
function startPetWorkTimer(){
  if(petWorkTimer){
    clearInterval(petWorkTimer);
    petWorkTimer = null;
  }
  const workData = lsGet('pet_work_data', null);
  if(!workData || workData.endTime <= Date.now()){
    return;
  }
  updateWorkTimerDisplay();
  petWorkTimer = setInterval(() => {
    const data = lsGet('pet_work_data', null);
    if(!data || data.endTime <= Date.now()){
      clearInterval(petWorkTimer);
      petWorkTimer = null;
      completePetWork();
      return;
    }
    updateWorkTimerDisplay();
  }, 1000);
}

// 更新打工倒计时显示
function updateWorkTimerDisplay(){
  const workData = lsGet('pet_work_data', null);
  if(!workData) return;
  const remaining = Math.max(0, Math.ceil((workData.endTime - Date.now()) / 1000));
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const timeStr = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  const el = document.getElementById('workAwayTimer');
  if(el) el.textContent = timeStr;
  // 状态页也同步
  const el2 = document.getElementById('statusPetAwayTimer');
  if(el2 && lsGet('pet_work_data', null)) el2.textContent = timeStr;
}

// 完成打工，获得金币
function completePetWork(){
  const workData = lsGet('pet_work_data', null);
  if(!workData) return;
  const job = PET_JOBS.find(j => j.id === workData.jobId);
  if(!job){ lsSet('pet_work_data', null); return; }
  // 随机金币
  const earned = Math.floor(Math.random() * (job.coinMax - job.coinMin + 1)) + job.coinMin;
  bpAddCoins(earned, 'petWork');
  // 记录打工次数
  const workCounts = lsGet('pet_work_counts', {});
  workCounts[job.id] = (workCounts[job.id] || 0) + 1;
  lsSet('pet_work_counts', workCounts);
  // 累计打工收入
  const totalEarned = lsGet('pet_work_total_earned', 0);
  lsSet('pet_work_total_earned', totalEarned + earned);
  // 清除打工数据
  lsSet('pet_work_data', null);
  showToast('💰 小橘打工回来啦！赚了' + earned + '金币~');
  updatePetStatusDisplay();
  updateWorkPetDisplay();
  renderWorkList();
  if(typeof bpUpdateHomeBadge === 'function') bpUpdateHomeBadge();
}

// 召回宠物（打工中）
function recallPetWork(){
  const workData = lsGet('pet_work_data', null);
  if(!workData) return;
  lsSet('pet_work_data', null);
  if(petWorkTimer){
    clearInterval(petWorkTimer);
    petWorkTimer = null;
  }
  showToast('🏠 小橘被召回啦！（不获得工资）');
  updatePetStatusDisplay();
  updateWorkPetDisplay();
}

