/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageSuperItemShopPage", "<!-- pageSuperItemShopPage -->\n<div class=\"tool-page\" id=\"pageSuperItemShopPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>✨ 超级道具商店</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">上学和出去玩神器！加速卡跳过时长，必出收藏品卡让你必定获得收藏品~</div>\n      \n      <!-- 小橘猫状态 -->\n      <div style=\"background:linear-gradient(180deg,#fef2f2,#fff);border-radius:16px;padding:16px;margin-bottom:16px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;gap:12px;\">\n            <div style=\"font-size:48px;\" id=\"superItemPetEmoji\">🐱</div>\n            <div style=\"text-align:left;\">\n              <div style=\"font-size:16px;font-weight:700;\" id=\"superItemPetName\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"superItemPetStatus\">心情不错~</div>\n            </div>\n          </div>\n          <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n            <div style=\"display:inline-block;background:#fee2e2;color:#ef4444;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n              ⚔️ <span id=\"superItemPetPower\">0</span>\n            </div>\n            <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"superItemCoins\">0</span></div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 道具列表 -->\n      <div id=\"superItemShopList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 道具列表由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ==================== 超级道具系统 ====================
// 道具配置
const SUPER_ITEMS = [
  {
    id: 'speedCard',
    name: '加速卡',
    emoji: '⏩',
    desc: '跳过50%上学剩余时长',
    cost: 20,
    type: 'speed',
    category: 'school'
  },
  {
    id: 'instantCard',
    name: '立即毕业卡',
    emoji: '⚡',
    desc: '直接毕业，获得全部奖励',
    cost: 50,
    type: 'instant',
    category: 'school'
  },
  {
    id: 'doublePowerCard',
    name: '双倍战力卡',
    emoji: '🌟',
    desc: '下次上学获得战力翻倍',
    cost: 30,
    type: 'doublePower',
    category: 'school'
  },
  {
    id: 'guaranteedCollectibleCard',
    name: '必出收藏品卡',
    emoji: '🎁',
    desc: '下次出去玩必定获得收藏品',
    cost: 25,
    type: 'guaranteedCollectible',
    category: 'play'
  },
  {
    id: 'playSpeedCard',
    name: '立即回家卡',
    emoji: '🏠',
    desc: '出去玩时立即结束，马上回家',
    cost: 15,
    type: 'playSpeed',
    category: 'play'
  }
];

// 获取/保存道具仓库
function getSuperItems(){ return lsGet('pet_super_items', {}); }
function saveSuperItems(items){ lsSet('pet_super_items', items); }

// 获取某道具数量
function getSuperItemCount(itemId){
  const items = getSuperItems();
  return items[itemId] || 0;
}

// 初始化超级道具商店
function initSuperItemShop(){
  renderSuperItemShopList();
  updateSuperItemShopDisplay();
}

// 渲染道具商店列表
function renderSuperItemShopList(){
  const container = document.getElementById('superItemShopList');
  if(!container) return;
  container.innerHTML = '';
  
  // 按分类分组
  const categories = [
    {id: 'school', name: '🎒 上学道具', color: '#667eea'},
    {id: 'play', name: '🌳 出去玩道具', color: '#10b981'}
  ];
  
  categories.forEach(cat => {
    const catItems = SUPER_ITEMS.filter(item => item.category === cat.id);
    if(catItems.length === 0) return;
    
    // 分类标题（占满整行）
    const titleDiv = document.createElement('div');
    titleDiv.style.cssText = `grid-column:1/-1;font-size:15px;font-weight:700;color:${cat.color};margin:16px 0 10px;padding-left:4px;`;
    titleDiv.textContent = cat.name;
    container.appendChild(titleDiv);
    
    // 道具网格（占满整行）
    const gridDiv = document.createElement('div');
    gridDiv.style.cssText = 'grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:12px;';
    
    catItems.forEach(item => {
      const count = getSuperItemCount(item.id);
      const div = document.createElement('div');
      div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;border:2px solid transparent;position:relative;';
      div.onmouseover = () => {div.style.transform='scale(1.03)';div.style.borderColor='#f43f5e';};
      div.onmouseout = () => {div.style.transform='scale(1)';div.style.borderColor='transparent';};
      div.onclick = () => buySuperItem(item.id);
      div.innerHTML = `
        ${count > 0 ? `<div style="position:absolute;top:8px;right:8px;background:#f43f5e;color:#fff;border-radius:10px;padding:2px 8px;font-size:11px;font-weight:700;">×${count}</div>` : ''}
        <div style="font-size:36px;">${item.emoji}</div>
        <div style="font-size:15px;font-weight:700;margin-top:8px;">${item.name}</div>
        <div style="font-size:11px;color:#666;margin-top:4px;">${item.desc}</div>
        <div style="margin-top:10px;display:inline-block;background:#fee2e2;color:#ef4444;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700;">
          💰 ${item.cost}
        </div>
      `;
      gridDiv.appendChild(div);
    });
    
    container.appendChild(gridDiv);
  });
}

// 购买超级道具
function buySuperItem(itemId){
  const item = SUPER_ITEMS.find(i => i.id === itemId);
  if(!item) return;
  
  const coins = bpGetCoins();
  if(coins < item.cost){
    showToast('金币不足，去玩游戏赚金币吧~');
    return;
  }
  
  // 扣除金币
  lsSet('backpack_coins', coins - item.cost);
  
  // 加入道具仓库
  const items = getSuperItems();
  items[itemId] = (items[itemId] || 0) + 1;
  saveSuperItems(items);
  
  // 更新显示
  updateSuperItemShopDisplay();
  renderSuperItemShopList();
  if(typeof playSound === 'function') playSound('coin');
  
  showToast(`购买了${item.emoji}${item.name}，${item.category === 'play' ? '出去玩时可以使用~' : '上学时可以使用~'}`);
}

// 更新超级道具商店显示
function updateSuperItemShopDisplay(){
  const power = lsGet('pet_power', 0);
  const coins = bpGetCoins();
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  
  const powerEl = document.getElementById('superItemPetPower');
  const coinsEl = document.getElementById('superItemCoins');
  const emojiEl = document.getElementById('superItemPetEmoji');
  const statusEl = document.getElementById('superItemPetStatus');
  
  if(powerEl) powerEl.textContent = power;
  if(coinsEl) coinsEl.textContent = coins;
  
  // 更新emoji和状态
  let emoji = '🐱', status = '心情不错~';
  if(hunger < 20){ emoji = '😿'; status = '有点饿了...'; }
  else if(clean < 20){ emoji = '🥺'; status = '该洗澡了...'; }
  else if(affection < 20){ emoji = '😾'; status = '有点不开心...'; }
  else if(hunger < 50 || clean < 50 || affection < 50){ emoji = '😺'; status = '还可以~'; }
  
  if(emojiEl) emojiEl.textContent = emoji;
  if(statusEl) statusEl.textContent = status;
}

// 显示道具选择面板
function showSuperItemPanel(){
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData){
    showToast('小橘还没上学呢，先送小橘去上学吧~');
    return;
  }
  
  const items = getSuperItems();
  const schoolItems = SUPER_ITEMS.filter(item => item.category === 'school');
  const hasItems = schoolItems.some(item => (items[item.id] || 0) > 0);
  
  let itemsHtml = '';
  if(hasItems){
    schoolItems.forEach(item => {
      const count = items[item.id] || 0;
      if(count > 0){
        itemsHtml += `
          <div onclick="useSuperItemAndClose('${item.id}')" style="background:var(--card-bg);border-radius:12px;padding:14px;cursor:pointer;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid transparent;transition:all 0.2s;" onmouseover="this.style.borderColor='#f43f5e'" onmouseout="this.style.borderColor='transparent'">
            <div style="font-size:32px;">${item.emoji}</div>
            <div style="font-size:14px;font-weight:700;margin-top:6px;">${item.name}</div>
            <div style="font-size:11px;color:#666;margin-top:2px;">${item.desc}</div>
            <div style="margin-top:6px;display:inline-block;background:#fee2e2;color:#ef4444;border-radius:10px;padding:2px 8px;font-size:12px;font-weight:700;">×${count}</div>
          </div>
        `;
      }
    });
  }
  
  const modalHtml = `
    <div class="modal-mask" id="superItemPanelMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;z-index:1000;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:400px;width:90%;padding:20px;border-radius:20px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;">
          <div style="font-size:18px;font-weight:700;">✨ 选择道具</div>
          <button class="modal-close-btn" onclick="closeSuperItemPanel()" aria-label="关闭超级道具弹窗">×</button>
        </div>
        ${hasItems ? 
          `<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">${itemsHtml}</div>` :
          `<div style="text-align:center;padding:30px 20px;color:#999;">
            <div style="font-size:48px;">📭</div>
            <div style="font-size:14px;margin-top:10px;">还没有道具哦~</div>
            <button onclick="closeSuperItemPanel();openPage('superItemShopPage')" style="margin-top:14px;padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#f43f5e,#f97316);color:#fff;font-size:13px;font-weight:700;cursor:pointer;">去超级道具商店</button>
          </div>`
        }
      </div>
    </div>
  `;
  
  const oldModal = document.getElementById('superItemPanelMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
}

// 关闭道具面板
function closeSuperItemPanel(){
  const modal = document.getElementById('superItemPanelMask');
  if(!modal) return;
  modal.classList.add('closing');
  document.body.style.overflow='';
  setTimeout(() => {
    if(modal.parentNode) modal.parentNode.removeChild(modal);
  }, 200);
}

// 使用道具并关闭面板
function useSuperItemAndClose(itemId){
  closeSuperItemPanel();
  setTimeout(() => useSuperItem(itemId), 100);
}

// 使用超级道具（在上学页面调用）
function useSuperItem(itemId){
  const item = SUPER_ITEMS.find(i => i.id === itemId);
  if(!item) return;
  
  const count = getSuperItemCount(itemId);
  if(count <= 0){
    showToast('没有这个道具哦，去超级道具商店购买吧~');
    return;
  }
  
  const schoolData = lsGet('pet_school_data', null);
  if(!schoolData){
    showToast('小橘还没上学呢，先送小橘去上学吧~');
    return;
  }
  
  // 扣除道具
  const items = getSuperItems();
  items[itemId]--;
  if(items[itemId] <= 0) delete items[itemId];
  saveSuperItems(items);
  
  // 记录使用
  recordUsage('superItem', item.id, item.name, item.emoji);
  
  if(item.type === 'speed'){
    // 加速卡：跳过50%剩余时长
    const now = Date.now();
    const remaining = schoolData.endTime - now;
    if(remaining <= 0){
      showToast('小橘已经毕业啦~');
      return;
    }
    const skipTime = Math.floor(remaining * 0.5);
    schoolData.endTime = now + (remaining - skipTime);
    lsSet('pet_school_data', schoolData);
    startPetSchoolTimer();
    showToast('⏩ 使用加速卡！上学时间缩短一半啦~');
  } else if(item.type === 'instant'){
    // 立即毕业卡：直接毕业
    showToast('⚡ 使用立即毕业卡！小橘马上毕业~');
    setTimeout(() => {
      completePetSchool();
    }, 500);
  } else if(item.type === 'doublePower'){
    // 双倍战力卡：设置标记，下次毕业战力翻倍
    lsSet('pet_double_power_next', true);
    showToast('🌟 使用双倍战力卡！下次毕业战力翻倍~');
  }
  
  // 刷新上学页面
  if(typeof renderSchoolList === 'function') renderSchoolList();
}

