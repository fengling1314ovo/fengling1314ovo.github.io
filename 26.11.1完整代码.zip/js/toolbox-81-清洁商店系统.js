/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageCleanShopPage", "<!-- pageCleanShopPage -->\n<div class=\"tool-page\" id=\"pageCleanShopPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🧼 清洁商店</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">给小橘买清洁用品，保持干净~ 点击物品购买后放入仓库，再从仓库使用！</div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);display:flex;align-items:center;justify-content:space-between;\">\n        <div style=\"display:flex;align-items:center;\">\n          <div style=\"font-size:48px;\" id=\"cleanPetEmoji\">🐱</div>\n          <div style=\"margin-left:12px;\">\n            <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n            <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"cleanPetMood\">心情不错~</div>\n          </div>\n        </div>\n        <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n          <div style=\"display:inline-block;background:#dbeafe;color:#3b82f6;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n            🧼 <span id=\"cleanPetClean\">100</span>\n          </div>\n          <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"cleanCoins\">0</span></div>\n        </div>\n      </div>\n      \n      <!-- 清洁用品列表 -->\n      <div id=\"cleanShopList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 清洁用品列表由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ==================== 清洁商店系统 ====================
// 初始化清洁商店页面
function initCleanShop(){
  renderCleanShopList();
  updateCleanShopDisplay();
}

// 更新清洁商店页面显示
function updateCleanShopDisplay(){
  const clean = lsGet('pet_clean', 100);
  const cleanPercent = Math.max(0, Math.min(100, clean));
  const hunger = lsGet('pet_hunger', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  const affection = lsGet('pet_affection', 50);
  const affectionPercent = Math.max(0, Math.min(100, affection));
  
  // 根据状态更新表情和心情
  let mood, emoji;
  if(hungerPercent >= 80 && cleanPercent >= 80){ mood='吃饱喝足，超级开心~'; emoji='😺'; }
  else if(hungerPercent >= 50 && cleanPercent >= 50){ mood='心情不错~'; emoji='🐱'; }
  else if(hungerPercent >= 20 && cleanPercent >= 20){ mood='有点饿了/该洗澡了...'; emoji='😿'; }
  else{ mood='快饿晕啦/脏死啦，快照顾我！'; emoji='😾'; }
  if(cleanPercent < 30){ emoji = '🥺'; mood = '脏死啦，快给我洗澡！'; }
  
  const elEmoji = document.getElementById('cleanPetEmoji');
  const elMood = document.getElementById('cleanPetMood');
  const elClean = document.getElementById('cleanPetClean');
  const elCoins = document.getElementById('cleanCoins');
  const elAffection = document.getElementById('cleanPetAffection');
  if(elEmoji) elEmoji.textContent = emoji;
  if(elMood) elMood.textContent = mood;
  if(elClean) elClean.textContent = cleanPercent;
  if(elCoins) elCoins.textContent = bpGetCoins();
  if(elAffection) elAffection.textContent = affectionPercent;
}

// 渲染清洁用品列表
function renderCleanShopList(){
  const container = document.getElementById('cleanShopList');
  if(!container) return;
  container.innerHTML = '';
  PET_CLEAN_ITEMS.forEach(item => {
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;border:2px solid transparent;';
    div.onmouseover = () => {div.style.transform='scale(1.03)';div.style.borderColor='#3b82f6';};
    div.onmouseout = () => {div.style.transform='scale(1)';div.style.borderColor='transparent';};
    div.onclick = () => showBuyQuantityModal(item, 'clean');
    div.innerHTML = `
      <div style="font-size:36px;">${item.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${item.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${item.clean}清洁值</div>
      <div style="margin-top:8px;display:inline-block;background:#dbeafe;color:#3b82f6;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700;">
        💰 ${item.cost}
      </div>
    `;
    container.appendChild(div);
  });
}



