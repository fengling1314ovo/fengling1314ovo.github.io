// ==================== 出去玩超级道具系统 ====================

// 显示出去玩道具面板
function showPlaySuperItemPanel(){
  const playData = lsGet('pet_play_data', null);
  if(!playData){
    showToast('小橘还没出去玩呢，先带小橘出去玩吧~');
    return;
  }
  
  const items = getSuperItems();
  const playItems = SUPER_ITEMS.filter(item => item.category === 'play');
  const hasItems = playItems.some(item => (items[item.id] || 0) > 0);
  
  let itemsHtml = '';
  if(hasItems){
    playItems.forEach(item => {
      const count = items[item.id] || 0;
      if(count > 0){
        itemsHtml += `
          <div onclick="usePlaySuperItemAndClose('${item.id}')" style="background:var(--card-bg);border-radius:12px;padding:14px;cursor:pointer;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid transparent;transition:all 0.2s;" onmouseover="this.style.borderColor='#f43f5e'" onmouseout="this.style.borderColor='transparent'">
            <div style="font-size:32px;">${item.emoji}</div>
            <div style="font-size:14px;font-weight:700;margin-top:6px;">${item.name}</div>
            <div style="font-size:11px;color:#666;margin-top:2px;">${item.desc}</div>
            <div style="margin-top:6px;display:inline-block;background:#fee2e2;color:#ef4444;border-radius:10px;padding:2px 8px;font-size:12px;font-weight:700;">×${count}</div>
          </div>
        `;
      }
    });
  }
  
  const modalHtml = `
    <div class="modal-mask" id="playSuperItemPanelMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100vw;height:100vh;z-index:99999;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:400px;width:90%;padding:20px;border-radius:20px;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;">
          <div style="font-size:18px;font-weight:700;">✨ 选择道具</div>
          <button class="modal-close-btn" onclick="closePlaySuperItemPanel()" aria-label="关闭外出道具弹窗">×</button>
        </div>
        ${hasItems ? 
          `<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;">${itemsHtml}</div>` :
          `<div style="text-align:center;padding:30px 20px;color:#999;">
            <div style="font-size:48px;">📭</div>
            <div style="font-size:14px;margin-top:10px;">还没有出去玩道具哦~</div>
            <button onclick="closePlaySuperItemPanel();openPage('superItemShopPage')" style="margin-top:14px;padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#f43f5e,#f97316);color:#fff;font-size:13px;font-weight:700;cursor:pointer;">去超级道具商店</button>
          </div>`
        }
      </div>
    </div>
  `;
  
  const oldModal = document.getElementById('playSuperItemPanelMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
}

// 关闭出去玩道具面板
function closePlaySuperItemPanel(){
  const modal = document.getElementById('playSuperItemPanelMask');
  if(!modal) return;
  modal.classList.add('closing');
  document.body.style.overflow='';
  setTimeout(() => {
    if(modal.parentNode) modal.parentNode.removeChild(modal);
  }, 200);
}

// 使用出去玩道具并关闭面板
function usePlaySuperItemAndClose(itemId){
  closePlaySuperItemPanel();
  usePlaySuperItem(itemId);
}

// 使用出去玩道具
function usePlaySuperItem(itemId){
  const item = SUPER_ITEMS.find(i => i.id === itemId);
  if(!item) return;
  
  const count = getSuperItemCount(itemId);
  if(count <= 0){
    showToast('没有这个道具哦，去超级道具商店购买吧~');
    return;
  }
  
  const playData = lsGet('pet_play_data', null);
  if(!playData){
    showToast('小橘还没出去玩呢，先带小橘出去玩吧~');
    return;
  }
  
  // 扣除道具
  const items = getSuperItems();
  items[itemId] = count - 1;
  saveSuperItems(items);
  
  // 记录使用历史
  recordUsage('superItem', item.id, item.name, item.emoji);
  
  if(item.type === 'playSpeed'){
    // 立即回家卡：将游玩结束时间缩短到0.1秒后
    playData.endTime = Date.now() + 100;
    lsSet('pet_play_data', playData);
    startPlayTimer();
    showToast('🏠 使用立即回家卡！小橘马上回来啦~');
  } else if(item.type === 'guaranteedCollectible'){
    // 必出收藏品卡：设置标记，游玩结束时必定获得收藏品
    lsSet('pet_guaranteed_collectible', true);
    showToast('🎁 使用必出收藏品卡！这次游玩必定获得收藏品~');
  }
  
  // 更新UI
  updatePlayUI();
  if(typeof playSound === 'function') playSound('success');
}

// 初始化使用统计页面
function initUsageStats(){
  renderUsageStats();
}

// 渲染使用统计
function renderUsageStats(){
  const history = lsGet('pet_usage_history', []);
  
  // 统计各类别数量
  let foodCount = 0, cleanCount = 0, toyCount = 0, superItemCount = 0;
  history.forEach(record => {
    if(record.type === 'food') foodCount++;
    else if(record.type === 'clean') cleanCount++;
    else if(record.type === 'toy') toyCount++;
    else if(record.type === 'superItem') superItemCount++;
  });
  
  // 更新统计数字
  const elFood = document.getElementById('statsFoodCount');
  const elClean = document.getElementById('statsCleanCount');
  const elToy = document.getElementById('statsToyCount');
  const elSuper = document.getElementById('statsSuperItemCount');
  
  if(elFood) elFood.textContent = foodCount;
  if(elClean) elClean.textContent = cleanCount;
  if(elToy) elToy.textContent = toyCount;
  if(elSuper) elSuper.textContent = superItemCount;
  
  // 渲染历史记录
  const listEl = document.getElementById('usageHistoryList');
  const emptyEl = document.getElementById('usageHistoryEmpty');
  
  if(!listEl) return;
  
  if(history.length === 0){
    listEl.style.display = 'none';
    if(emptyEl) emptyEl.style.display = 'block';
    return;
  }
  
  listEl.style.display = 'flex';
  if(emptyEl) emptyEl.style.display = 'none';
  
  // 类型颜色映射
  const typeColors = {
    food: {bg: '#fef2f2', text: '#dc2626', label: '食物'},
    clean: {bg: '#eff6ff', text: '#2563eb', label: '清洁'},
    toy: {bg: '#fdf2f8', text: '#db2777', label: '玩具'},
    superItem: {bg: '#fffbeb', text: '#d97706', label: '道具'}
  };
  
  listEl.innerHTML = history.slice(0, 100).map(record => {
    const date = new Date(record.timestamp);
    const dateStr = `${date.getMonth()+1}/${date.getDate()} ${String(date.getHours()).padStart(2,'0')}:${String(date.getMinutes()).padStart(2,'0')}`;
    const color = typeColors[record.type] || typeColors.food;
    
    return `
      <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:${color.bg};border-radius:10px;">
        <div style="font-size:24px;">${record.itemEmoji}</div>
        <div style="flex:1;">
          <div style="font-size:13px;font-weight:600;color:#333;">${record.itemName}</div>
          <div style="font-size:11px;color:#999;margin-top:1px;">${dateStr}</div>
        </div>
        <div style="background:${color.text};color:#fff;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:600;">${color.label}</div>
      </div>
    `;
  }).join('');
}

// 清空使用记录
function clearUsageHistory(){
  if(confirm('确定要清空所有使用记录吗？此操作不可恢复。')){
    lsSet('pet_usage_history', []);
    renderUsageStats();
    showToast('使用记录已清空~');
  }
}

