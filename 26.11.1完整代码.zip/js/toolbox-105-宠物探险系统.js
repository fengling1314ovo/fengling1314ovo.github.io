/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetExplorePage", "<!-- pagePetExplorePage -->\n<div class=\"tool-page\" id=\"pagePetExplorePage\">\n  <div class=\"tool-header\">\n    <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n  </div>\n  <div class=\"breadcrumb\"></div>\n  <div class=\"common-block\" style=\"padding:0 28px 32px\">\n    <h3>🗺️ 宠物探险</h3>\n    <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">派小橘去各地冒险吧！带回金币和稀有宝藏，还有意外事件哦~ 关闭浏览器时间也会继续走</div>\n\n    <!-- 小橘状态 -->\n    <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n      <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n        <div style=\"display:flex;align-items:center;\">\n          <div style=\"font-size:48px;\" id=\"explorePetEmoji\">🐱</div>\n          <div style=\"margin-left:12px;\">\n            <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n            <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"explorePetMood\">心情不错~</div>\n          </div>\n        </div>\n        <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n          <div style=\"display:inline-block;background:#fef3c7;color:#f59e0b;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n            ⚔️ <span id=\"explorePetPower\">0</span>\n          </div>\n          <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"exploreCoins\">0</span></div>\n        </div>\n      </div>\n      <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n        <div>\n          <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n            <span>🍖 饱食</span><span id=\"exploreHungerText\">50/100</span>\n          </div>\n          <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n            <div id=\"exploreHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;\"></div>\n          </div>\n        </div>\n        <div>\n          <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n            <span>🧼 清洁</span><span id=\"exploreCleanText\">100/100</span>\n          </div>\n          <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n            <div id=\"exploreCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;\"></div>\n          </div>\n        </div>\n        <div>\n          <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n            <span>💕 好感</span><span id=\"exploreAffectionText\">50/100</span>\n          </div>\n          <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n            <div id=\"exploreAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;\"></div>\n          </div>\n        </div>\n      </div>\n    </div>\n\n    <!-- 探险中状态 -->\n    <div id=\"exploreAwayArea\" style=\"display:none;margin-bottom:14px;\">\n      <div style=\"background:linear-gradient(135deg,#ede9fe,#ddd6fe);border-radius:16px;padding:20px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"font-size:48px;\" id=\"exploreAwayEmoji\">🗺️</div>\n        <div style=\"font-size:16px;font-weight:700;color:#5b21b6;margin-top:8px;\" id=\"exploreAwayText\">小橘正在探险...</div>\n        <div style=\"font-size:28px;font-weight:700;color:#5b21b6;margin-top:10px;\" id=\"exploreAwayTimer\">00:00</div>\n        <div style=\"font-size:13px;color:#6d28d9;margin-top:8px;\" id=\"exploreAwayReward\">探索中，期待宝藏~</div>\n        <button onclick=\"recallPetExplore()\" style=\"margin-top:14px;background:#ef4444;color:#fff;border:none;padding:10px 24px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(239,68,68,0.3);\">\n          🏠 召回宠物（无奖励）\n        </button>\n      </div>\n    </div>\n\n    <!-- 探险地点列表 -->\n    <div id=\"exploreListArea\">\n      <div style=\"display:grid;gap:12px;\" id=\"exploreList\">\n        <!-- 地点列表由JS生成 -->\n      </div>\n    </div>\n\n    <!-- 探险仓库 -->\n    <div style=\"margin-top:18px;\">\n      <div style=\"display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;\">\n        <div style=\"font-size:15px;font-weight:700;\">🎒 探险背包</div>\n        <span style=\"font-size:12px;color:var(--text-secondary);\">已收集 <span id=\"exploreItemCount\">0</span> 件宝物</span>\n      </div>\n      <div id=\"exploreItemsBox\" style=\"display:flex;flex-wrap:wrap;gap:8px;min-height:50px;background:var(--card-bg);border-radius:14px;padding:12px;box-shadow:0 2px 8px rgba(0,0,0,0.06);\">\n        <span style=\"font-size:12px;color:var(--text-placeholder);margin:auto;\">去探险带回宝物吧~</span>\n      </div>\n    </div>\n  </div>\n</div>");
// ==================== 宠物探险系统 ====================
const PET_EXPLORE_PLACES = [
  {id:'forest', name:'神秘森林', emoji:'🌲', duration:30, hungerCost:10, cleanCost:5, coinMin:10, coinMax:30,
   items:[{emoji:'🍄',name:'蘑菇'},{emoji:'🌰',name:'板栗'},{emoji:'🪵',name:'树枝'},{emoji:'🌸',name:'野花'}],
   eventChance:0.0, desc:'在林间散步，采采野果~', color:'#34d399'},
  {id:'cave', name:'幽暗山洞', emoji:'🕳️', duration:60, hungerCost:15, cleanCost:10, coinMin:20, coinMax:50,
   items:[{emoji:'💎',name:'宝石'},{emoji:'🪨',name:'矿石'},{emoji:'📜',name:'古地图'},{emoji:'🦇',name:'小蝙蝠'}],
   eventChance:0.3, desc:'探险洞窟，有稀有宝藏，也有危险！', color:'#8b5cf6'},
  {id:'beach', name:'海边沙滩', emoji:'🌊', duration:45, hungerCost:8, cleanCost:15, coinMin:15, coinMax:40,
   items:[{emoji:'🐚',name:'贝壳'},{emoji:'🦀',name:'小螃蟹'},{emoji:'⭐',name:'海星'},{emoji:'🫧',name:'水晶'}],
   eventChance:0.15, desc:'海边漫步，捡贝壳吹海风~', color:'#60a5fa'},
  {id:'city', name:'城市冒险', emoji:'🏙️', duration:90, hungerCost:20, cleanCost:5, coinMin:30, coinMax:80,
   items:[{emoji:'🎁',name:'神秘礼盒'},{emoji:'📰',name:'旧报纸'},{emoji:'🎫',name:'电影票'},{emoji:'🍬',name:'糖果'}],
   eventChance:0.35, desc:'逛遍大街小巷，惊喜多多！', color:'#f59e0b'}
];

let petExploreTimer = null;

// 初始化宠物探险页面
function initPetExplore(){
  // 页面打开时检查是否已到期自动结算
  const ed = lsGet('pet_explore_data', null);
  if(ed && ed.endTime <= Date.now()){
    completePetExplore();
  }
  updateExplorePetDisplay();
  renderExploreList();
  renderExploreItems();
  startPetExploreTimer();
}

// 更新探险页面宠物状态显示
function updateExplorePetDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  const affection = lsGet('pet_affection', 50);
  const power = lsGet('pet_power', 0);
  const coins = bpGetCoins();

  let mood = '心情不错~', emoji = '🐱';
  if(hunger >= 80){emoji='😺';mood='吃饱喝足，准备出发~';}
  else if(hunger >= 50){emoji='🐱';mood='心情不错~';}
  else if(hunger >= 20){emoji='😿';mood='有点饿了...';}
  else{emoji='😾';mood='饿晕了，先喂我！';}

  const setBar = (id, val) => {
    const el = document.getElementById(id);
    if(el) el.style.width = Math.max(0, Math.min(100, val)) + '%';
  };
  const setText = (id, val) => {
    const el = document.getElementById(id);
    if(el) el.textContent = Math.round(val) + '/100';
  };

  setText('exploreHungerText', hunger); setBar('exploreHungerBar', hunger);
  setText('exploreCleanText', clean); setBar('exploreCleanBar', clean);
  setText('exploreAffectionText', affection); setBar('exploreAffectionBar', affection);

  const e1 = document.getElementById('explorePetEmoji'); if(e1) e1.textContent = emoji;
  const e2 = document.getElementById('explorePetMood'); if(e2) e2.textContent = mood;
  const e3 = document.getElementById('explorePetPower'); if(e3) e3.textContent = power;
  const e4 = document.getElementById('exploreCoins'); if(e4) e4.textContent = coins;

  // 检查是否在探险中
  const ed = lsGet('pet_explore_data', null);
  const awayArea = document.getElementById('exploreAwayArea');
  const listArea = document.getElementById('exploreListArea');
  if(ed && ed.endTime > Date.now()){
    if(awayArea) awayArea.style.display = 'block';
    if(listArea) listArea.style.display = 'none';
    const place = PET_EXPLORE_PLACES.find(p => p.id === ed.placeId);
    if(place){
      const t = document.getElementById('exploreAwayText');
      if(t) t.textContent = '小橘正在' + place.name + '探险...';
      const em = document.getElementById('exploreAwayEmoji');
      if(em) em.textContent = place.emoji;
      const r = document.getElementById('exploreAwayReward');
      if(r) r.textContent = '预计 ' + place.coinMin + '~' + place.coinMax + ' 金币 + 神秘宝物';
    }
  } else {
    if(awayArea) awayArea.style.display = 'none';
    if(listArea) listArea.style.display = 'block';
  }
}

// 渲染探险地点列表
function renderExploreList(){
  const container = document.getElementById('exploreList');
  if(!container) return;
  container.innerHTML = '';
  PET_EXPLORE_PLACES.forEach(place => {
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;box-shadow:0 2px 8px rgba(0,0,0,0.06);border-left:4px solid ' + place.color + ';';
    div.innerHTML =
      '<div style="display:flex;align-items:center;gap:12px;">' +
        '<div style="font-size:36px;">' + place.emoji + '</div>' +
        '<div style="flex:1;">' +
          '<div style="font-size:15px;font-weight:700;">' + place.name + '</div>' +
          '<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">' + place.desc + '</div>' +
          '<div style="display:flex;gap:10px;margin-top:6px;font-size:11px;color:var(--text-secondary);flex-wrap:wrap;">' +
            '<span>⏱️ ' + place.duration + '秒</span>' +
            '<span>💰 ' + place.coinMin + '~' + place.coinMax + '</span>' +
            '<span>🍖-' + place.hungerCost + '</span>' +
            '<span>🧼-' + place.cleanCost + '</span>' +
            (place.eventChance > 0 ? '<span style="color:#8b5cf6;">✨有事件</span>' : '') +
          '</div>' +
        '</div>' +
        '<button onclick="sendPetToExplore(\'' + place.id + '\')" style="background:linear-gradient(135deg,' + place.color + ',#8b5cf6);color:#fff;border:none;padding:8px 18px;border-radius:10px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(0,0,0,0.15);flex-shrink:0;">🗺️ 出发</button>' +
      '</div>';
    container.appendChild(div);
  });
}

// 检查小橘是否在忙（上学/打工/探险任一未到期）
function isPetBusy(){
  const sd = lsGet('pet_school_data', null);
  if(sd && sd.endTime && sd.endTime > Date.now()) return {busy:true, type:'school'};
  const wd = lsGet('pet_work_data', null);
  if(wd && wd.endTime && wd.endTime > Date.now()) return {busy:true, type:'work'};
  const ed = lsGet('pet_explore_data', null);
  if(ed && ed.endTime && ed.endTime > Date.now()) return {busy:true, type:'explore'};
  return {busy:false};
}

// 送小橘去探险
function sendPetToExplore(placeId){
  const place = PET_EXPLORE_PLACES.find(p => p.id === placeId);
  if(!place) return;
  // 检查忙碌状态
  const busy = isPetBusy();
  if(busy.busy){
    if(busy.type === 'school') showToast('⚠️ 小橘正在上学，不能同时探险~');
    else if(busy.type === 'work') showToast('⚠️ 小橘正在打工，不能同时探险~');
    else showToast('⚠️ 小橘已经在探险了~');
    return;
  }
  // 检查属性
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  if(hunger < place.hungerCost || clean < place.cleanCost){
    showToast('⚠️ 饱食或清洁不足，先照顾小橘吧~');
    return;
  }
  // 扣除属性
  lsSet('pet_hunger', Math.max(0, hunger - place.hungerCost));
  lsSet('pet_clean', Math.max(0, clean - place.cleanCost));
  // 记录探险数据
  const exploreData = {
    placeId: place.id,
    startTime: Date.now(),
    endTime: Date.now() + place.duration * 1000
  };
  lsSet('pet_explore_data', exploreData);
  // 记录当日事件
  recordPetDailyEvent('小橘去' + place.name + '探险啦');
  showToast('🗺️ 小橘出发去' + place.name + '！');
  updateExplorePetDisplay();
  updatePetStatusDisplay();
  startPetExploreTimer();
}

// 启动探险倒计时
function startPetExploreTimer(){
  if(petExploreTimer){
    clearInterval(petExploreTimer);
    petExploreTimer = null;
  }
  const ed = lsGet('pet_explore_data', null);
  if(!ed || ed.endTime <= Date.now()){
    return;
  }
  updateExploreTimerDisplay();
  petExploreTimer = setInterval(() => {
    const data = lsGet('pet_explore_data', null);
    if(!data || data.endTime <= Date.now()){
      clearInterval(petExploreTimer);
      petExploreTimer = null;
      completePetExplore();
      return;
    }
    updateExploreTimerDisplay();
    updateExploreStatusDisplay();
  }, 1000);
}

// 更新探险倒计时显示
function updateExploreTimerDisplay(){
  const ed = lsGet('pet_explore_data', null);
  if(!ed) return;
  const remaining = Math.max(0, Math.ceil((ed.endTime - Date.now()) / 1000));
  const minutes = Math.floor(remaining / 60);
  const seconds = remaining % 60;
  const timeStr = String(minutes).padStart(2, '0') + ':' + String(seconds).padStart(2, '0');
  const el = document.getElementById('exploreAwayTimer');
  if(el) el.textContent = timeStr;
}

// 完成探险结算
function completePetExplore(){
  const ed = lsGet('pet_explore_data', null);
  if(!ed) return;
  const place = PET_EXPLORE_PLACES.find(p => p.id === ed.placeId);
  if(!place){ lsSet('pet_explore_data', null); return; }

  // 随机金币
  const earned = Math.floor(Math.random() * (place.coinMax - place.coinMin + 1)) + place.coinMin;
  bpAddCoins(earned, 'petExplore');

  // 随机物品（每个地点带1-2件）
  const items = lsGet('pet_explore_items', []);
  const itemCount = 1 + Math.floor(Math.random() * 2); // 1~2件
  const gotItems = [];
  for(let i = 0; i < itemCount; i++){
    const it = place.items[Math.floor(Math.random() * place.items.length)];
    // 合并同类物品
    const exist = items.find(x => x.emoji === it.emoji);
    if(exist) exist.count = (exist.count || 1) + 1;
    else items.push({emoji: it.emoji, name: it.name, count: 1, place: place.name});
    gotItems.push(it.emoji + it.name);
  }
  lsSet('pet_explore_items', items);

  // 随机事件
  let eventMsg = '';
  let moodDelta = 0;
  if(place.eventChance > 0 && Math.random() < place.eventChance){
    const events = [
      {type:'money', text:'小橘在路上捡到了金币！💰', effect:()=>{const b=Math.floor(Math.random()*15)+5;bpAddCoins(b,'petExploreLucky');eventMsg+=' 还捡到了'+b+'金币！';}},
      {type:'friend', text:'小橘遇到了好朋友一起玩耍~', effect:()=>{const a=lsGet('pet_affection',50);lsSet('pet_affection',Math.min(100,a+8));moodDelta=8;eventMsg+=' 还遇到了新朋友，好感度提升了！';}},
      {type:'hurt', text:'小橘不小心摔了一跤...', effect:()=>{const p=lsGet('pet_power',0);lsSet('pet_power',Math.max(0,p-3));eventMsg+=' 不过有点小擦伤，战力-3';}},
      {type:'rare', text:'小橘发现了稀有宝物！✨', effect:()=>{const rare={emoji:'🏆',name:'勇者勋章',count:1,place:place.name};const arr=lsGet('pet_explore_items',[]);arr.push(rare);lsSet('pet_explore_items',arr);gotItems.push('🏆勇者勋章');eventMsg+=' 还获得了稀有宝物【勇者勋章】！';}}
    ];
    const ev = events[Math.floor(Math.random() * events.length)];
    ev.effect();
    recordPetDailyEvent(ev.text);
  }

  // 清除探险数据
  lsSet('pet_explore_data', null);

  // 记录当日事件
  recordPetDailyEvent('小橘从' + place.name + '探险回来，赚了' + earned + '金币，带回了' + gotItems.join('、'));
  // 自动触发日记
  generatePetDiary();

  // 反馈
  let toastMsg = '🗺️ 小橘探险回来啦！💰+' + earned;
  if(gotItems.length) toastMsg += ' 🎒获得' + gotItems.join('、');
  if(eventMsg) toastMsg += eventMsg;
  showToast(toastMsg);

  if(typeof bpUpdateHomeBadge === 'function') bpUpdateHomeBadge();
  updatePetStatusDisplay();
  updateExplorePetDisplay();
  renderExploreList();
  renderExploreItems();
}

// 召回探险中的小橘（无奖励）
function recallPetExplore(){
  const ed = lsGet('pet_explore_data', null);
  if(!ed) return;
  lsSet('pet_explore_data', null);
  if(petExploreTimer){
    clearInterval(petExploreTimer);
    petExploreTimer = null;
  }
  recordPetDailyEvent('小橘的探险被提前召回了');
  showToast('🏠 小橘被召回啦！（无奖励）');
  updatePetStatusDisplay();
  updateExplorePetDisplay();
}

// 渲染探险背包
function renderExploreItems(){
  const items = lsGet('pet_explore_items', []);
  const box = document.getElementById('exploreItemsBox');
  const cnt = document.getElementById('exploreItemCount');
  if(cnt) cnt.textContent = items.reduce((s,x)=>s+(x.count||1),0);
  if(!box) return;
  if(!items.length){
    box.innerHTML = '<span style="font-size:12px;color:var(--text-placeholder);margin:auto;">去探险带回宝物吧~</span>';
    return;
  }
  box.innerHTML = '';
  items.forEach(it => {
    const div = document.createElement('div');
    div.style.cssText = 'background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:10px;padding:8px 12px;text-align:center;min-width:70px;box-shadow:0 2px 6px rgba(245,158,11,0.15);';
    div.title = (it.place || '') + '带回';
    div.innerHTML = '<div style="font-size:24px;">' + it.emoji + '</div>' +
      '<div style="font-size:11px;color:#92400e;margin-top:2px;font-weight:600;">' + it.name + '</div>' +
      '<div style="font-size:10px;color:#b45309;">×' + (it.count || 1) + '</div>';
    box.appendChild(div);
  });
}

// 供状态页调用：显示探险中的状态
function updateExploreStatusDisplay(){
  const ed = lsGet('pet_explore_data', null);
  const elHomeArea = document.getElementById('statusPetHomeArea');
  const elAwayArea = document.getElementById('statusPetAwayArea');
  if(!elAwayArea) return;

  if(ed && ed.endTime > Date.now()){
    // 仅当当前没有其他活动状态时才接管显示
    const sd = lsGet('pet_school_data', null);
    const wd = lsGet('pet_work_data', null);
    const pd = lsGet('pet_play_data', null);
    const otherActive = (sd && sd.endTime > Date.now()) || (wd && wd.endTime > Date.now()) || (pd && pd.endTime > Date.now());
    if(otherActive) return;

    if(elHomeArea) elHomeArea.style.display = 'none';
    elAwayArea.style.display = 'block';
    const place = PET_EXPLORE_PLACES.find(p => p.id === ed.placeId);
    const elAwayText = document.getElementById('statusPetAwayText');
    if(elAwayText) elAwayText.textContent = place ? '小橘正在' + place.name + '探险...' : '小橘正在探险...';

    const recallBtn = document.querySelector('#statusPetAwayArea button');
    if(recallBtn){
      recallBtn.style.display = 'block';
      recallBtn.textContent = '🏠 召回宠物（无奖励）';
      recallBtn.onclick = recallPetExplore;
    }
    const allBtns = document.querySelectorAll('#statusPetAwayArea button');
    if(allBtns.length > 1) allBtns[1].style.display = 'none';

    const remaining = Math.max(0, ed.endTime - Date.now());
    const timerEl = document.getElementById('statusPetAwayTimer');
    if(timerEl){
      const mins = Math.floor(remaining / 60000);
      const secs = Math.floor((remaining % 60000) / 1000);
      timerEl.textContent = String(mins).padStart(2,'0') + ':' + String(secs).padStart(2,'0');
    }
  }
}

