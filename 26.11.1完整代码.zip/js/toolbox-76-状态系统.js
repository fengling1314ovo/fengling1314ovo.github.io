/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageStatusPage", "<!-- pageStatusPage -->\n<div class=\"tool-page\" id=\"pageStatusPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('chestHome')\"><span>←</span> 返回百宝箱</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>📊 个人状态</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">查看你的数据信息和宠物成长统计</div>\n      \n      <!-- 数据信息卡片 -->\n      <div style=\"background:var(--card-bg);border-radius:16px;padding:18px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <h4 style=\"margin:0 0 12px 0;font-size:15px;\">📊 数据信息</h4>\n        <div class=\"status-data-grid\" style=\"display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;\">\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:var(--text-secondary);\">首次进入</div>\n            <div style=\"font-size:16px;font-weight:700;color:var(--primary);margin-top:4px;\" id=\"statusFirstVisit\">--</div>\n          </div>\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:var(--text-secondary);\">访问次数</div>\n            <div style=\"font-size:16px;font-weight:700;color:var(--primary);margin-top:4px;\" id=\"statusVisitCount\">0</div>\n          </div>\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:var(--text-secondary);\">当前金币</div>\n            <div style=\"font-size:16px;font-weight:700;color:#f59e0b;margin-top:4px;\" id=\"statusCoins\">0</div>\n          </div>\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:var(--text-secondary);\">弹珠总数</div>\n            <div style=\"font-size:16px;font-weight:700;color:#ef4444;margin-top:4px;\" id=\"statusPinballs\">0</div>\n          </div>\n          <div style=\"background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:#92400e;\">⚔️ 总战力</div>\n            <div style=\"font-size:16px;font-weight:700;color:#d97706;margin-top:4px;\" id=\"statusTotalPower\">0</div>\n          </div>\n          <div style=\"background:linear-gradient(135deg,#dbeafe,#bfdbfe);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:#1e40af;\">🏫 累计上学</div>\n            <div style=\"font-size:16px;font-weight:700;color:#2563eb;margin-top:4px;\" id=\"statusTotalSchool\">0次</div>\n          </div>\n          <div style=\"background:linear-gradient(135deg,#dcfce7,#bbf7d0);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:#166534;\">🎓 当前学历</div>\n            <div style=\"font-size:16px;font-weight:700;color:#16a34a;margin-top:4px;\" id=\"statusCurrentDegree\">--</div>\n          </div>\n          <div style=\"background:linear-gradient(135deg,#f3e8ff,#e9d5ff);border-radius:12px;padding:12px;\">\n            <div style=\"font-size:12px;color:#6b21a8;\">📦 累计使用</div>\n            <div style=\"font-size:16px;font-weight:700;color:#9333ea;margin-top:4px;\" id=\"statusTotalUsage\">0次</div>\n          </div>\n          <div class=\"status-stats-btn\" onclick=\"openPage('usageStatsPage')\" style=\"background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:12px;padding:12px;cursor:pointer;box-shadow:0 2px 8px rgba(245,158,11,0.2);border:2px solid #f59e0b;transition:all 0.2s;\" onmouseover=\"this.style.transform='scale(1.02)'\" onmouseout=\"this.style.transform='scale(1)'\">\n            <div style=\"font-size:12px;color:#92400e;\">📊 统计信息</div>\n            <div style=\"font-size:16px;font-weight:700;color:#d97706;margin-top:4px;\">查看使用记录 →</div>\n          </div>\n        </div>\n      </div>\n\n      <!-- 收藏统计卡片 -->\n      <div style=\"background:var(--card-bg);border-radius:16px;padding:18px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <h4 style=\"margin:0 0 12px 0;font-size:15px;\">📦 收藏统计</h4>\n        <div style=\"display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;\">\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;text-align:center;\">\n            <div style=\"font-size:20px;\">🃏</div>\n            <div style=\"font-size:12px;color:var(--text-secondary);margin-top:4px;\">卡牌数量</div>\n            <div style=\"font-size:16px;font-weight:700;color:var(--primary);\" id=\"statusCards\">0</div>\n          </div>\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;text-align:center;\">\n            <div style=\"font-size:20px;\">🎁</div>\n            <div style=\"font-size:12px;color:var(--text-secondary);margin-top:4px;\">道具数量</div>\n            <div style=\"font-size:16px;font-weight:700;color:var(--primary);\" id=\"statusItems\">0</div>\n          </div>\n          <div style=\"background:var(--primary-bg);border-radius:12px;padding:12px;text-align:center;\">\n            <div style=\"font-size:20px;\">🏅</div>\n            <div style=\"font-size:12px;color:var(--text-secondary);margin-top:4px;\">成就数量</div>\n            <div style=\"font-size:16px;font-weight:700;color:var(--primary);\" id=\"statusAchievements\">0</div>\n          </div>\n        </div>\n      </div>\n\n      <!-- 小橘猫展示区 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:20px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);text-align:center;position:relative;\">\n        <!-- 校长信箱按钮 -->\n        <button onclick=\"openPage('mailboxPage')\" style=\"position:absolute;top:12px;right:12px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#fff;border:none;padding:8px 12px;border-radius:12px;font-size:13px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(245,158,11,0.4);display:flex;align-items:center;gap:4px;\">\n          ✉️ 校长信箱 <span id=\"mailboxBadge\" style=\"display:none;background:#ef4444;color:#fff;border-radius:10px;padding:1px 6px;font-size:11px;min-width:16px;text-align:center;\">0</span>\n        </button>\n        <div style=\"font-size:60px;\" id=\"statusPetEmoji\">🐱</div>\n        <div style=\"font-size:18px;font-weight:700;margin-top:8px;\" id=\"statusPetName\">小橘</div>\n        <div style=\"font-size:12px;color:#666;margin-top:4px;\" id=\"statusPetMood\">心情不错~</div>\n        <div style=\"margin-top:10px;display:inline-block;background:#fef3c7;color:#f59e0b;padding:4px 14px;border-radius:14px;font-size:13px;font-weight:700;\">\n          ⚔️ 战力：<span id=\"statusPetPower\">0</span>\n        </div>\n        <div style=\"margin-top:14px;text-align:left;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span>\n              <span id=\"statusHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"statusHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span>\n              <span id=\"statusCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"statusCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span>\n              <span id=\"statusAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"statusAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;transition:width 0.3s;\"></div>\n            </div>\n          </div>\n        </div>\n        <div id=\"statusPetHomeArea\" style=\"margin-top:14px;\">\n          <button onclick=\"openPage('petSchoolPage')\" style=\"width:100%;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(102,126,234,0.3);\">\n            🎒 出门上学\n          </button>\n          <button onclick=\"openPage('petPlayPage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#10b981,#34d399);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(16,185,129,0.3);\">\n            🌳 出去玩\n          </button>\n          <button onclick=\"openPage('petWorkPage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.3);\">\n            💼 出门打工\n          </button>\n          <button onclick=\"openPage('petExplorePage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(16,185,129,0.3);\">\n            🗺️ 宠物探险\n          </button>\n          <button onclick=\"openPage('petDressPage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#ec4899,#f472b6);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(236,72,153,0.3);\">\n            👗 宠物装扮\n          </button>\n          <button onclick=\"openPage('petSkillPage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#8b5cf6,#6366f1);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(139,92,246,0.3);\">\n            ✨ 宠物技能\n          </button>\n          <button onclick=\"openPage('petDiaryPage')\" style=\"width:100%;margin-top:10px;background:linear-gradient(135deg,#f59e0b,#fb7185);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.3);\">\n            📔 宠物日记\n          </button>\n        </div>\n        <div id=\"statusPetAwayArea\" style=\"margin-top:14px;display:none;\">\n          <div style=\"background:#fff3cd;border-radius:12px;padding:12px;text-align:center;\">\n            <div style=\"font-size:14px;color:#856404;font-weight:600;\" id=\"statusPetAwayText\">小橘正在上学...</div>\n            <div style=\"font-size:20px;font-weight:700;color:#856404;margin-top:6px;\" id=\"statusPetAwayTimer\">00:00</div>\n            <button onclick=\"recallPet()\" style=\"margin-top:10px;width:100%;background:#ef4444;color:#fff;border:none;padding:10px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(239,68,68,0.3);\">\n              🏠 召回宠物（退还一半金币）\n            </button>\n            <button onclick=\"showSuperItemPanel()\" style=\"margin-top:8px;width:100%;background:linear-gradient(135deg,#f43f5e,#f97316);color:#fff;border:none;padding:10px;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 2px 8px rgba(244,63,94,0.3);\">\n              ✨ 使用道具\n            </button>\n          </div>\n        </div>\n        <!-- 仓库按钮 -->\n        <div style=\"margin-top:10px;\">\n          <button onclick=\"openPage('warehousePage')\" style=\"width:100%;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.3);display:flex;align-items:center;justify-content:center;gap:6px;\">\n            📦 宠物仓库 <span id=\"warehouseBadge\" style=\"background:rgba(255,255,255,0.25);border-radius:10px;padding:1px 8px;font-size:12px;\">0</span>\n          </button>\n        </div>\n      </div>\n      \n      <!-- 收藏品展柜 -->\n      <div style=\"margin-top:14px;margin-bottom:24px;background:linear-gradient(135deg,#fef3c7,#fde68a);border-radius:16px;padding:16px;box-shadow:0 4px 16px rgba(245,158,11,0.2);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;\">\n          <div style=\"font-size:16px;font-weight:700;color:#92400e;\">🏆 收藏品展柜</div>\n          <div style=\"display:flex;align-items:center;gap:8px;\">\n            <span style=\"font-size:12px;color:#92400e;\" id=\"collectionProgress\">0/15</span>\n            <button onclick=\"openPage('collectionPage')\" style=\"background:rgba(255,255,255,0.5);border:none;border-radius:8px;padding:4px 10px;font-size:11px;color:#92400e;font-weight:600;cursor:pointer;\">查看全部 →</button>\n          </div>\n        </div>\n        <div id=\"collectionDisplay\" style=\"display:grid;grid-template-columns:repeat(5,1fr);gap:8px;\">\n          <!-- 收藏品由JS生成 -->\n        </div>\n      </div>\n      \n      <!-- 商店按钮区域 -->\n      <div style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 食物商店按钮 -->\n        <div onclick=\"openPage('foodShopPage')\" style=\"background:linear-gradient(135deg,#ff9a9e,#fecfef);border-radius:16px;padding:16px;cursor:pointer;box-shadow:0 4px 16px rgba(255,154,158,0.3);\">\n          <div style=\"text-align:center;\">\n            <div style=\"font-size:32px;\">🍖</div>\n            <div style=\"font-size:15px;font-weight:700;color:#fff;margin-top:6px;\">食物商店</div>\n            <div style=\"font-size:11px;color:rgba(255,255,255,0.9);margin-top:2px;\">买好吃的~</div>\n          </div>\n        </div>\n        <!-- 清洁商店按钮 -->\n        <div onclick=\"openPage('cleanShopPage')\" style=\"background:linear-gradient(135deg,#60a5fa,#34d399);border-radius:16px;padding:16px;cursor:pointer;box-shadow:0 4px 16px rgba(96,165,250,0.3);\">\n          <div style=\"text-align:center;\">\n            <div style=\"font-size:32px;\">🧼</div>\n            <div style=\"font-size:15px;font-weight:700;color:#fff;margin-top:6px;\">清洁商店</div>\n            <div style=\"font-size:11px;color:rgba(255,255,255,0.9);margin-top:2px;\">买清洁用品~</div>\n          </div>\n        </div>\n      </div>\n      <!-- 猫咪用品商店按钮 -->\n      <div onclick=\"openPage('toyShopPage')\" style=\"margin-top:12px;background:linear-gradient(135deg,#a78bfa,#f472b6);border-radius:16px;padding:14px;cursor:pointer;box-shadow:0 4px 16px rgba(167,139,250,0.3);\">\n        <div style=\"text-align:center;display:flex;align-items:center;justify-content:center;gap:10px;\">\n          <div style=\"font-size:28px;\">🪶</div>\n          <div style=\"text-align:left;\">\n            <div style=\"font-size:15px;font-weight:700;color:#fff;\">猫咪用品商店</div>\n            <div style=\"font-size:11px;color:rgba(255,255,255,0.9);margin-top:1px;\">逗猫棒、毛线球~ 提升好感度</div>\n          </div>\n        </div>\n      </div>\n      <!-- 超级道具商店按钮 -->\n      <div onclick=\"openPage('superItemShopPage')\" style=\"margin-top:12px;background:linear-gradient(135deg,#f43f5e,#f97316);border-radius:16px;padding:14px;cursor:pointer;box-shadow:0 4px 16px rgba(244,63,94,0.3);\">\n        <div style=\"text-align:center;display:flex;align-items:center;justify-content:center;gap:10px;\">\n          <div style=\"font-size:28px;\">✨</div>\n          <div style=\"text-align:left;\">\n            <div style=\"font-size:15px;font-weight:700;color:#fff;\">超级道具商店</div>\n            <div style=\"font-size:11px;color:rgba(255,255,255,0.9);margin-top:1px;\">加速卡、双倍战力~ 上学神器</div>\n          </div>\n        </div>\n      </div>\n      <!-- 每日任务按钮 -->\n      <div onclick=\"openPage('dailyTaskPage')\" style=\"margin-top:12px;background:linear-gradient(135deg,#8b5cf6,#6366f1);border-radius:16px;padding:14px;cursor:pointer;box-shadow:0 4px 16px rgba(139,92,246,0.3);\">\n        <div style=\"text-align:center;display:flex;align-items:center;justify-content:center;gap:10px;\">\n          <div style=\"font-size:28px;\">📋</div>\n          <div style=\"text-align:left;\">\n            <div style=\"font-size:15px;font-weight:700;color:#fff;\">每日任务</div>\n            <div style=\"font-size:11px;color:rgba(255,255,255,0.9);margin-top:1px;\">完成任务领金币，每天0点刷新</div>\n          </div>\n        </div>\n      </div>\n    </div>\n  </div>");
window.flRegisterToolPage("pageFoodShopPage", "<!-- pageFoodShopPage -->\n<div class=\"tool-page\" id=\"pageFoodShopPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🍽️ 食物商店</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">给小橘买好吃的，点击食物购买后放入仓库，再从仓库喂食~</div>\n      \n      <!-- 小橘猫状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:20px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);text-align:center;\">\n        <div style=\"font-size:60px;\" id=\"foodPetEmoji\">🐱</div>\n        <div style=\"font-size:18px;font-weight:700;margin-top:8px;\" id=\"foodPetName\">小橘</div>\n        <div style=\"font-size:12px;color:#666;margin-top:4px;\" id=\"foodPetMood\">心情不错~</div>\n        <div style=\"margin-top:14px;text-align:left;\">\n          <div style=\"display:flex;justify-content:space-between;font-size:13px;margin-bottom:6px;\">\n            <span>🍖 饱食度</span>\n            <span id=\"foodHungerText\">50/100</span>\n          </div>\n          <div style=\"height:10px;background:#eee;border-radius:5px;overflow:hidden;\">\n            <div id=\"foodHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:5px;width:50%;transition:width 0.3s;\"></div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 食物列表 -->\n      <div id=\"foodShopList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 食物列表由JS生成 -->\n      </div>\n      \n      <!-- 当前金币 -->\n      <div style=\"margin-top:16px;padding:14px;background:var(--primary-bg);border-radius:12px;text-align:center;font-size:15px;\">\n        💰 当前金币：<span id=\"foodCoinsDisplay\" style=\"font-weight:700;color:#f59e0b;font-size:18px;\">0</span>\n      </div>\n    </div>\n  </div>");
// ==================== 状态系统 ====================
function initStatus(){
  // 记录第一次进入日期
  const firstVisit = lsGet('first_visit_date', null);
  if(!firstVisit){
    const now = new Date();
    const dateStr = now.getFullYear()+'-'+String(now.getMonth()+1).padStart(2,'0')+'-'+String(now.getDate()).padStart(2,'0');
    lsSet('first_visit_date', dateStr);
  }
  // 记录访问次数
  const visitCount = lsGet('visit_count', 0) + 1;
  lsSet('visit_count', visitCount);
  // 初始化饱食度
  if(lsGet('pet_hunger', null) === null){
    lsSet('pet_hunger', 50);
  }
  // 初始化清洁值
  if(lsGet('pet_clean', null) === null){
    lsSet('pet_clean', 100);
  }
  // 初始化好感度
  if(lsGet('pet_affection', null) === null){
    lsSet('pet_affection', 50);
  }
  // 初始化宠物战力
  initPetPower();
  // 离线结算：检查关闭浏览器期间是否有活动结束
  setTimeout(() => {
    // 上学离线结算
    const schoolData = lsGet('pet_school_data', null);
    if(schoolData && schoolData.endTime <= Date.now()){
      completePetSchool();
    }
    // 打工离线结算
    const workData = lsGet('pet_work_data', null);
    if(workData && workData.endTime <= Date.now()){
      completePetWork();
    }
    // 启动各活动计时器（游玩计时器首次tick会自动结算已结束的）
    startPetSchoolTimer();
    startPetWorkTimer();
    startPlayTimer();
    updatePetStatusDisplay();
    updateWarehouseBadge();
    updateMailboxBadge();
  }, 500);
}

function updateStatusPage(){
  // 更新状态页面信息
  const firstVisit = lsGet('first_visit_date', '--');
  const visitCount = lsGet('visit_count', 0);
  const coins = bpGetCoins();
  
  // 计算弹珠总数
  const pinballInv = lsGet('pinball_inventory', {});
  let totalPinballs = 0;
  for(let k in pinballInv){ totalPinballs += pinballInv[k]; }
  
  // 计算卡牌数量（backpack_cards是数组，每个元素是卡牌对象）
  const cardInv = lsGet('backpack_cards', []);
  let totalCards = Array.isArray(cardInv) ? cardInv.length : 0;
  
  // 计算道具数量（backpack_items是数组，每个元素是道具对象）
  const itemInv = lsGet('backpack_items', []);
  let totalItems = Array.isArray(itemInv) ? itemInv.length : 0;
  
  // 计算成就数量
  const achievementsClaimed = lsGet('achievements_claimed', []);
  const totalAchievements = achievementsClaimed.length;
  
  // 更新DOM
  const elFirst = document.getElementById('statusFirstVisit');
  const elVisit = document.getElementById('statusVisitCount');
  const elCoins = document.getElementById('statusCoins');
  const elPinballs = document.getElementById('statusPinballs');
  const elCards = document.getElementById('statusCards');
  const elItems = document.getElementById('statusItems');
  const elAch = document.getElementById('statusAchievements');
  
  if(elFirst) elFirst.textContent = firstVisit;
  if(elVisit) elVisit.textContent = visitCount + ' 次';
  if(elCoins) elCoins.textContent = coins + ' 💰';
  if(elPinballs) elPinballs.textContent = totalPinballs + ' 🔮';
  if(elCards) elCards.textContent = totalCards;
  if(elItems) elItems.textContent = totalItems;
  if(elAch) elAch.textContent = totalAchievements + '/' + (typeof ACHIEVEMENTS !== 'undefined' ? ACHIEVEMENTS.length : 34);
  
  // 宠物数据统计
  const petPower = lsGet('pet_power', 0);
  const schoolCounts = lsGet('pet_school_counts', {});
  let totalSchool = 0;
  for(let k in schoolCounts){ totalSchool += schoolCounts[k]; }
  const totalGainedPower = lsGet('pet_total_gained_power', 0);
  const warehouseTotal = typeof getWarehouseAllTotal === 'function' ? getWarehouseAllTotal() : 0;
  
  // 计算当前学历（最高解锁的学校）
  let currentDegree = '幼儿园';
  const unlockedSchools = PET_SCHOOLS.filter(s => {
    if(!s.unlockSchool) return true;
    const reqCount = schoolCounts[s.unlockSchool] || 0;
    return reqCount >= s.unlockCount;
  });
  if(unlockedSchools.length > 0){
    currentDegree = unlockedSchools[unlockedSchools.length - 1].name;
  }
  
  const elTotalPower = document.getElementById('statusTotalPower');
  const elTotalSchool = document.getElementById('statusTotalSchool');
  const elDegree = document.getElementById('statusCurrentDegree');
  const elTotalUsage = document.getElementById('statusTotalUsage');
  
  // 计算使用总次数
  const usageHistory = lsGet('pet_usage_history', []);
  const totalUsage = usageHistory.length;
  
  if(elTotalPower) elTotalPower.textContent = petPower;
  if(elTotalSchool) elTotalSchool.textContent = totalSchool + '次';
  if(elDegree) elDegree.textContent = currentDegree;
  if(elTotalUsage) elTotalUsage.textContent = totalUsage + '次';
  
  // 更新小橘猫显示
  updatePetStatusDisplay();
  // 更新仓库角标
  updateWarehouseBadge();
  // 更新收藏品展柜
  renderCollections();
  // 更新信箱角标
  updateMailboxBadge();
}

// 更新小橘猫显示（状态页面和食物商店页面）
function updatePetDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  
  // 根据饱食度更新心情和表情
  let mood, emoji;
  if(hungerPercent >= 80){
    mood = '吃饱啦，超级开心~';
    emoji = '😺';
  } else if(hungerPercent >= 50){
    mood = '心情不错~';
    emoji = '🐱';
  } else if(hungerPercent >= 20){
    mood = '有点饿了...';
    emoji = '😿';
  } else {
    mood = '快饿晕啦，快喂我！';
    emoji = '😾';
  }
  
  // 更新状态页面的小橘猫
  const elStatusEmoji = document.getElementById('statusPetEmoji');
  const elStatusMood = document.getElementById('statusPetMood');
  const elStatusHungerText = document.getElementById('statusHungerText');
  const elStatusHungerBar = document.getElementById('statusHungerBar');
  if(elStatusEmoji) elStatusEmoji.textContent = emoji;
  if(elStatusMood) elStatusMood.textContent = mood;
  if(elStatusHungerText) elStatusHungerText.textContent = hungerPercent + '/100';
  if(elStatusHungerBar) elStatusHungerBar.style.width = hungerPercent + '%';
  
  // 更新食物商店页面的小橘猫
  const elFoodEmoji = document.getElementById('foodPetEmoji');
  const elFoodMood = document.getElementById('foodPetMood');
  const elFoodHungerText = document.getElementById('foodHungerText');
  const elFoodHungerBar = document.getElementById('foodHungerBar');
  if(elFoodEmoji) elFoodEmoji.textContent = emoji;
  if(elFoodMood) elFoodMood.textContent = mood;
  if(elFoodHungerText) elFoodHungerText.textContent = hungerPercent + '/100';
  if(elFoodHungerBar) elFoodHungerBar.style.width = hungerPercent + '%';
  
  // 更新食物商店页面的金币
  const elFoodCoins = document.getElementById('foodCoinsDisplay');
  if(elFoodCoins) elFoodCoins.textContent = bpGetCoins();
}

// 初始化食物商店页面
function initFoodShop(){
  renderFoodShopList();
  updatePetDisplay();
}

// 渲染食物商店列表
function renderFoodShopList(){
  const container = document.getElementById('foodShopList');
  if(!container) return;
  container.innerHTML = '';
  PHONE_FOODS.forEach(food => {
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;border:2px solid transparent;';
    div.onmouseover = () => {div.style.transform='scale(1.03)';div.style.borderColor='var(--primary)';};
    div.onmouseout = () => {div.style.transform='scale(1)';div.style.borderColor='transparent';};
    div.onclick = () => showBuyQuantityModal(food, 'food');
    div.innerHTML = `
      <div style="font-size:36px;">${food.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${food.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${food.hunger}饱食度</div>
      <div style="margin-top:8px;display:inline-block;background:#fef3c7;color:#f59e0b;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700;">💰 ${food.price}</div>
    `;
    container.appendChild(div);
  });
}

