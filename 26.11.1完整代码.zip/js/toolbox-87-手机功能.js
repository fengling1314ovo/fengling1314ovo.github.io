// ==================== 手机功能 ====================
const PHONE_FOODS = [
  {id:'fish', name:'小鱼干', emoji:'🐟', price:5, hunger:15},
  {id:'meat', name:'肉肉', emoji:'🍖', price:10, hunger:25},
  {id:'milk', name:'牛奶', emoji:'🥛', price:3, hunger:10},
  {id:'cake', name:'蛋糕', emoji:'🍰', price:8, hunger:20},
  {id:'apple', name:'苹果', emoji:'🍎', price:2, hunger:8},
  {id:'candy', name:'糖果', emoji:'🍬', price:1, hunger:5}
];



function closePhoneModal(){
  const mask = document.getElementById('phoneModalMask');
  if(mask) closeModalAnimated(mask);
}

function renderPhoneFoodList(){
  const container = document.getElementById('phoneFoodList');
  if(!container) return;
  container.innerHTML = '';
  PHONE_FOODS.forEach(food => {
    const div = document.createElement('div');
    div.style.cssText = 'background:#fff;border-radius:12px;padding:12px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;';
    div.onmouseover = () => div.style.transform = 'scale(1.03)';
    div.onmouseout = () => div.style.transform = 'scale(1)';
    div.onclick = () => showBuyQuantityModal(food, 'food');
    div.innerHTML = `
      <div style="font-size:28px;">${food.emoji}</div>
      <div style="font-size:13px;font-weight:600;margin-top:4px;">${food.name}</div>
      <div style="font-size:11px;color:#666;margin-top:2px;">+${food.hunger}饱食度</div>
      <div style="font-size:12px;color:#f59e0b;font-weight:700;margin-top:4px;">💰 ${food.price}</div>
    `;
    container.appendChild(div);
  });
}

