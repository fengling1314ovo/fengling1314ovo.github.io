// ==================== 背景流动 ====================
let bgFlowEnabled = false;
let bgFlowSpeed = 2;
let bgFlowTime = 0;
let bgFlowRafId = null;
const BG_FLOW_SPEED_MAP = {1:0.0006, 2:0.0012, 3:0.002, 4:0.0035, 5:0.0055};
function getCurrentThemeColors(){
  const saved = localStorage.getItem("qqtool_theme");
  if(saved){ try{ const t = JSON.parse(saved); return [t.p1, t.p2]; }catch(e){} }
  return ['#6366f1', '#818cf8'];
}
function applyBgFlowFrame(){
  const [c1, c2] = getCurrentThemeColors();
  const t = bgFlowTime;
  const sp = BG_FLOW_SPEED_MAP[bgFlowSpeed] || 0.002;
  // 更大的流动范围
  const x1 = 15 + Math.sin(t * sp) * 32;
  const y1 = 15 + Math.cos(t * sp * 0.7) * 22;
  const x2 = 85 + Math.cos(t * sp * 0.8) * 22;
  const y2 = 85 + Math.sin(t * sp * 0.9) * 30;
  const x3 = 50 + Math.sin(t * sp * 0.6) * 38;
  const y3 = 100 + Math.cos(t * sp * 0.5) * 20;
  // 颜色深浅随时间呼吸变化
  const a1 = 0.16 + Math.sin(t * sp * 0.5) * 0.10;
  const a2 = 0.14 + Math.cos(t * sp * 0.6) * 0.09;
  const a3 = 0.08 + Math.sin(t * sp * 0.4) * 0.06;
  const bg = 'radial-gradient(circle at '+x1+'% '+y1+'%,' + hexToRgba(c1, Math.max(0.02, a1)) + ',transparent 35%),' +
             'radial-gradient(circle at '+x2+'% '+y2+'%,' + hexToRgba(c2, Math.max(0.02, a2)) + ',transparent 35%),' +
             'radial-gradient(circle at '+x3+'% '+y3+'%,' + hexToRgba(c1, Math.max(0.01, a3)) + ',transparent 50%),' +
             'linear-gradient(160deg,#f8faff 0%,#eef1ff 50%,#eaf6ff 100%)';
  bodyEl.style.background = bg;
  bodyEl.style.backgroundAttachment = 'fixed';
}
function bgFlowLoop(){
  bgFlowTime += 16;
  applyBgFlowFrame();
  bgFlowRafId = requestAnimationFrame(bgFlowLoop);
}
function startBgFlow(){ if(bgFlowRafId) return; bgFlowTime = 0; bgFlowLoop(); }
function stopBgFlow(){
  if(bgFlowRafId){ cancelAnimationFrame(bgFlowRafId); bgFlowRafId = null; }
  const [c1, c2] = getCurrentThemeColors();
  setPrimary(c1, c2);
}
function toggleBgFlow(){
  bgFlowEnabled = !bgFlowEnabled;
  const btn = document.getElementById('bgFlowToggleBtn');
  if(btn) btn.textContent = bgFlowEnabled ? '已开启' : '已关闭';
  document.querySelectorAll('.bg-flow-speed-btn').forEach(b=>{ b.style.opacity = bgFlowEnabled ? '1' : '0.5'; });
  localStorage.setItem('qqtool_bgflow', bgFlowEnabled ? '1' : '0');
  if(bgFlowEnabled){ startBgFlow(); } else { stopBgFlow(); }
}
function setBgFlowSpeed(speed){
  bgFlowSpeed = speed;
  localStorage.setItem('qqtool_bgflow_speed', String(speed));
  document.querySelectorAll('.bg-flow-speed-btn').forEach(b=>{
    if(parseInt(b.dataset.speed) === speed){ b.classList.add('active'); } else { b.classList.remove('active'); }
  });
}
// 恢复背景流动设置
const _savedBgFlow = localStorage.getItem('qqtool_bgflow');
const _savedBgFlowSpeed = localStorage.getItem('qqtool_bgflow_speed');
if(_savedBgFlowSpeed){ bgFlowSpeed = parseInt(_savedBgFlowSpeed); }
document.querySelectorAll('.bg-flow-speed-btn').forEach(b=>{
  if(parseInt(b.dataset.speed) === bgFlowSpeed){ b.classList.add('active'); } else { b.classList.remove('active'); }
});
// 首次进入默认开启背景流动
const _shouldEnableBgFlow = (_savedBgFlow === null) ? true : (_savedBgFlow === '1');
if(_shouldEnableBgFlow){
  bgFlowEnabled = true;
  if(_savedBgFlow === null){ localStorage.setItem('qqtool_bgflow','1'); }
  const _btn = document.getElementById('bgFlowToggleBtn');
  if(_btn) _btn.textContent = '已开启';
  document.querySelectorAll('.bg-flow-speed-btn').forEach(b=>{ b.style.opacity = '1'; });
  setTimeout(startBgFlow, 600);
}

