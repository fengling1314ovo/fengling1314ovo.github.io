/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetDiaryPage", "<!-- pagePetDiaryPage -->\n<div class=\"tool-page\" id=\"pagePetDiaryPage\">\n  <div class=\"tool-header\">\n    <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n  </div>\n  <div class=\"breadcrumb\"></div>\n  <div class=\"common-block\" style=\"padding:0 28px 32px\">\n    <h3>📔 宠物日记</h3>\n    <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">小橘每天都会把有趣的事写进日记里，一起来看看吧~</div>\n\n    <!-- 写日记按钮 -->\n    <button id=\"diaryWriteBtn\" onclick=\"manualWriteDiary()\" style=\"width:100%;background:linear-gradient(135deg,#f59e0b,#f97316);color:#fff;border:none;padding:12px;border-radius:12px;font-size:15px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.3);margin-bottom:14px;\">\n      ✍️ 写日记\n    </button>\n\n    <!-- 日记列表 -->\n    <div id=\"diaryList\" style=\"display:grid;gap:12px;\">\n      <!-- 日记卡片由JS生成 -->\n    </div>\n  </div>\n</div>");
// ==================== 宠物日记系统 ====================
let petDiaryTimer = null;

// 获取今天日期字符串
function getDiaryTodayStr(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

// 获取当日事件列表（自动跨天清空）
function getPetDailyEvents(){
  const data = lsGet('pet_daily_events', null);
  const today = getDiaryTodayStr();
  if(!data || data.date !== today){
    const fresh = {date: today, events: []};
    lsSet('pet_daily_events', fresh);
    return fresh;
  }
  if(!Array.isArray(data.events)) data.events = [];
  return data;
}

// 记录一条当日事件（供其他功能调用）
function recordPetDailyEvent(text){
  if(!text) return;
  const data = getPetDailyEvents();
  data.events.push(text);
  lsSet('pet_daily_events', data);
}

// 生成宠物日记（可被其他功能调用）
function generatePetDiary(){
  const today = getDiaryTodayStr();
  const diaryList = lsGet('pet_diary', []);
  // 今天已写过则不重复
  if(diaryList.some(d => d.date === today)) return null;

  // 收集事件
  const daily = getPetDailyEvents();
  const events = daily.events.slice();

  // 附加推断：根据 localStorage 状态补充事件
  const schoolData = lsGet('pet_school_data', null);
  if(schoolData && schoolData.endTime > Date.now()){
    events.push('正在认真地上学呢');
  }
  const workData = lsGet('pet_work_data', null);
  if(workData && workData.endTime > Date.now()){
    events.push('出门打工赚金币去了');
  }
  const hunger = lsGet('pet_hunger', 50);
  const clean = lsGet('pet_clean', 100);
  if(hunger >= 80) events.push('吃得饱饱的');
  if(clean < 30) events.push('玩得脏兮兮的');

  // 随机天气
  const weathers = [
    {emoji:'☀️', text:'阳光明媚的大晴天'},
    {emoji:'🌤️', text:'多云转晴'},
    {emoji:'⛅', text:'云朵飘来飘去的'},
    {emoji:'🌧️', text:'下着小雨的一天'},
    {emoji:'🌈', text:'雨后出了彩虹'},
    {emoji:'🌙', text:'晚上星星特别亮'}
  ];
  const weather = weathers[Math.floor(Math.random() * weathers.length)];

  // 心情
  const moods = [
    {emoji:'😄', text:'开心'},
    {emoji:'😺', text:'满足'},
    {emoji:'🥰', text:'幸福'},
    {emoji:'😴', text:'慵懒'},
    {emoji:'🤔', text:'有点小好奇'},
    {emoji:'😋', text:'美滋滋'}
  ];
  const mood = moods[Math.floor(Math.random() * moods.length)];

  // 拼接正文（50-100字）
  let body = '';
  if(events.length === 0){
    body = '今天阳光很好，我趴在窗台上晒了一整个下午的太阳，舔了舔爪子，伸了个大大的懒腰。主人好像很忙的样子，但偶尔会过来摸摸我的头，我觉得今天也很幸福呢。';
  } else {
    const evText = events.slice(0, 4).join('，') + '。';
    const feelings = [
      '真是充实的一天呀！',
      '虽然有点累，但是很开心~',
      '好想天天都这样过！',
      '下次还要叫上好朋友一起！',
      '主人会不会夸我呢？嘻嘻~'
    ];
    const feel = feelings[Math.floor(Math.random() * feelings.length)];
    body = '今天' + weather.text + '。' + evText + feel;
  }
  // 控制字数 50-100
  if(body.length < 50){
    body += '对了，刚才又去吃了点小零食，咕噜咕噜好饱。明天也要开开心心地过！';
  }
  if(body.length > 110){
    body = body.substring(0, 100) + '。';
  }

  const entry = {
    date: today,
    weather: weather.emoji,
    weatherText: weather.text,
    mood: mood.emoji,
    moodText: mood.text,
    content: body
  };
  diaryList.push(entry);
  lsSet('pet_diary', diaryList);
  return entry;
}

// 手动写日记按钮
function manualWriteDiary(){
  const today = getDiaryTodayStr();
  const diaryList = lsGet('pet_diary', []);
  if(diaryList.some(d => d.date === today)){
    showToast('📔 小橘今天已经写过日记啦~');
    return;
  }
  const entry = generatePetDiary();
  if(entry){
    showToast('📔 小橘写完日记啦！');
    renderDiaryList();
  }
}

// 初始化宠物日记页面
function initPetDiary(){
  // 每次打开页面时，如果今天还没写，自动生成一篇
  const today = getDiaryTodayStr();
  const diaryList = lsGet('pet_diary', []);
  const btn = document.getElementById('diaryWriteBtn');
  if(diaryList.some(d => d.date === today)){
    if(btn) btn.disabled = true;
    if(btn) btn.textContent = '📔 今天已写完';
  } else {
    if(btn) btn.disabled = false;
    if(btn) btn.textContent = '✍️ 写日记';
  }
  renderDiaryList();
}

// 渲染日记列表（按日期倒序）
function renderDiaryList(){
  const container = document.getElementById('diaryList');
  if(!container) return;
  container.innerHTML = '';
  const diaryList = lsGet('pet_diary', []).slice().sort((a,b) => b.date.localeCompare(a.date));
  if(!diaryList.length){
    container.innerHTML = '<div style="text-align:center;padding:30px 10px;color:var(--text-placeholder);font-size:13px;">还没有日记呢，和小橘一起度过有趣的一天吧~</div>';
    return;
  }
  diaryList.forEach(entry => {
    const div = document.createElement('div');
    div.style.cssText = 'background:linear-gradient(135deg,#fffbeb,#fef3c7);border-radius:14px;padding:16px;box-shadow:0 2px 10px rgba(245,158,11,0.12);border-left:4px solid #f59e0b;';
    div.innerHTML =
      '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px;">' +
        '<div style="font-size:13px;font-weight:700;color:#92400e;">📅 ' + entry.date + '</div>' +
        '<div style="font-size:18px;">' + (entry.weather || '☀️') + ' ' + (entry.mood || '😄') + '</div>' +
      '</div>' +
      '<div style="font-size:12px;color:#b45309;margin-bottom:6px;">' + (entry.weatherText || '') + ' · 心情：' + (entry.moodText || '') + '</div>' +
      '<div style="font-size:14px;color:#78350f;line-height:1.8;">' + entry.content + '</div>';
    container.appendChild(div);
  });
}

