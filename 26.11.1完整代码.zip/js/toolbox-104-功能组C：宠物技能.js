/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pagePetSkillPage", "<!-- pagePetSkillPage -->\n<div class=\"tool-page\" id=\"pagePetSkillPage\">\n  <div class=\"tool-header\">\n    <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n  </div>\n  <div class=\"breadcrumb\"></div>\n  <div class=\"common-block\" style=\"padding:0 28px 32px\">\n    <h3>✨ 宠物技能</h3>\n    <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">\n      小橘通过上学、打工和日常陪伴习得技能，达成条件即可免费解锁！已解锁 <b id=\"psUnlockedCount\">0</b> / <b id=\"psTotalCount\">0</b> 个\n    </div>\n    <div id=\"psSkillArea\" style=\"display:grid;gap:12px;\"></div>\n  </div>\n</div>");
// ==================== 功能组C：宠物技能 ====================

function petGradCount(schoolId){
  const c = lsGet('pet_school_counts', {});
  return c[schoolId] || 0;
}
// 清洁≥80连续天数（按自然日累计）
function petCleanStreak(){
  const clean = lsGet('pet_clean', 100);
  const today = new Date().toDateString();
  const rec = lsGet('pet_clean_days', {streak:0, date:''});
  if(clean >= 80){
    if(rec.date !== today){
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      if(rec.date === yesterday){ rec.streak = (rec.streak || 0) + 1; }
      else { rec.streak = 1; }
      rec.date = today;
      lsSet('pet_clean_days', rec);
    }
  } else if(rec.streak !== 0){
    rec.streak = 0;
    rec.date = '';
    lsSet('pet_clean_days', rec);
  }
  return rec.streak || 0;
}

const PET_SKILLS = [
  {id:'fish', icon:'🐟', name:'抓鱼达人', desc:'打工金币 +20%', needText:'小学毕业 1 次', check:()=> petGradCount('primary') >= 1},
  {id:'spoiled', icon:'💕', name:'撒娇高手', desc:'游玩好感 +30%', needText:'好感度 ≥ 60', check:()=> (lsGet('pet_affection', 50)) >= 60},
  {id:'door', icon:'🚪', name:'开门大师', desc:'所有活动时间 -20%', needText:'初中毕业 1 次', check:()=> petGradCount('middle') >= 1},
  {id:'rich', icon:'💰', name:'理财小能手', desc:'金币获取 +15%', needText:'高中毕业 1 次', check:()=> petGradCount('high') >= 1},
  {id:'clean', icon:'🧼', name:'清洁精灵', desc:'清洁消耗 -30%', needText:'清洁 ≥ 80 持续 3 天', check:()=> petCleanStreak() >= 3},
  {id:'power', icon:'💪', name:'力量训练', desc:'战力 +10', needText:'大学毕业 1 次', check:()=> petGradCount('university') >= 1}
];

function psIsUnlocked(id){
  const un = lsGet('pet_skills_unlocked', []);
  return un.indexOf(id) >= 0;
}

function unlockSkill(id){
  let sk = null;
  for(let i=0;i<PET_SKILLS.length;i++){ if(PET_SKILLS[i].id===id){ sk = PET_SKILLS[i]; break; } }
  if(!sk) return;
  if(psIsUnlocked(id)){ showToast('已经解锁过啦~'); return; }
  // 先刷新清洁连续天数统计
  petCleanStreak();
  if(!sk.check()){ showToast('暂未满足解锁条件：'+sk.needText); return; }
  const un = lsGet('pet_skills_unlocked', []);
  un.push(id);
  lsSet('pet_skills_unlocked', un);
  showToast('🎉 解锁新技能：'+sk.name+'！');
  renderPetSkills();
}



function renderPetSkills(){
  const area = document.getElementById('psSkillArea');
  if(!area) return;
  let unlockedCount = 0;
  let html = '';
  PET_SKILLS.forEach(sk=>{
    // 刷新条件（尤其清洁连续天数）
    const met = sk.check();
    const unlocked = psIsUnlocked(sk.id);
    if(unlocked) unlockedCount++;
    let cardStyle, statusHtml;
    if(unlocked){
      cardStyle = 'background:linear-gradient(135deg,#dcfce7,#bbf7d0);border:2px solid #16a34a;';
      statusHtml = '<div style="font-size:12px;color:#166534;font-weight:700;margin-top:6px;">✅ 已解锁 · '+sk.desc+'</div>';
    } else if(met){
      cardStyle = 'background:linear-gradient(135deg,#fef3c7,#fde68a);border:2px solid #f59e0b;';
      statusHtml = '<div style="font-size:12px;color:#92400e;margin-top:6px;">🔓 条件达成：'+sk.needText+'</div>'
        + '<button onclick="unlockSkill(\''+sk.id+'\')" style="margin-top:8px;width:100%;background:linear-gradient(135deg,#16a34a,#22c55e);color:#fff;border:none;padding:8px;border-radius:9px;font-size:13px;font-weight:700;cursor:pointer;">✨ 点击解锁</button>';
    } else {
      cardStyle = 'background:var(--card-bg);border:2px solid var(--border-color);opacity:0.85;';
      statusHtml = '<div style="font-size:12px;color:var(--text-secondary);margin-top:6px;">🔒 未解锁 · 需 '+sk.needText+'</div>';
    }
    html += '<div style="border-radius:14px;padding:14px;box-shadow:0 2px 10px rgba(0,0,0,0.05);'+cardStyle+'">'
      + '<div style="display:flex;align-items:center;gap:10px;">'
      + '<div style="font-size:32px;">'+sk.icon+'</div>'
      + '<div>'
      + '<div style="font-size:15px;font-weight:700;color:var(--text-main);">'+sk.name+'</div>'
      + '<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">'+sk.desc+'</div>'
      + '</div></div>'
      + statusHtml
      + '</div>';
  });
  area.innerHTML = html;
  const uc = document.getElementById('psUnlockedCount');
  const tc = document.getElementById('psTotalCount');
  if(uc) uc.textContent = unlockedCount;
  if(tc) tc.textContent = PET_SKILLS.length;
}

function initPetSkill(){
  renderPetSkills();
}

// 状态页刷新后叠加小橘装扮效果
const _origUpdateStatusPageC = updateStatusPage;
updateStatusPage = function(){
  _origUpdateStatusPageC.apply(this, arguments);
  if(typeof updatePetDressDisplay === 'function') updatePetDressDisplay();
};

