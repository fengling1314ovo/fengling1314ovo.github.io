/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageMailboxPage", "<!-- pageMailboxPage -->\n<div class=\"tool-page\" id=\"pageMailboxPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>✉️ 校长信箱</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">小橘每次毕业后，校长都会寄来祝福信和小礼物~ 点击信件查看详情并领取奖励！</div>\n      \n      <!-- 邮件列表 -->\n      <div id=\"mailboxList\" style=\"display:flex;flex-direction:column;gap:12px;\">\n        <!-- 邮件列表由JS生成 -->\n      </div>\n      \n      <!-- 空状态 -->\n      <div id=\"mailboxEmpty\" style=\"display:none;text-align:center;padding:40px 20px;color:var(--text-placeholder);\">\n        <div style=\"font-size:48px;\">📭</div>\n        <div style=\"font-size:14px;margin-top:10px;\">还没有收到校长的信呢，让小橘去上学吧~</div>\n        <button onclick=\"openPage('petSchoolPage')\" style=\"margin-top:14px;padding:8px 16px;border:none;border-radius:10px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-size:13px;font-weight:600;cursor:pointer;\">送小橘上学</button>\n      </div>\n    </div>\n  </div>");
// ==================== 校长信箱系统 ====================
// 校长祝福语文案库
const PRINCIPAL_MESSAGES = {
  normal: [
    '亲爱的小橘同学，今天在学校表现很棒！继续加油哦~',
    '小橘今天又学会了新东西，校长为你感到骄傲！',
    '认真学习的小橘最可爱啦，明天也要元气满满哦~',
    '小橘同学今天出勤准时，课堂表现积极，继续保持！',
    '看到小橘每天都在进步，校长真的很欣慰呢~'
  ],
  final: [
    '🎉 恭喜小橘同学顺利毕业！你已经掌握了本阶段所有知识，准备好迎接新的挑战了吗？',
    '🎓 毕业快乐！小橘同学在这段时间里成长了很多，校长相信你在更高的学府会更加出色！',
    '✨ 光荣毕业！小橘用努力证明了自己，带着这份自信去开启新的学习旅程吧！',
    '🌟 毕业啦！小橘同学的每一份努力都有了回报，未来可期，继续闪闪发光吧！'
  ]
};

// 获取/保存信箱
function getMailbox(){ return lsGet('pet_mailbox', []); }
function saveMailbox(mails){ lsSet('pet_mailbox', mails); }

// 生成校长邮件
function generateSchoolMail(school, graduationCount, isFinalGraduation){
  const messages = isFinalGraduation ? PRINCIPAL_MESSAGES.final : PRINCIPAL_MESSAGES.normal;
  const content = messages[Math.floor(Math.random() * messages.length)];
  
  // 根据学校等级生成奖励
  const schoolLevel = PET_SCHOOLS.findIndex(s => s.id === school.id);
  const rewards = {
    coins: 5 + schoolLevel * 5 + Math.floor(Math.random() * 5),
    foods: [],
    cleans: [],
    toys: []
  };
  
  // 随机食物奖励
  const foodItems = PHONE_FOODS;
  const randomFood = foodItems[Math.floor(Math.random() * Math.min(foodItems.length, schoolLevel + 2))];
  rewards.foods.push({id: randomFood.id, name: randomFood.name, emoji: randomFood.emoji, count: 1});
  
  // 随机清洁用品奖励
  const cleanItems = PET_CLEAN_ITEMS;
  const randomClean = cleanItems[Math.floor(Math.random() * Math.min(cleanItems.length, schoolLevel + 2))];
  rewards.cleans.push({id: randomClean.id, name: randomClean.name, emoji: randomClean.emoji, count: 1});
  
  // 随机玩具奖励（有概率）
  if(Math.random() < 0.5 + schoolLevel * 0.1){
    const toyItems = PET_TOYS;
    const randomToy = toyItems[Math.floor(Math.random() * Math.min(toyItems.length, schoolLevel + 2))];
    rewards.toys.push({id: randomToy.id, name: randomToy.name, emoji: randomToy.emoji, count: 1});
  }
  
  const mail = {
    id: 'mail_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
    schoolId: school.id,
    schoolName: school.name,
    schoolEmoji: school.emoji,
    graduationCount: graduationCount,
    isFinalGraduation: isFinalGraduation,
    title: isFinalGraduation ? '🎓 毕业祝福信' : '✉️ 校长的日常问候',
    content: content,
    rewards: rewards,
    claimed: false,
    read: false,
    timestamp: Date.now()
  };
  
  const mails = getMailbox();
  mails.unshift(mail); // 最新的放最前面
  saveMailbox(mails);
  updateMailboxBadge();
  
  showToast('✉️ 收到校长的来信啦！');
}

// 更新未读邮件红点
function updateMailboxBadge(){
  const mails = getMailbox();
  const unreadCount = mails.filter(m => !m.read).length;
  const badge = document.getElementById('mailboxBadge');
  if(badge){
    if(unreadCount > 0){
      badge.style.display = 'inline-block';
      badge.textContent = unreadCount > 99 ? '99+' : unreadCount;
    } else {
      badge.style.display = 'none';
    }
  }
}

// 渲染信箱列表
function renderMailbox(){
  const mails = getMailbox();
  const listEl = document.getElementById('mailboxList');
  const emptyEl = document.getElementById('mailboxEmpty');
  
  if(!listEl) return;
  
  if(mails.length === 0){
    listEl.style.display = 'none';
    if(emptyEl) emptyEl.style.display = 'block';
    return;
  }
  
  listEl.style.display = 'flex';
  if(emptyEl) emptyEl.style.display = 'none';
  
  listEl.innerHTML = mails.map(mail => {
    const date = new Date(mail.timestamp);
    const dateStr = `${date.getMonth()+1}/${date.getDate()} ${String(date.getHours()).padStart(2,'0')}:${String(date.getMinutes()).padStart(2,'0')}`;
    const rewardPreview = [];
    if(mail.rewards.coins) rewardPreview.push(`💰${mail.rewards.coins}`);
    mail.rewards.foods.forEach(f => rewardPreview.push(`${f.emoji}${f.name}`));
    mail.rewards.cleans.forEach(c => rewardPreview.push(`${c.emoji}${c.name}`));
    mail.rewards.toys.forEach(t => rewardPreview.push(`${t.emoji}${t.name}`));
    
    return `
      <div onclick="openMailDetail('${mail.id}')" style="background:${mail.read ? '#fff' : 'linear-gradient(135deg,#fef3c7,#fff)'};border-radius:14px;padding:14px;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);border:2px solid ${mail.read ? 'transparent' : '#fbbf24'};transition:all 0.2s;">
        <div style="display:flex;align-items:center;justify-content:space-between;">
          <div style="display:flex;align-items:center;gap:8px;">
            <span style="font-size:24px;">${mail.schoolEmoji}</span>
            <div>
              <div style="font-size:14px;font-weight:700;color:#333;">${mail.title}</div>
              <div style="font-size:11px;color:#999;margin-top:2px;">${mail.schoolName} · 第${mail.graduationCount}次 · ${dateStr}</div>
            </div>
          </div>
          <div style="text-align:right;">
            ${!mail.read ? '<span style="display:inline-block;background:#ef4444;color:#fff;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:700;">未读</span>' : ''}
            ${mail.claimed ? '<span style="display:inline-block;background:#d1fae5;color:#059669;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:700;margin-top:4px;">已领取</span>' : '<span style="display:inline-block;background:#fef3c7;color:#d97706;border-radius:8px;padding:2px 8px;font-size:11px;font-weight:700;margin-top:4px;">待领取</span>'}
          </div>
        </div>
        <div style="font-size:12px;color:#666;margin-top:8px;line-height:1.5;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;">${mail.content}</div>
        <div style="margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;">
          ${rewardPreview.map(r => `<span style="background:#f3f4f6;border-radius:8px;padding:2px 8px;font-size:11px;color:#666;">${r}</span>`).join('')}
        </div>
      </div>
    `;
  }).join('');
}

// 打开邮件详情
let currentMailId = null;
function openMailDetail(mailId){
  const mails = getMailbox();
  const mail = mails.find(m => m.id === mailId);
  if(!mail) return;
  
  currentMailId = mailId;
  
  // 标记为已读
  mail.read = true;
  saveMailbox(mails);
  updateMailboxBadge();
  renderMailbox();
  
  const date = new Date(mail.timestamp);
  const dateStr = `${date.getFullYear()}/${date.getMonth()+1}/${date.getDate()} ${String(date.getHours()).padStart(2,'0')}:${String(date.getMinutes()).padStart(2,'0')}`;
  
  const rewardItems = [];
  if(mail.rewards.coins) rewardItems.push(`<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:24px;">💰</span><span style="font-size:14px;">金币 ×${mail.rewards.coins}</span></div>`);
  mail.rewards.foods.forEach(f => rewardItems.push(`<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:24px;">${f.emoji}</span><span style="font-size:14px;">${f.name} ×${f.count}</span></div>`));
  mail.rewards.cleans.forEach(c => rewardItems.push(`<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:24px;">${c.emoji}</span><span style="font-size:14px;">${c.name} ×${c.count}</span></div>`));
  mail.rewards.toys.forEach(t => rewardItems.push(`<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:24px;">${t.emoji}</span><span style="font-size:14px;">${t.name} ×${t.count}</span></div>`));
  
  // 显示弹窗
  const modalHtml = `
    <div class="modal-mask" id="mailDetailMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;z-index:1000;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:420px;width:90%;padding:0;overflow:hidden;border-radius:20px;max-height:85vh;overflow-y:auto;">
        <div style="background:linear-gradient(135deg,#fbbf24,#f59e0b);padding:20px;text-align:center;position:relative;">
          <div style="font-size:48px;">${mail.schoolEmoji}</div>
          <div style="font-size:18px;font-weight:700;color:#fff;margin-top:8px;">${mail.title}</div>
          <div style="font-size:12px;color:rgba(255,255,255,0.8);margin-top:4px;">${mail.schoolName}校长 · ${dateStr}</div>
          <button class="modal-close-btn" onclick="closeMailDetail()" aria-label="关闭邮件详情" style="position:absolute;top:12px;right:12px;">×</button>
        </div>
        <div style="padding:20px;">
          <div style="background:#fffbeb;border-radius:12px;padding:16px;font-size:14px;color:#78350f;line-height:1.8;">
            💌 ${mail.content}
          </div>
          <div style="margin-top:16px;">
            <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:10px;">🎁 随信礼物</div>
            <div style="background:#f9fafb;border-radius:12px;padding:14px;display:flex;flex-direction:column;gap:10px;">
              ${rewardItems.join('')}
            </div>
          </div>
          <div style="margin-top:16px;display:flex;gap:10px;">
            ${mail.claimed ? 
              '<button disabled style="flex:1;padding:12px;border:none;border-radius:12px;background:#d1fae5;color:#059669;font-size:14px;font-weight:700;cursor:not-allowed;">✅ 已领取</button>' :
              `<button onclick="claimMailReward('${mail.id}')" style="flex:1;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#fbbf24,#f59e0b);color:#fff;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(245,158,11,0.3);">🎁 领取礼物</button>`
            }
          </div>
        </div>
      </div>
    </div>
  `;
  
  // 移除已存在的弹窗
  const oldModal = document.getElementById('mailDetailMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
}

// 关闭邮件详情
function closeMailDetail(){
  const modal = document.getElementById('mailDetailMask');
  if(!modal) return;
  modal.classList.add('closing');
  document.body.style.overflow='';
  setTimeout(() => {
    if(modal.parentNode) modal.parentNode.removeChild(modal);
  }, 200);
  currentMailId = null;
}

// 领取邮件奖励
function claimMailReward(mailId){
  const mails = getMailbox();
  const mail = mails.find(m => m.id === mailId);
  if(!mail || mail.claimed) return;
  
  // 领取金币
  if(mail.rewards.coins){
    const coins = lsGet('backpack_coins', 0);
    lsSet('backpack_coins', coins + mail.rewards.coins);
  }
  
  // 领取食物入仓库
  mail.rewards.foods.forEach(f => {
    for(let i = 0; i < f.count; i++){
      addToWarehouse('food', f.id);
    }
  });
  
  // 领取清洁用品入仓库
  mail.rewards.cleans.forEach(c => {
    for(let i = 0; i < c.count; i++){
      addToWarehouse('clean', c.id);
    }
  });
  
  // 领取玩具入仓库
  mail.rewards.toys.forEach(t => {
    for(let i = 0; i < t.count; i++){
      addToWarehouse('toy', t.id);
    }
  });
  
  // 标记为已领取
  mail.claimed = true;
  saveMailbox(mails);
  
  showToast('🎁 礼物已领取！食物和用品已放入仓库~');
  
  // 刷新弹窗和列表
  closeMailDetail();
  renderMailbox();
  updateWarehouseBadge();
}

// 初始化信箱页面
function initMailbox(){
  renderMailbox();
  updateMailboxBadge();
}

