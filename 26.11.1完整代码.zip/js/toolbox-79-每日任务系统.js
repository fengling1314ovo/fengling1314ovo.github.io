// ==================== 每日任务系统 ====================
const DAILY_TASKS = [
  {id:'play_game', name:'玩1局游戏', emoji:'🎮', target:1, reward:10, key:'daily_play_game', desc:'任意游戏玩1局'},
  {id:'feed_pet', name:'喂食小橘1次', emoji:'🍖', target:1, reward:8, key:'daily_feed_pet', desc:'使用食物1次'},
  {id:'clean_pet', name:'给小橘清洁1次', emoji:'🧼', target:1, reward:8, key:'daily_clean_pet', desc:'使用清洁用品1次'},
  {id:'play_pet', name:'陪小橘玩1次', emoji:'🪶', target:1, reward:8, key:'daily_play_pet', desc:'使用玩具1次'},
  {id:'gacha', name:'抽卡或扭蛋1次', emoji:'🎴', target:1, reward:10, key:'daily_gacha', desc:'抽卡/扭蛋/转盘任意1次'},
  {id:'checkin', name:'每日签到', emoji:'📅', target:1, reward:15, key:'daily_checkin', desc:'完成今日签到'},
  {id:'earn_coins', name:'赚取50金币', emoji:'🪙', target:50, reward:20, key:'daily_earn_coins', desc:'通过游戏/打工累计赚取'},
  {id:'pet_work', name:'让小橘打工1次', emoji:'💼', target:1, reward:15, key:'daily_pet_work', desc:'完成一次打工'},
  {id:'pet_school', name:'送小橘上学1次', emoji:'🎒', target:1, reward:12, key:'daily_pet_school', desc:'完成一次上学'},
  {id:'use_tool', name:'使用3款不同工具', emoji:'🧰', target:3, reward:12, key:'daily_use_tool', desc:'使用不同的工具/游戏'}
];

// 获取今天的日期字符串
function getTodayStr(){
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0');
}

// 获取每日任务数据（自动跨天重置）
function getDailyTaskData(){
  const data = lsGet('daily_tasks_data', null);
  const today = getTodayStr();
  if(!data || data.date !== today){
    const fresh = {date: today, progress: {}, claimed: [], uniqueTools: []};
    lsSet('daily_tasks_data', fresh);
    return fresh;
  }
  return data;
}

// 更新任务进度
function updateDailyTask(key, amount){
  const data = getDailyTaskData();
  if(!data.progress) data.progress = {};
  data.progress[key] = (data.progress[key] || 0) + (amount || 1);
  lsSet('daily_tasks_data', data);
  // 如果当前在任务页面，刷新显示
  if(pageDailyTaskPage && pageDailyTaskPage.style.display === 'block'){
    renderDailyTasks();
  }
}

// 记录使用了不同工具（用于"使用3款不同工具"任务）
function recordDailyToolUse(toolId){
  const data = getDailyTaskData();
  if(!data.uniqueTools) data.uniqueTools = [];
  if(!data.uniqueTools.includes(toolId)){
    data.uniqueTools.push(toolId);
    data.progress['daily_use_tool'] = data.uniqueTools.length;
    lsSet('daily_tasks_data', data);
  }
}

// 从每日任务页面返回（根据来源页面动态返回）
function backFromDailyTask(){
  const from = window._dailyTaskFrom || 'chestHome';
  openPage(from);
}

// 渲染每日任务列表
function renderDailyTasks(){
  // 更新返回按钮文字（根据来源页面）
  const backText = document.getElementById('dailyTaskBackText');
  if(backText){
    const from = window._dailyTaskFrom || 'chestHome';
    backText.textContent = from === 'statusPage' ? '返回状态' : '返回百宝箱';
  }
  // 同时更新签到区域
  if(typeof checkinRender === 'function') checkinRender();
  const data = getDailyTaskData();
  const listEl = document.getElementById('dailyTaskList');
  if(!listEl) return;
  
  let completed = 0, claimedReward = 0, totalReward = 0;
  let html = '';
  
  DAILY_TASKS.forEach(task => {
    const progress = data.progress[task.key] || 0;
    const done = progress >= task.target;
    const claimed = data.claimed.includes(task.id);
    if(done) completed++;
    totalReward += task.reward;
    if(claimed) claimedReward += task.reward;
    
    const percent = Math.min(100, (progress / task.target) * 100);
    let btnHtml = '';
    if(!done){
      btnHtml = '<div style="font-size:12px;color:var(--text-placeholder);">进度 ' + Math.min(progress, task.target) + '/' + task.target + '</div>';
    } else if(claimed){
      btnHtml = '<div style="font-size:12px;color:#16a34a;font-weight:600;">✅ 已领取</div>';
    } else {
      btnHtml = '<button onclick="claimDailyTask(\'' + task.id + '\')" style="background:linear-gradient(135deg,#f59e0b,#d97706);color:#fff;border:none;padding:6px 14px;border-radius:10px;font-size:12px;font-weight:700;cursor:pointer;box-shadow:0 2px 6px rgba(245,158,11,0.3);">🎁 领取 +' + task.reward + '</button>';
    }
    
    html += '<div style="background:' + (done ? 'linear-gradient(135deg,#fef3c7,#fde68a)' : 'var(--card-bg)') + ';border-radius:14px;padding:14px;box-shadow:0 2px 8px rgba(0,0,0,0.05);border:1px solid ' + (done ? '#f59e0b' : 'var(--border-color)') + ';">' +
      '<div style="display:flex;align-items:center;gap:12px;">' +
        '<div style="font-size:28px;">' + task.emoji + '</div>' +
        '<div style="flex:1;min-width:0;">' +
          '<div style="font-size:14px;font-weight:700;">' + task.name + '</div>' +
          '<div style="font-size:11px;color:var(--text-secondary);margin-top:1px;">' + task.desc + '</div>' +
          '<div style="height:6px;background:#eee;border-radius:3px;overflow:hidden;margin-top:6px;">' +
            '<div style="height:100%;background:linear-gradient(90deg,#f59e0b,#d97706);border-radius:3px;width:' + percent + '%;transition:width 0.3s;"></div>' +
          '</div>' +
        '</div>' +
        '<div style="flex-shrink:0;text-align:right;min-width:70px;">' +
          '<div style="font-size:11px;color:#b45309;font-weight:600;">+' + task.reward + '💰</div>' +
          btnHtml +
        '</div>' +
      '</div>' +
    '</div>';
  });
  
  listEl.innerHTML = html;
  
  // 更新概览
  const elDate = document.getElementById('dailyTaskDate');
  if(elDate) elDate.textContent = data.date;
  const elProg = document.getElementById('dailyTaskProgress');
  if(elProg) elProg.textContent = completed + '/' + DAILY_TASKS.length;
  const elBar = document.getElementById('dailyTaskBar');
  if(elBar) elBar.style.width = (completed / DAILY_TASKS.length * 100) + '%';
  const elClaimed = document.getElementById('dailyTaskClaimed');
  if(elClaimed) elClaimed.textContent = claimedReward;
  const elTotal = document.getElementById('dailyTaskTotal');
  if(elTotal) elTotal.textContent = totalReward;
}

// 领取每日任务奖励
function claimDailyTask(taskId){
  const task = DAILY_TASKS.find(t => t.id === taskId);
  if(!task) return;
  const data = getDailyTaskData();
  if(data.claimed.includes(taskId)) return;
  const progress = data.progress[task.key] || 0;
  if(progress < task.target) return;
  data.claimed.push(taskId);
  lsSet('daily_tasks_data', data);
  bpAddCoins(task.reward, 'dailyTask');
  showToast('🎁 领取成功！获得' + task.reward + '金币~');
  renderDailyTasks();
}

