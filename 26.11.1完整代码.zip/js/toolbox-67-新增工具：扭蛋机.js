/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageCapsulePage", "<!-- pageCapsulePage -->\n<div class=\"tool-page\" id=\"pageCapsulePage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('chestHome')\"><span>←</span> 返回百宝箱</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3 style=\"display:flex;align-items:center;justify-content:space-between;\">🥚 扭蛋机 <button onclick=\"openCapsuleRule()\" style=\"background:var(--primary);color:#fff;border:none;padding:6px 14px;border-radius:20px;font-size:13px;cursor:pointer;font-weight:600;\">? 规则</button></h3>\n      <div class=\"fortune-today-card\" style=\"text-align:center;\">\n        <div style=\"font-size:64px;margin:12px 0;\" id=\"capsuleIcon\">🥚</div>\n        <div style=\"font-size:14px;color:var(--text-secondary);\">每次扭蛋消耗 <b style=\"color:var(--primary);\">5</b> 金币，有机会获得稀有卡牌、金币返还或道具！</div>\n        <div style=\"display:flex;gap:10px;justify-content:center;margin-top:16px;flex-wrap:wrap;\">\n          <button class=\"common-btn\" onclick=\"capsuleSpin()\">🥚 扭一次（5金币）</button>\n          <button class=\"common-btn\" onclick=\"capsuleSpin5()\">🎉 扭五次（25金币）</button>\n        </div>\n        <div style=\"margin-top:12px;font-size:13px;color:var(--text-secondary);\">当前金币：<b id=\"capsuleCoins\" style=\"color:var(--primary);\"></b></div>\n      </div>\n      <div id=\"capsuleResult\" style=\"margin-top:16px;\"></div>\n    </div>\n  </div>");
// ==================== 新增工具：扭蛋机 ====================
const CAPSULE_COST=5;
function capsuleRender(){
  const el=document.getElementById('capsuleCoins');
  if(el)el.textContent=bpGetCoins();
}
function capsuleSpinOne(){
  if(bpGetCoins()<CAPSULE_COST){showToast('金币不足！去玩小游戏赚金币吧');return null;}
  bpSpendCoins(CAPSULE_COST,'capsule');
  const r=Math.random();
  if(r<0.30){
    const rr=Math.random();
    const rarity=rr<0.03?'ssr':(rr<0.15?'sr':(rr<0.45?'r':'n'));
    const name=bpAddCard(rarity);
    const icon=BP_CARD_ICONS[rarity];
    const color=rarity==='ssr'?'#f59e0b':(rarity==='sr'?'#a855f7':(rarity==='r'?'#3b82f6':'#6b7280'));
    return '<div style="font-size:34px;">'+icon+'</div><div style="font-weight:bold;font-size:15px;color:'+color+';margin:6px 0;">稀有卡牌：'+name+'</div><div style="font-size:12px;color:var(--text-secondary);">已收入背包</div>';
  }else if(r<0.75){
    const back=Math.floor(Math.random()*4)+1;
    bpAddCoins(back,'capsule');
    return '<div style="font-size:34px;">💰</div><div style="font-weight:bold;font-size:15px;color:var(--primary);margin:6px 0;">返还金币 +'+back+'</div>';
  }else if(r<0.9){
    const item=capsuleGetRandomItem();
    bpAddItem(item.id);
    return '<div style="font-size:34px;">'+item.icon+'</div><div style="font-weight:bold;font-size:15px;color:'+item.color+';margin:6px 0;">道具：'+item.name+'</div><div style="font-size:12px;color:var(--text-secondary);">'+ITEM_RARITY_NAMES[item.rarity]+' · 已收入背包</div>';
  }else{
    return '<div style="font-size:34px;">😢</div><div style="font-weight:bold;font-size:15px;margin:6px 0;">什么都没有</div><div style="font-size:12px;color:var(--text-secondary);">下次好运！</div>';
  }
}
function capsuleSpin(){
  const res=capsuleSpinOne();
  if(res===null)return;
  document.getElementById('capsuleResult').innerHTML='<div class="quiz-result-card" style="text-align:center;">'+res+'</div>';
  capsuleRender();
  // 每日任务进度
  if(typeof updateDailyTask === 'function') updateDailyTask('daily_gacha', 1);
}
function capsuleSpin5(){
  if(bpGetCoins()<CAPSULE_COST*5){showToast('金币不足！');return;}
  const results=[];
  for(let i=0;i<5;i++){
    const r=capsuleSpinOne();
    if(r)results.push(r);
  }
  document.getElementById('capsuleResult').innerHTML='<div style="display:flex;flex-wrap:wrap;gap:10px;">'+results.map(r=>'<div class="quiz-result-card" style="flex:1 1 120px;min-width:0;text-align:center;">'+r+'</div>').join('')+'</div>';
  capsuleRender();
}

