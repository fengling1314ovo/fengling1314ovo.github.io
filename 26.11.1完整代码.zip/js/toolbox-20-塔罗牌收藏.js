/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageCollectionPage", "<!-- pageCollectionPage -->\n<div class=\"tool-page\" id=\"pageCollectionPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🏆 全部收藏品展柜</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:16px;\">带小橘出去玩收集各种纪念品吧~ 已收集 <span id=\"allCollectionCount\" style=\"color:#f59e0b;font-weight:700;\">0</span>/<span id=\"allCollectionTotal\">15</span></div>\n      \n      <div id=\"allCollectionContent\">\n        <!-- 按地点分组的收藏品由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ===== 塔罗牌收藏 =====
let bpTarotFilter='upright';
function bpFilterTarot(cat){
  bpTarotFilter=cat;
  document.querySelectorAll('#bpTarotTabs .bp-cat-tab').forEach(t=>t.classList.remove('active'));
  try{event.target.classList.add('active');}catch(e){}
  const grid=document.getElementById('bpTarotGrid');
  const tip=document.getElementById('bpTarotHideTip');
  if(grid){grid.style.display='grid';}
  if(tip){tip.style.display='none';}
  const hideBtn=document.querySelector('#bpTarotTabs .bp-hide-btn');
  if(hideBtn){hideBtn.textContent='🙈 隐藏';hideBtn.classList.add('showing');}
  bpRenderTarot();
}
function bpRenderTarot(){
  const cards=lsGet('backpack_tarot',[]);
  const filtered=bpTarotFilter==='all'?cards:
    bpTarotFilter==='upright'?cards.filter(c=>!c.reversed):
    cards.filter(c=>c.reversed);
  const grid=document.getElementById('bpTarotGrid');
  if(!grid)return;
  if(filtered.length===0){
    grid.innerHTML='<div class="bp-empty" style="grid-column:1/-1;">还没有塔罗牌，去百宝箱抽牌试试吧！</div>';
    return;
  }
  // 合并重复项，按牌编号+正逆位分组统计数量
  const tarotMap={};
  filtered.forEach(c=>{
    const key=c.num+'_'+(c.reversed?'rev':'up');
    if(!tarotMap[key])tarotMap[key]={...c,count:0};
    tarotMap[key].count++;
  });
  const mergedTarot=Object.values(tarotMap).sort((a,b)=>b.count-a.count);
  grid.innerHTML=mergedTarot.map(c=>{
    const tarotKey=c.num+'_'+(c.reversed?'rev':'up');
    return '<div class="bp-tarot-card'+(c.reversed?' reversed':'')+'" style="position:relative;cursor:pointer;" onclick="bpShowTarotDetail(\''+tarotKey+'\')">'+
      (c.count>1?'<div style="position:absolute;top:4px;right:4px;background:'+(c.reversed?'#db2777':'#ca8a04')+';color:#fff;font-size:10px;padding:1px 6px;border-radius:8px;font-weight:bold;">x'+c.count+'</div>':'')+
      '<div class="bt-num">'+c.num+'</div>'+
      '<div class="bt-icon">'+c.icon+'</div>'+
      '<div class="bt-name">'+c.name+'</div>'+
      '<div class="bt-orient">'+(c.reversed?'逆位':'正位')+'</div>'+
    '</div>';
  }).join('');
}

