// ==================== 批量购买系统 ====================
let batchBuyItem = null;
let batchBuyType = null;
let batchBuyQuantity = 1;

// 打开批量购买弹窗
function showBuyQuantityModal(item, type){
  batchBuyItem = item;
  batchBuyType = type;
  batchBuyQuantity = 1;
  
  // 获取商品单价和效果描述
  const price = item.price || item.cost || 0;
  let effectText = '';
  if(type === 'food') effectText = `+${item.hunger}饱食度/个`;
  else if(type === 'clean') effectText = `+${item.clean}清洁值/个`;
  else if(type === 'toy') effectText = `+${item.affection}好感度/个`;
  
  const coins = bpGetCoins();
  const maxAffordable = Math.floor(coins / price);
  
  const modalHtml = `
    <div class="modal-mask" id="buyModalMask" style="display:flex;position:fixed;top:0;left:0;right:0;bottom:0;width:100%;height:100%;z-index:1000;align-items:center;justify-content:center;margin:0;padding:0;">
      <div class="modal-box" style="max-width:360px;width:90%;padding:0;overflow:hidden;border-radius:20px;">
        <div style="background:linear-gradient(135deg,#667eea,#764ba2);padding:20px;text-align:center;position:relative;">
          <div style="font-size:56px;">${item.emoji}</div>
          <div style="font-size:18px;font-weight:700;color:#fff;margin-top:8px;">${item.name}</div>
          <div style="font-size:12px;color:rgba(255,255,255,0.8);margin-top:4px;">${effectText}</div>
          <div style="font-size:14px;color:#fef3c7;margin-top:6px;font-weight:600;">💰 单价：${price} 金币</div>
          <button class="modal-close-btn" onclick="closeBuyModal()" aria-label="关闭批量购买弹窗" style="position:absolute;top:12px;right:12px;">×</button>
        </div>
        <div style="padding:20px;">
          <div style="font-size:14px;font-weight:700;color:#333;margin-bottom:12px;text-align:center;">选择购买数量</div>
          
          <!-- 快捷数量按钮 -->
          <div style="display:flex;gap:8px;margin-bottom:14px;">
            <button onclick="setBuyQuantity(1)" id="bqBtn1" style="flex:1;padding:10px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;">×1</button>
            <button onclick="setBuyQuantity(5)" id="bqBtn5" style="flex:1;padding:10px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;background:#f3f4f6;color:#666;">×5</button>
            <button onclick="setBuyQuantity(10)" id="bqBtn10" style="flex:1;padding:10px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;background:#f3f4f6;color:#666;">×10</button>
            <button onclick="setBuyQuantity(${maxAffordable > 0 ? maxAffordable : 1})" id="bqBtnMax" style="flex:1;padding:10px;border:none;border-radius:10px;font-size:14px;font-weight:700;cursor:pointer;background:#f3f4f6;color:#666;">最大</button>
          </div>
          
          <!-- 自定义数量 -->
          <div style="display:flex;align-items:center;justify-content:center;gap:16px;margin-bottom:16px;background:#f9fafb;border-radius:12px;padding:12px;">
            <button onclick="changeBuyQuantity(-1)" style="width:36px;height:36px;border:none;border-radius:50%;background:#e5e7eb;color:#333;font-size:20px;font-weight:700;cursor:pointer;">−</button>
            <input type="number" id="buyQuantityInput" value="1" min="1" oninput="onBuyQuantityInput(this.value)" style="font-size:28px;font-weight:700;color:#333;min-width:80px;text-align:center;border:none;background:transparent;outline:none;-moz-appearance:textfield;" />
            <button onclick="changeBuyQuantity(1)" style="width:36px;height:36px;border:none;border-radius:50%;background:#e5e7eb;color:#333;font-size:20px;font-weight:700;cursor:pointer;">+</button>
          </div>
          
          <!-- 总价 -->
          <div style="display:flex;justify-content:space-between;align-items:center;background:#fef3c7;border-radius:10px;padding:12px;margin-bottom:16px;">
            <span style="font-size:14px;color:#92400e;font-weight:600;">总价</span>
            <span style="font-size:18px;font-weight:700;color:#d97706;" id="buyTotalPrice">💰 ${price}</span>
          </div>
          
          <!-- 当前金币 -->
          <div style="text-align:center;font-size:12px;color:#999;margin-bottom:14px;">当前金币：💰 ${coins} ${maxAffordable > 0 ? `（最多可买${maxAffordable}个）` : '（金币不足）'}</div>
          
          <!-- 按钮 -->
          <div style="display:flex;gap:10px;">
            <button onclick="closeBuyModal()" style="flex:1;padding:12px;border:none;border-radius:12px;background:#f3f4f6;color:#666;font-size:14px;font-weight:700;cursor:pointer;">取消</button>
            <button onclick="confirmBatchBuy()" id="confirmBatchBuyBtn" style="flex:2;padding:12px;border:none;border-radius:12px;background:linear-gradient(135deg,#667eea,#764ba2);color:#fff;font-size:14px;font-weight:700;cursor:pointer;box-shadow:0 4px 12px rgba(102,126,234,0.3);">🛒 确认购买</button>
          </div>
        </div>
      </div>
    </div>
  `;
  
  // 移除已存在的弹窗
  const oldModal = document.getElementById('buyModalMask');
  if(oldModal) oldModal.remove();
  
  document.body.insertAdjacentHTML('beforeend', modalHtml);
  document.body.style.overflow='hidden';
  updateBuyModalDisplay();
}

// 设置购买数量
function setBuyQuantity(qty){
  batchBuyQuantity = qty;
  updateBuyModalDisplay();
}

// 增减购买数量
function changeBuyQuantity(delta){
  const newQty = batchBuyQuantity + delta;
  if(newQty >= 1 && newQty <= 999){
    batchBuyQuantity = newQty;
    updateBuyModalDisplay();
  }
}

// 直接输入购买数量
function onBuyQuantityInput(value){
  let qty = parseInt(value);
  if(isNaN(qty) || qty < 1) qty = 1;
  if(qty > 999) qty = 999;
  batchBuyQuantity = qty;
  updateBuyModalDisplay();
}

// 更新弹窗显示
function updateBuyModalDisplay(){
  const price = batchBuyItem.price || batchBuyItem.cost || 0;
  const total = price * batchBuyQuantity;
  const coins = bpGetCoins();
  
  const qtyInput = document.getElementById('buyQuantityInput');
  const totalDisplay = document.getElementById('buyTotalPrice');
  const confirmBtn = document.getElementById('confirmBatchBuyBtn');
  
  if(qtyInput && document.activeElement !== qtyInput) qtyInput.value = batchBuyQuantity;
  if(totalDisplay) totalDisplay.textContent = `💰 ${total}`;
  
  // 更新快捷按钮高亮
  ['1','5','10'].forEach(q => {
    const btn = document.getElementById('bqBtn' + q);
    if(btn){
      if(batchBuyQuantity === parseInt(q)){
        btn.style.background = 'linear-gradient(135deg,#667eea,#764ba2)';
        btn.style.color = '#fff';
      } else {
        btn.style.background = '#f3f4f6';
        btn.style.color = '#666';
      }
    }
  });
  
  // 最大按钮高亮
  const maxBtn = document.getElementById('bqBtnMax');
  if(maxBtn){
    const maxAffordable = Math.floor(coins / price);
    if(batchBuyQuantity === maxAffordable && maxAffordable > 0){
      maxBtn.style.background = 'linear-gradient(135deg,#667eea,#764ba2)';
      maxBtn.style.color = '#fff';
    } else {
      maxBtn.style.background = '#f3f4f6';
      maxBtn.style.color = '#666';
    }
  }
  
  // 确认按钮状态
  if(confirmBtn){
    if(total > coins){
      confirmBtn.style.background = '#d1d5db';
      confirmBtn.style.color = '#9ca3af';
      confirmBtn.style.cursor = 'not-allowed';
      confirmBtn.textContent = '💰 金币不足';
    } else {
      confirmBtn.style.background = 'linear-gradient(135deg,#667eea,#764ba2)';
      confirmBtn.style.color = '#fff';
      confirmBtn.style.cursor = 'pointer';
      confirmBtn.textContent = `🛒 购买${batchBuyQuantity}个`;
    }
  }
}

// 确认批量购买
function confirmBatchBuy(){
  const item = batchBuyItem;
  const type = batchBuyType;
  const qty = batchBuyQuantity;
  const price = item.price || item.cost || 0;
  const total = price * qty;
  const coins = bpGetCoins();
  
  if(total > coins){
    showToast('金币不足，去玩游戏赚金币吧~');
    return;
  }
  
  // 扣除金币
  lsSet('backpack_coins', coins - total);
  
  // 批量放入仓库
  for(let i = 0; i < qty; i++){
    addToWarehouse(type, item.id);
  }
  
  // 更新显示
  if(type === 'food'){
    updatePetDisplay();
  } else if(type === 'clean'){
    updateCleanShopDisplay();
    updatePetStatusDisplay();
  } else if(type === 'toy'){
    updateToyShopDisplay();
    updatePetStatusDisplay();
  }
  updateWarehouseBadge();
  if(typeof bpUpdateHomeBadge === 'function') bpUpdateHomeBadge();
  
  // 播放音效
  if(typeof playSound === 'function') playSound('coin');
  
  showToast(`购买了${item.emoji}${item.name} ×${qty}，已放入仓库~`);
  closeBuyModal();
}

// 关闭购买弹窗
function closeBuyModal(){
  const modal = document.getElementById('buyModalMask');
  if(modal){
    modal.classList.add('closing');
    document.body.style.overflow='';
    setTimeout(()=>{ modal.remove(); }, 200);
  }
  batchBuyItem = null;
  batchBuyType = null;
  batchBuyQuantity = 1;
}



// 页面加载时初始化状态
initStatus();


/* ===== 百宝箱功能分段 ===== */

