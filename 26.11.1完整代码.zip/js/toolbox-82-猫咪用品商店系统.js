/* 页面模板按需注册：从原 tool-pages.js 迁入。 */
window.flRegisterToolPage("pageToyShopPage", "<!-- pageToyShopPage -->\n<div class=\"tool-page\" id=\"pageToyShopPage\">\n    <div class=\"tool-header\">\n      <button class=\"back-btn\" onclick=\"openPage('statusPage')\"><span>←</span> 返回状态</button>\n    </div>\n    <div class=\"breadcrumb\"></div>\n    <div class=\"common-block\" style=\"padding:0 28px 32px\">\n      <h3>🪶 猫咪用品商店</h3>\n      <div style=\"font-size:13px;color:var(--text-secondary);margin-bottom:14px;\">给小橘买玩具和用品，陪它玩耍提升好感度~ 点击物品购买后放入仓库，再从仓库使用！</div>\n      \n      <!-- 小橘状态 -->\n      <div style=\"background:linear-gradient(180deg,#e0f7fa,#fff);border-radius:16px;padding:16px;margin-bottom:14px;box-shadow:0 2px 12px rgba(0,0,0,0.06);\">\n        <div style=\"display:flex;align-items:center;justify-content:space-between;\">\n          <div style=\"display:flex;align-items:center;\">\n            <div style=\"font-size:48px;\" id=\"toyPetEmoji\">🐱</div>\n            <div style=\"margin-left:12px;\">\n              <div style=\"font-size:16px;font-weight:700;\">小橘</div>\n              <div style=\"font-size:12px;color:#666;margin-top:2px;\" id=\"toyPetMood\">心情不错~</div>\n            </div>\n          </div>\n          <div style=\"text-align:right;flex-shrink:0;min-width:80px;\">\n            <div style=\"display:inline-block;background:#fce7f3;color:#ec4899;padding:3px 10px;border-radius:10px;font-size:12px;font-weight:700;white-space:nowrap;\">\n              💕 <span id=\"toyPetAffection\">50</span>\n            </div>\n            <div style=\"font-size:11px;color:#666;margin-top:5px;white-space:nowrap;\">💰 <span id=\"toyCoins\">0</span></div>\n          </div>\n        </div>\n        <div style=\"margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;\">\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🍖 饱食</span>\n              <span id=\"toyHungerText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"toyHungerBar\" style=\"height:100%;background:linear-gradient(90deg,#ff6b6b,#feca57);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>🧼 清洁</span>\n              <span id=\"toyCleanText\">100/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"toyCleanBar\" style=\"height:100%;background:linear-gradient(90deg,#60a5fa,#34d399);border-radius:4px;width:100%;\"></div>\n            </div>\n          </div>\n          <div>\n            <div style=\"display:flex;justify-content:space-between;font-size:10px;margin-bottom:4px;white-space:nowrap;\">\n              <span>💕 好感</span>\n              <span id=\"toyAffectionText\">50/100</span>\n            </div>\n            <div style=\"height:8px;background:#eee;border-radius:4px;overflow:hidden;\">\n              <div id=\"toyAffectionBar\" style=\"height:100%;background:linear-gradient(90deg,#f472b6,#fb7185);border-radius:4px;width:50%;\"></div>\n            </div>\n          </div>\n        </div>\n      </div>\n      \n      <!-- 玩具列表 -->\n      <div id=\"toyShopList\" style=\"display:grid;grid-template-columns:1fr 1fr;gap:12px;\">\n        <!-- 玩具列表由JS生成 -->\n      </div>\n    </div>\n  </div>");
// ==================== 猫咪用品商店系统 ====================
// 初始化猫咪用品商店页面
function initToyShop(){
  renderToyShopList();
  updateToyShopDisplay();
}

// 更新猫咪用品商店页面显示
function updateToyShopDisplay(){
  const hunger = lsGet('pet_hunger', 50);
  const hungerPercent = Math.max(0, Math.min(100, hunger));
  const clean = lsGet('pet_clean', 100);
  const cleanPercent = Math.max(0, Math.min(100, clean));
  const affection = lsGet('pet_affection', 50);
  const affectionPercent = Math.max(0, Math.min(100, affection));
  
  // 根据状态更新表情和心情
  let mood, emoji;
  if(hungerPercent >= 80 && cleanPercent >= 80){ mood='吃饱喝足，超级开心~'; emoji='😺'; }
  else if(hungerPercent >= 50 && cleanPercent >= 50){ mood='心情不错~'; emoji='🐱'; }
  else if(hungerPercent >= 20 && cleanPercent >= 20){ mood='有点饿了/该洗澡了...'; emoji='😿'; }
  else{ mood='快饿晕啦/脏死啦，快照顾我！'; emoji='😾'; }
  if(cleanPercent < 30){ emoji = '🥺'; mood = '脏死啦，快给我洗澡！'; }
  
  const elEmoji = document.getElementById('toyPetEmoji');
  const elMood = document.getElementById('toyPetMood');
  const elAffection = document.getElementById('toyPetAffection');
  const elCoins = document.getElementById('toyCoins');
  const elHungerText = document.getElementById('toyHungerText');
  const elHungerBar = document.getElementById('toyHungerBar');
  const elCleanText = document.getElementById('toyCleanText');
  const elCleanBar = document.getElementById('toyCleanBar');
  const elAffectionText = document.getElementById('toyAffectionText');
  const elAffectionBar = document.getElementById('toyAffectionBar');
  
  if(elEmoji) elEmoji.textContent = emoji;
  if(elMood) elMood.textContent = mood;
  if(elAffection) elAffection.textContent = affectionPercent;
  if(elCoins) elCoins.textContent = bpGetCoins();
  if(elHungerText) elHungerText.textContent = hungerPercent + '/100';
  if(elHungerBar) elHungerBar.style.width = hungerPercent + '%';
  if(elCleanText) elCleanText.textContent = cleanPercent + '/100';
  if(elCleanBar) elCleanBar.style.width = cleanPercent + '%';
  if(elAffectionText) elAffectionText.textContent = affectionPercent + '/100';
  if(elAffectionBar) elAffectionBar.style.width = affectionPercent + '%';
}

// 渲染玩具列表
function renderToyShopList(){
  const container = document.getElementById('toyShopList');
  if(!container) return;
  container.innerHTML = '';
  PET_TOYS.forEach(toy => {
    const div = document.createElement('div');
    div.style.cssText = 'background:var(--card-bg);border-radius:14px;padding:16px;text-align:center;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,0.06);transition:transform 0.2s;border:2px solid transparent;';
    div.onmouseover = () => {div.style.transform='scale(1.03)';div.style.borderColor='#a78bfa';};
    div.onmouseout = () => {div.style.transform='scale(1)';div.style.borderColor='transparent';};
    div.onclick = () => showBuyQuantityModal(toy, 'toy');
    div.innerHTML = `
      <div style="font-size:36px;">${toy.emoji}</div>
      <div style="font-size:15px;font-weight:700;margin-top:8px;">${toy.name}</div>
      <div style="font-size:12px;color:#666;margin-top:4px;">+${toy.affection}好感度</div>
      <div style="margin-top:8px;display:inline-block;background:#fce7f3;color:#ec4899;padding:4px 12px;border-radius:12px;font-size:13px;font-weight:700;">
        💰 ${toy.cost}
      </div>
    `;
    container.appendChild(div);
  });
}



