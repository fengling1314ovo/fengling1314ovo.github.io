// ============================================================
(function () {
  if (typeof window.cleanupBeforePageSwitch === 'function') {
    const _orig = window.cleanupBeforePageSwitch;
    window.cleanupBeforePageSwitch = function () {
      _orig.apply(this, arguments);
      try {
        if (sdTimer) { clearInterval(sdTimer); sdTimer = null; sdPlaying = false; }
        if (m3Timer) { clearInterval(m3Timer); m3Timer = null; m3Lock = false; }
        if (lkTimer) { clearInterval(lkTimer); lkTimer = null; lkLock = false; }
      } catch (e) { /* ignore */ }
    };
  }
})();

